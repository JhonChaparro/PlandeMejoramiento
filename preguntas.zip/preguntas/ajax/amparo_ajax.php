<?php

include_once dirname(__FILE__) . '/../../general/sec_ajax.php';
include_once dirname(__FILE__) . '/../../general/sec_header.php';

$accion = $_POST['accion'];
switch ($accion) {
  case 'cambiarActivo':
    echo cambiarActivo();
    break;

  case 'buscarAmparo':
    echo buscarAmparo();
    break;

  case 'listarAmparos':
    echo listarAmparos();
    break;

  case 'guardarAmparo':
    echo guardarAmparo();
    break;
}

function cambiarActivo() {
  global $mySQL;
  $return = array();
  $amparo_id = $_POST['amparo_id'];
  $valor = $_POST['valor'];
  $usuario_log = $_SESSION['preguntas_admin_user']['usuario_id'];
  $sql = "UPDATE amparo SET amparo_activo = '$valor', usuario_log = $usuario_log WHERE amparo_id = $amparo_id";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    $return['success'] = true;
  } else {
    $return['success'] = false;
    $return['error'] = 'Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
    //$return['error'] = $query['error'];
  }
  return json_encode($return);
}

function buscarAmparo() {
  global $mySQL;
  $return = array();
  $amparo_id = $_POST['amparo_id'];
  $sql = "SELECT * FROM amparo WHERE amparo_id = $amparo_id";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      $return = $mySQL->fetch_assoc($query['result']);

      $sql = "SELECT tipo_liqui_id FROM amparo_liqui WHERE amparo_id = $amparo_id";
      $query = $mySQL->query($sql);
      if ($query['success']) {
        $tipo_liqui_ids = array();
        if ($mySQL->num_rows($query['result']) > 0) {
          while ($row = $mySQL->fetch_assoc($query['result'])) {
            $tipo_liqui_ids[] = $row['tipo_liqui_id'];
          }
        }
        $return['success'] = true;
        $return['tipo_liqui_ids'] = $tipo_liqui_ids;
      } else {
        $return['success'] = false;
        $return['error'] = "Error tratando de buscar los tipos de liquidación, por favor intente nuevamente";
      }
    } else {
      $return['success'] = false;
      $return['error'] = "Amparo no encontrado";
    }
  } else {
    $return['success'] = false;
    $return['error'] = 'Ocurrió un error al momento de consultar la información del amparo, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
    //$return['error'] = $query['error'];
  }
  return json_encode($return);
}

function listarAmparos() {
  global $mySQL;
  $filtro = $_POST['filtro'];

  $return = "";
  $sql = "SELECT amparo.*, elt(field(amparo.amparo_activo, 'S','N'), 'SI', 'NO') AS amparo_activo, tipo_amparo_nombre, garantia_nombre FROM amparo LEFT JOIN tipo_amparo USING (tipo_amparo_id) LEFT JOIN garantia USING (garantia_id)";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      $return = '
  <table style="width: 80%" id="tablaAmparos" class="tablesorter">
    <thead>
      <tr style="text-align:center;">
        <th>
          Nombre
        </th>
        <th>
          Garantia
        </th>
        <th>
          Tipo
        </th>
        <th>
          Liquidaciones
        </th>
        <th>
          Vigencia puede ser no definida
        </th>
        <th>
          Activo
        </th>
        <th>
          &nbsp;
        </th>
      </tr>
    </thead>
    <tbody>';
      while ($row = $mySQL->fetch_assoc($query['result'])) {
        $trRow = "
        <tr>
          <td>$row[amparo_nombre]</td>
          <td style='text-align: left;'>$row[garantia_nombre]</td>
          <td>$row[tipo_amparo_nombre]</td>
          ";

        $text_liqui = "";
        $sql_liqui = "SELECT amparo_liqui_nombre FROM tipo_liqui"
          . " WHERE EXISTS (SELECT 1 FROM amparo_liqui WHERE amparo_id = " . $row['amparo_id'] . " AND amparo_liqui_activo = 'S' AND amparo_liqui.tipo_liqui_id = tipo_liqui.tipo_liqui_id)";
        $query_liqui = $mySQL->query($sql_liqui);
        if ($query_liqui['success']) {
          if ($mySQL->num_rows($query_liqui['result']) > 0) {
            while ($row_liqui = $mySQL->fetch_assoc($query_liqui['result'])) {
              if (!empty($text_liqui)) {
                $text_liqui .= "<br/>";
              }
              $text_liqui .= $row_liqui['amparo_liqui_nombre'];
            }
          }
        }

        $trRow .= "
          <td style='text-align: left;'>$text_liqui</td>";

        $trRow .= "
          <td>" . (($row['vig_no_def'] == 'S') ? "SI" : "NO") . "</td>
          <td style='text-align: center;'>$row[amparo_activo]</td>
          <td style='text-align: center;'>
            <a href='javascript:editarAmparo(\"editar\", $row[amparo_id]);'><img src='images/b_edit.png'/></a>";
        if ($row['amparo_activo'] == 'SI') {
          $trRow .= "<a href='javascript:cambiarActivoAmparo($row[amparo_id], \"N\");'><img src='images/turn_off.png'/></a>";
        } else {
          $trRow .= "<a href='javascript:cambiarActivoAmparo($row[amparo_id], \"S\");'><img src='images/turn_on.png'/></a>";
        }
        $trRow .= "
          </td>
        </tr>";
        if (is_null($filtro) || empty($filtro) || strpos(strtolower($trRow), strtolower($filtro)) > 0) {
          $return .= $trRow;
        }
      }
      $return .= '
      </tbody>
  </table>';
    } else {
      $return = 'No existen amparos en el sistema';
    }
  } else {
    $return = 'Se ha generado el siguiente error: ' . $query['error'];
  }
  return $return;
}

function guardarAmparo() {
  global $mySQL;
  $return = array();
  $tipo = $_POST['tipo'];
  $amparo_id = $_POST['amparo_id'];
  $amparo_nombre = $_POST['amparo_nombre'];
  $vig_no_def = $_POST['vig_no_def'];
  $tipo_amparo_id = $_POST['tipo_amparo_id'];
  $garantia_id = $_POST['garantia_id'];
  $tipo_liqui_ids = $_POST['tipo_liqui_ids'];
  $usuario_log = $_SESSION['preguntas_admin_user']['usuario_id'];
  //die;
  if ($tipo == "nuevo") {
    $sql = "SELECT * FROM amparo WHERE amparo_nombre = '$amparo_nombre'";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $return['success'] = false;
        $return['error'] = "Ya existe un amparo con el nombre $amparo_nombre.  Por favor utilice uno diferente.";
      } else {
        $sql = "INSERT INTO amparo (garantia_id, amparo_nombre, vig_no_def, tipo_amparo_id, usuario_log, amparo_activo) VALUES($garantia_id, '$amparo_nombre', '$vig_no_def',  $tipo_amparo_id, $usuario_log, 'S')";
        $query = $mySQL->query($sql);

        if ($query['success']) {
          $amparo_id = $mySQL->insert_id();
          $return['success'] = true;
        } else {
          $return['success'] = false;
          $return['error'] = 'Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
          //$return['error'] = $query['error'];
        }
      }
    } else {
      $return['success'] = false;
      $return['error'] = 'Ocurrió un error al momento de consultar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
    }
  } else {
    $sql = "SELECT * FROM amparo WHERE amparo_nombre = '$amparo_nombre' AND amparo_id <> $amparo_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $return['success'] = false;
        $return['error'] = "Ya existe un amparo con el nombre $amparo_nombre.  Por favor utilice uno diferente.";
      } else {
        $sql = "UPDATE amparo SET garantia_id = $garantia_id, amparo_nombre = '$amparo_nombre', tipo_amparo_id = $tipo_amparo_id, vig_no_def = '$vig_no_def', usuario_log = $usuario_log WHERE amparo_id = $amparo_id";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          $return['success'] = true;
        } else {
          $return['success'] = false;
          $return['error'] = 'Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
          //$return['error'] = $query['error'];
        }
      }
    } else {
      $return['success'] = false;
      $return['error'] = 'Ocurrió un error al momento de consultar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
    }
  }
  if ($return['success']) {
    //tipo_liquis
    $tipo_liquis_sql = "(";
    foreach ($tipo_liqui_ids as $key => $tipo_liqui_id) {
      $tipo_liquis_sql .= $tipo_liqui_id;
      if ($key < count($tipo_liqui_ids) - 1) {
        $tipo_liquis_sql .= ",";
      }
    }
    $tipo_liquis_sql .= ")";
    //se deshabilitan los que no vienen de pantalla
    $sql = "UPDATE amparo_liqui SET amparo_liqui_activo = 'N', usuario_log = $usuario_log WHERE amparo_id = $amparo_id AND amparo_liqui_activo = 'S' AND tipo_liqui_id NOT IN $tipo_liquis_sql";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      //se habilitan los que vienen de pantalla y estan inactivos
      $sql = "UPDATE amparo_liqui SET amparo_liqui_activo = 'S', usuario_log = $usuario_log WHERE amparo_id = $amparo_id AND amparo_liqui_activo = 'N' AND tipo_liqui_id IN $tipo_liquis_sql";
      $query = $mySQL->query($sql);
      if ($query['success']) {
        $sql = "INSERT INTO amparo_liqui (tipo_liqui_id, amparo_id, amparo_liqui_activo, usuario_log)
                    SELECT tipo_liqui_id, $amparo_id, 'S', $usuario_log FROM tipo_liqui WHERE tipo_liqui_id IN $tipo_liquis_sql
                    AND NOT EXISTS (SELECT 1 FROM amparo_liqui b WHERE amparo_id = $amparo_id AND b.tipo_liqui_id = tipo_liqui.tipo_liqui_id)";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          $return['success'] = true;
        } else {
          $return['success'] = false;
          $return['error'] = "Error tratando de ingresar tipos de liquidación nuevas.  Por favor intente nuevamente.";
        }
      } else {
        $return['success'] = false;
        $return['error'] = "Error tratando de actualizar tipos de liquidación existentes.  Por favor intente nuevamente.";
      }
    } else {
      $return['success'] = false;
      $return['error'] = "Error tratando de eliminar tipos de liquidación antiguas.  Por favor intente nuevamente.";
    }
  }
  return json_encode($return);
}

include_once dirname(__FILE__) . '/../../general/sec_footer.php';
?>
