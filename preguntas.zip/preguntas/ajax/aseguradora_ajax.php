<?php

include_once dirname(__FILE__) . '/../../general/sec_ajax.php';
include_once dirname(__FILE__) . '/../../general/sec_header.php';

$accion = $_POST['accion'];
switch ($accion) {
  case 'cambiarActivo':
    echo cambiarActivo();
    break;

  case 'buscarAseguradora':
    echo buscarAseguradora();
    break;

  case 'listarAseguradoras':
    echo listarAseguradoras();
    break;

  case 'guardarAseguradora':
    echo guardarAseguradora();
    break;
}

function cambiarActivo() {
  global $mySQL;
  $return = array();
  $aseguradora_id = $_POST['aseguradora_id'];
  $valor = $_POST['valor'];
  $usuario_log = $_SESSION['preguntas_admin_user']['usuario_id'];
  $sql = "UPDATE aseguradora SET aseguradora_activo = '$valor', usuario_log = $usuario_log WHERE aseguradora_id = $aseguradora_id";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    $return['success'] = true;
  } else {
    $return['success'] = false;
    $return['error'] = 'Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
    //$return['error'] = $query['error'];
  }
  return json_encode($return);
}

function buscarAseguradora() {
  global $mySQL;
  $return = array();
  $aseguradora_id = $_POST['aseguradora_id'];
  $sql = "SELECT * FROM aseguradora WHERE aseguradora_id = $aseguradora_id";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      $return = $mySQL->fetch_assoc($query['result']);
      $return['success'] = true;
    } else {
      $return['success'] = false;
      $return['error'] = "Aseguradora no encontrado";
    }
  } else {
    $return['success'] = false;
    $return['error'] = 'Ocurrió un error al momento de consultar la información del aseguradora, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
    //$return['error'] = $query['error'];
  }
  return json_encode($return);
}

function listarAseguradoras() {
  global $mySQL;
  $filtro = $_POST['filtro'];

  $return = "";
  $sql = "SELECT aseguradora.*, elt(field(aseguradora.aseguradora_activo, 'S','N'), 'SI', 'NO') AS aseguradora_activo
          FROM aseguradora";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      $return = '
  <table style="width: 60%" id="tablaAseguradoras" class="tablesorter">
    <thead>
      <tr style="text-align:center;">
        <th>
          Nombre
        </th>
        <th>
          Activo
        </th>
        <th>
          &nbsp;
        </th>
      </tr>
    </thead>
    <tbody>';
      while ($row = $mySQL->fetch_assoc($query['result'])) {
        $trRow = "
        <tr>
          <td>$row[aseguradora_nombre]</td>
          <td style='text-align:center;'>$row[aseguradora_activo]</td>
          <td style='text-align:center;'>
            <a href='javascript:editarAseguradora(\"editar\", $row[aseguradora_id]);'><img src='images/b_edit.png'/></a>";
        if ($row['aseguradora_activo'] == 'SI') {
          $trRow .= "<a href='javascript:cambiarActivoAseguradora($row[aseguradora_id], \"N\");'><img src='images/turn_off.png'/></a>";
        } else {
          $trRow .= "<a href='javascript:cambiarActivoAseguradora($row[aseguradora_id], \"S\");'><img src='images/turn_on.png'/></a>";
        }
        $trRow .= "
          </td>
        </tr>";
        if (is_null($filtro) || empty($filtro) || strpos(strtolower($trRow), strtolower($filtro)) > 0) {
          $return .= $trRow;
        }
      }
      $return .= '
      </tbody>
  </table>';
    } else {
      $return = 'No existen aseguradoras en el sistema';
    }
  } else {
    $return = 'Se ha generado el siguiente error: ' . $query['error'];
  }
  return $return;
}

function guardarAseguradora() {
  global $mySQL;
  $return = array();
  $tipo = $_POST['tipo'];
  $aseguradora_id = $_POST['aseguradora_id'];
  $aseguradora_nombre = $_POST['aseguradora_nombre'];
  $usuario_log = $_SESSION['preguntas_admin_user']['usuario_id'];
  //die;
  if ($tipo == "nuevo") {
    $sql = "SELECT * FROM aseguradora WHERE aseguradora_nombre = '$aseguradora_nombre'";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $return['success'] = false;
        $return['error'] = "Ya existe una aseguradora con el nombre $aseguradora_nombre.  Por favor utilice uno diferente.";
      } else {
        $sql = "INSERT INTO aseguradora (aseguradora_nombre ,usuario_log, aseguradora_activo) VALUES('$aseguradora_nombre', $usuario_log, 'S')";
        $query = $mySQL->query($sql);
        $aseguradora_id = $mySQL->insert_id();
        if ($query['success']) {
          $return['success'] = true;
        } else {
          $return['success'] = false;
          $return['error'] = 'Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
          //$return['error'] = $query['error'];
        }
      }
    } else {
      $return['success'] = false;
      $return['error'] = 'Ocurrió un error al momento de consultar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
    }
  } else {
    $sql = "SELECT * FROM aseguradora WHERE aseguradora_nombre = '$aseguradora_nombre' AND aseguradora_id <> $aseguradora_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $return['success'] = false;
        $return['error'] = "Ya existe una aseguradora con el nombre $aseguradora_nombre.  Por favor utilice uno diferente.";
      } else {
        $sql = "UPDATE aseguradora SET aseguradora_nombre = '$aseguradora_nombre', usuario_log = $usuario_log WHERE aseguradora_id = $aseguradora_id";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          $return['success'] = true;
        } else {
          $return['success'] = false;
          $return['error'] = 'Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
          //$return['error'] = $query['error'];
        }
      }
    } else {
      $return['success'] = false;
      $return['error'] = 'Ocurrió un error al momento de consultar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
    }
  }
  return json_encode($return);
}

include_once dirname(__FILE__) . '/../../general/sec_footer.php';
?>
