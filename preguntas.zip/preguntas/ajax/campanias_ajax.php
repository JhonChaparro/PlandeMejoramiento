<?php

include_once dirname(__FILE__) . '/../../general/sec_ajax.php';
include_once dirname(__FILE__) . '/../../general/sec_header.php';

$accion = $_POST['accion'];
switch ($accion) {
  case 'cambiarActivo':
    echo cambiarActivo();
    break;

  case 'buscarCampania':
    echo buscarCampania();
    break;

  case 'listarCampanias':
    echo listarCampanias();
    break;

  case 'guardarCampanias':
    echo guardarCampanias();
    break;
}

function cambiarActivo() {
  global $mySQL;
  $return = array();
  $aseguradora_id = $_POST['aseguradora_id'];
  $valor = $_POST['valor'];
  $usuario_log = $_SESSION['preguntas_admin_user']['usuario_id'];
  $sql = "UPDATE aseguradora SET aseguradora_activo = '$valor', usuario_log = $usuario_log WHERE aseguradora_id = $aseguradora_id";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    $return['success'] = true;
  } else {
    $return['success'] = false;
    $return['error'] = 'Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
    //$return['error'] = $query['error'];
  }
  return json_encode($return);
}

function buscarCampania() {
  global $mySQL;
  $return = array();
  $campania_id = $_POST['campania_id'];
  $sql = "SELECT * FROM campania WHERE campania_id = $campania_id";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      $return = $mySQL->fetch_assoc($query['result']);
      $return['success'] = true;
    } else {
      $return['success'] = false;
      $return['error'] = "Campaña no encontrado";
    }
  } else {
    $return['success'] = false;
    $return['error'] = 'Ocurrió un error al momento de consultar la información del aseguradora, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
    //$return['error'] = $query['error'];
  }
  return json_encode($return);
}

function listarCampanias() {
  global $mySQL;
  $filtro = $_POST['filtro'];

  $return = "";
  $sql = "SELECT * FROM campania";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      $return = '
  <table style="width: 60%" id="tablaCampanias" class="tablesorter">
    <thead>
      <tr style="text-align:center;">
        <th>
          Nombre
        </th>
        <th>
          Llave
        </th>
        <th>
          &nbsp;
        </th>
      </tr>
    </thead>
    <tbody>';
      while ($row = $mySQL->fetch_assoc($query['result'])) {
        $trRow = "
        <tr>
          <td>$row[campania_nombre]</td>
          <td>$row[llave]</td>
          <td style='text-align:center;'>
            <a href='javascript:editarCampania(\"editar\", $row[campania_id]);'><img src='images/b_edit.png'/></a>
          </td>
        </tr>";
        if (is_null($filtro) || empty($filtro) || strpos(strtolower($trRow), strtolower($filtro)) > 0) {
          $return .= $trRow;
        }
      }
      $return .= '
      </tbody>
  </table>';
    } else {
      $return = 'No existen campañas en el sistema';
    }
  } else {
    $return = 'Se ha generado el siguiente error: ' . $query['error'];
  }
  return $return;
}

function guardarCampanias() {
  global $mySQL;
  $return = array();
  $tipo = $_POST['tipo'];
  $campania_id = $_POST['campania_id'];
  $campania_nombre = $_POST['campania_nombre'];
  $llave = $_POST['llave'];
  //die;
  if ($tipo == "nuevo") {
    $sql = "SELECT * FROM campania WHERE llave = '$llave'";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $return['success'] = false;
        $return['error'] = "Ya existe una campaña con la llave $llave.  Por favor utilice una diferente.";
      } else {
        $sql = "INSERT INTO campania (campania_nombre , llave) VALUES('$campania_nombre', '$llave')";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          $return['success'] = true;
        } else {
          $return['success'] = false;
          $return['error'] = 'Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
          //$return['error'] = $query['error'];
        }
      }
    } else {
      $return['success'] = false;
      $return['error'] = 'Ocurrió un error al momento de consultar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
    }
  } else {
    $sql = "SELECT * FROM campania WHERE campania_nombre = '$campania_nombre' AND campania_id <> $campania_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $return['success'] = false;
        $return['error'] = "Ya existe una campaña con la llave $llave.  Por favor utilice uno diferente.";
      } else {
        $sql = "UPDATE campania SET campania_nombre = '$campania_nombre', llave = '$llave' WHERE campania_id = $campania_id";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          $return['success'] = true;
        } else {
          $return['success'] = false;
          $return['error'] = 'Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
          //$return['error'] = $query['error'];
        }
      }
    } else {
      $return['success'] = false;
      $return['error'] = 'Ocurrió un error al momento de consultar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
    }
  }
  return json_encode($return);
}

include_once dirname(__FILE__) . '/../../general/sec_footer.php';
?>
