<?php

include_once dirname(__FILE__) . '/../../general/sec_header.php';
$accion = $_POST['accion'];
switch ($accion) {
  case 'aplicarCambios':
    echo aplicarCambios($mySQL);
    break;
  case 'buscarConfiguracion':
    echo buscarConfiguracion($mySQL);
    break;
}

function aplicarCambios($mySQL) {
  $config_ids = $_POST['config_ids'];
  $config_valores = $_POST['config_valores'];
  $usuario_log = $_SESSION['preguntas_admin_user']['usuario_id'];
  $return = array();

  foreach ($config_ids as $key => $value) {
    $sql = "SELECT * FROM empresa_config WHERE config_id = $value";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $arrIns[] = "UPDATE empresa_config SET valor = '$config_valores[$key]', usuario_log = $usuario_log, fec_cambio = CURDATE() WHERE config_id = $value";
      } else {
        $arrIns[] = "INSERT INTO empresa_config (config_id, valor, usuario_log, fec_cambio) VALUES ($value, '$config_valores[$key]', $usuario_log, CURDATE())";
      }
    } else {
      $return['success'] = false;
      $return['error'] = 'Ocurrió un error al consultar la Configuración de la empresa, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
    }
  }

  $success = true;
  foreach ($arrIns as $i => $sql) {
    $query = $mySQL->query($sql);
    if (!$query['success']) {
      $success = false;
      break;
    }
  }

  if ($success) {
    $return['success'] = true;
    $return['message'] = "Los cambios han sido aplicados correctamente!";
    if (!empty($_SESSION['hide_menu'])) {
      unset($_SESSION['hide_menu']);
      $return['forward'] = "default_login";
    }
  } else {
    $return['success'] = false;
    $return['error'] = 'Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
    //$return['error'] = $query['error'];
  }


  return json_encode($return);
}

function buscarConfiguracion($mySQL) {
  $return = array();
  $sql = "SELECT * FROM empresa_config";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      while ($row = $mySQL->fetch_assoc($query['result'])) {
        $return[$row[config_id]] = $row[valor];
        $return['success'] = true;
      }
    }
  } else {
    $return['success'] = false;
    $return['error'] = 'Ocurrió un error al momento de consultar la información del cliente, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
    //$return['error'] = $query['error'];
  }
  return json_encode($return);
}

?>