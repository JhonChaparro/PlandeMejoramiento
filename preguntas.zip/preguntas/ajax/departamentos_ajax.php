<?php

include_once dirname(__FILE__) . '/../../general/sec_ajax.php';
include_once dirname(__FILE__) . '/../../general/sec_header.php';

$accion = $_POST['accion'];
switch ($accion) {
  case 'listarDepartamentos':
    echo listarDepartamentos();
    break;

  case 'cambiarEstado':
    echo cambiarEstado();
    break;
}

function cambiarEstado() {
  global $mySQL;
  $return = array();
  $arrIns = array();

  $sql = "SELECT * FROM departamento WHERE departamento_activo = 'S'";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      while ($row = $mySQL->fetch_assoc($query['result'])) {
        $departamento_id = $_POST['check_desac_' . $row['departamento_id']];
        if (!empty($departamento_id)) {
          $arrIns[] = "UPDATE departamento SET departamento_activo = 'N' WHERE departamento_id = $departamento_id";
        }
      }
    }
  }

  $sql = "SELECT * FROM departamento WHERE departamento_activo = 'N'";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      while ($row = $mySQL->fetch_assoc($query['result'])) {
        $departamento_id = $_POST['check_acti_' . $row['departamento_id']];
        if (!empty($departamento_id)) {
          $arrIns[] = "UPDATE departamento SET departamento_activo = 'S' WHERE departamento_id = $departamento_id";
        }
      }
    }
  }

  foreach ($arrIns as $i => $sql) {
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $return['success'] = true;
    } else {
      $return['success'] = false;
      $return['error'] = 'Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
      break;
    }
  }
  return json_encode($return);
}

function listarDepartamentos() {
  global $mySQL;
  $filtro = $_POST['filtro'];

  $return = "";
  $sql = "SELECT *, elt(field(departamento_activo, 'S','N'), 'SI', 'NO') AS departamento_activo 
          FROM departamento";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      $return = '
  <table style="width: 60%" id="tablaDepartamentos" class="tablesorter">
    <thead>
      <tr style="text-align:center;">
        <th>
          Departamento
        </th>
        <th>
          Activo
        </th>
        <th>
          &nbsp;
        </th>
      </tr>
    </thead>
    <tbody>';
      while ($row = $mySQL->fetch_assoc($query['result'])) {
        $trRow = "
        <tr>
          <td>$row[departamento_nombre]</td>
          <td>$row[departamento_activo]</td>
          <td style='text-align:center;'>";
        if ($row['departamento_activo'] == 'SI') {
          $trRow .= "<input type='checkbox' name='check_desac' id='check_desac_" . $row[departamento_id] . "' value='" . $row[departamento_id] . "'/>";
        } else {
          $trRow .= "<input type='checkbox' name='check_acti' id='check_acti_" . $row[departamento_id] . "' value='" . $row[departamento_id] . "'/>";
        }
        $trRow .= "
          </td>
        </tr>";
        if (is_null($filtro) || empty($filtro) || strpos(strtolower($trRow), strtolower($filtro)) > 0) {
          $return .= $trRow;
        }
      }
      $return .= '
      </tbody>
  </table>';
    } else {
      $return = 'No existen departamentos en el sistema';
    }
  } else {
    $return = 'Se ha generado el siguiente error: ' . $query['error'];
  }
  return $return;
}

include_once dirname(__FILE__) . '/../../general/sec_footer.php';
?>
