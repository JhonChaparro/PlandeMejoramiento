<?php

include_once dirname(__FILE__) . '/../../general/sec_ajax.php';
include_once dirname(__FILE__) . '/../../general/sec_header.php';

$accion = $_POST['accion'];
switch ($accion) {
  case 'listarCampanias':
    echo listarCampanias();
    break;
}

function listarCampanias() {
  global $mySQL;
  $return = array();
  $fec_inicio = $_POST["fec_inicio"];
  $fec_final = $_POST["fec_final"];

  $sql = "SELECT campania.*, COUNT(poliza.campania_id) cantidad 
          FROM campania
          LEFT JOIN poliza USING (campania_id)
          WHERE poliza.poliza_estado_id IN (6,7)";

  if (!empty($fec_inicio)) {
    $sql .= " AND poliza.fec_registro >= '$fec_inicio'";
  }
  if (!empty($fec_final)) {
    $sql .= " AND poliza.fec_registro <= '$fec_final'";
  }
  $sql .= " GROUP BY poliza.campania_id";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      $return = '
  <table style="width: 100%" id="tablaCampanias" class="tablesorter">
    <thead>
      <tr style="text-align:center;">
        <th>
          Campaña
        </th>
        <th>
          Cantidad de polizas por campaña
        </th>
      </tr>
    </thead>
    <tbody>';
      while ($row = $mySQL->fetch_assoc($query['result'])) {
        $trRow = "
        <tr>
          <td>$row[campania_nombre]</td>
          <td style='text-align:center;'>$row[cantidad]</td>
        </tr>";
        if (is_null($filtro) || empty($filtro) || strpos(strtolower($trRow), strtolower($filtro)) > 0) {
          $return .= $trRow;
        }
      }
      $return .= '
      </tbody>
  </table>';
    } else {
      $return = 'No existen campañas para ese rango de fechas';
    }
  } else {
    $return = 'Se ha generado el siguiente error: ' . $query['error'];
  }
  return $return;
}

include_once dirname(__FILE__) . '/../../general/sec_footer.php';
?>