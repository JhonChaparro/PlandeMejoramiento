<?php

$path = dirname(__FILE__);
include_once $path . '/../general/sec_ajax.php';
include_once $path . '/../general/sec_header.php';
include_once $path . '/../general/Tools.php';

$accion = $_POST['accion'];
switch ($accion) {
  case 'recuperarContrasena':
    echo recuperarContrasena();
    break;

  case 'iniciarSesion':
    echo iniciarSesion();
    break;
}

function iniciarSesion() {
    global $mySQL;
    global $configVars;
    $tools = new Tools();
    $usuario_email = $_POST['email'];
    $usuario_passwd = $_POST['password'];
    $response = '';
    unset($_SESSION['preguntas_admin_user']);
    unset($_SESSION['preguntas_admin_menu']);
    $return = array();

    if (isset($usuario_email) && !empty($usuario_email) && isset($usuario_passwd) && !empty($usuario_passwd)) {
      if (strpos($usuario_email, "'") === false && strpos($usuario_passwd, "'") === false) {
        $sql = "SELECT *
              FROM usuarios 
              WHERE email = '$usuario_email' AND password = MD5('$usuario_passwd') AND estado = 'A'";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          if ($mySQL->num_rows($query['result']) > 0) {
            $usuario = $mySQL->fetch_assoc($query['result']);
            $usuario['password'] = "";

            $_SESSION['preguntas_admin_user'] = $usuario;
            $sql = "SELECT DISTINCT opciones.*, menus.menu_nombre, menus.menu_orden 
                    FROM opciones 
                    JOIN opciones_roles USING(opcion_id) 
                    JOIN menus USING(menu_id)
                    JOIN usuarios USING(rol_id) 
                    WHERE rol_id = " . $usuario['rol_id'] . " AND opcion_rol_activo = 'S' 
                    ORDER BY menu_orden, opcion_orden";
            $query = $mySQL->query($sql);
            if ($query['success']) {
              $menu_array = array();
              while ($row = mysql_fetch_assoc($query['result'])) {
                if (!array_key_exists($row['menu_orden'], $menu_array)) {
                  $menu_array[$row['menu_orden']] = array();
                  $menu_array[$row['menu_orden']]['menu_nombre'] = $row['menu_nombre'];
                  $menu_array[$row['menu_orden']]['menu_id'] = $row['menu_id'];
                  $menu_array[$row['menu_orden']]['opciones'] = array();
                }
                $menu_array[$row['menu_orden']]['opciones'][] = $row;
              }
              $menuHTML = '';
              foreach ($menu_array as $menu_orden => $menu) {
                $menuHTML .= '<li><a>' . $menu['menu_nombre'] . '</a><ul>';
                foreach ($menu['opciones'] as $opcion_orden => $opcion) {
                  $menuHTML .= "<li><a href='" . $opcion['opcion_url'] . "'>" . $opcion['opcion_nombre'] . "</a></li>";
                }
                $menuHTML .= '  </ul>
                    </li>';
              }
              $menuHTML .= '<li><a href="logout.php">Cerrar sesión</a></li>';
              $_SESSION['preguntas_admin_menu'] = $menuHTML;
              $return['success'] = true;
            } else {
              $return['success'] = false;
              $return['error'] = $query['error'];
              unset($_SESSION['preguntas_admin_user']);
            }
          } else {
            $return['success'] = false;
            $return['error'] = 'El usuario o contraseña no coinciden';
          }
        } else {
          $return['success'] = false;
          $return['error'] = "Ha ocurrido un error tratando de iniciar sesión, por favor intente nuevamente";
        }
      } else {
        $return['success'] = false;
        $return['error'] = 'El usuario o contraseña no pueden contener comilla';
      }
    } else {
      $return['success'] = false;
      $return['error'] = 'El usuario y la contraseña son requeridos';
    }
    return json_encode($return, JSON_UNESCAPED_UNICODE);
  }

function recuperarContrasena() {
  global $mySQL;
  global $configVars;
  $usuario_osc = $_POST['usuario_osc'];
  $return = array();
  $sql = "SELECT * FROM usuario WHERE usuario_email = '$usuario_osc'";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      $row = $mySQL->fetch_assoc($query['result']);
      if ($row['usuario_activo'] == 'S') {

        $tools = new Tools();
        $domain_name = $configVars['server.name'];
        $params = array();
        $params['P_USUARIO_NOMBRE'] = $row['usuario_nombre'];
        $new_password = $tools->getRandowPassword(10);
        $sql = "UPDATE usuario SET usuario_passwd = MD5('$new_password'), usuario_fec_cp = CURDATE() WHERE usuario_id = $row[usuario_id]";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          $params['P_NEW_PW'] = $new_password;
          $return = $tools->loadTemplate('osc.html', $params);
          if ($return['success']) {
            $message = $return['content'];
            $params = array();
            $params['P_DOMAIN_NAME'] = $domain_name;
            $params['P_LOGO'] = $configVars['mail.logo'];
            $return = $tools->loadTemplate('footer.html', $params);
            if ($return['success']) {
              $message .= $return['content'];
              $subject = "Recuperación de contraseña";
              $to = $row['usuario_email'];
              $return = $tools->sendEmail($subject, $message, NULL, NULL, NULL, $to);
              if ($return['success']) {
                $return['message'] = "Se ha enviado un correo electronico a $to indicando los pasos para reestablecer la contraseña!";
              }
            }
          } else {
            $return['success'] = false;
            $return['error'] = "Error al tratar de cargar la plantilla de correo.  Por favor comuniquese con el administrador del sistema";
          }
        } else {
          return $query;
        }
      } else {
        $return['success'] = false;
        $return['error'] = "El usuario esta desactivado.  Por favor comuniquese con el administrador del sistema";
      }
    } else {
      $return['success'] = false;
      $return['error'] = "El usuario no existe en el sistema";
    }
  } else {
    $return = $query;
  }
  return json_encode($return);
}

require_once $path . '/../../general/sec_footer.php';

