<?php

include_once dirname(__FILE__) . '/../../general/sec_ajax.php';
include_once dirname(__FILE__) . '/../../general/sec_header.php';

$accion = $_POST['accion'];
switch ($accion) {
  case 'listarMunicipios':
    echo listarMunicipios();
    break;

  case 'cambiarEstado':
    echo cambiarEstado();
    break;
}

function cambiarEstado() {
  global $mySQL;
  $departamento_id = $_POST['departamento_id'];
  $return = array();
  $arrIns = array();

  $sql = "SELECT * FROM municipio WHERE municipio_activo = 'S' AND departamento_id = $departamento_id";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      while ($row = $mySQL->fetch_assoc($query['result'])) {
        $municipio_id = $_POST['check_desac_' . $row['municipio_id']];
        if (!empty($municipio_id)) {
          $arrIns[] = "UPDATE municipio SET municipio_activo = 'N' WHERE municipio_id = $municipio_id";
        }
      }
    }
  }

  $sql = "SELECT * FROM municipio WHERE municipio_activo = 'N' AND departamento_id = $departamento_id";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      while ($row = $mySQL->fetch_assoc($query['result'])) {
        $municipio_id = $_POST['check_acti_' . $row['municipio_id']];
        if (!empty($municipio_id)) {
          $arrIns[] = "UPDATE municipio SET municipio_activo = 'S' WHERE municipio_id = $municipio_id";
        }
      }
    }
  }

  foreach ($arrIns as $i => $sql) {
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $return['success'] = true;
    } else {
      $return['success'] = false;
      $return['error'] = 'Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
      break;
    }
  }
  return json_encode($return);
}

function listarMunicipios() {
  global $mySQL;
  $departamento_id = $_POST['departamento_id'];

  $return = "";
  $sql = "SELECT *, elt(field(municipio_activo, 'S','N'), 'SI', 'NO') AS municipio_activo 
          FROM municipio WHERE departamento_id = $departamento_id";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      $return = '
  <table style="width: 60%" id="tablaDepartamentos" class="tablesorter">
    <thead>
      <tr style="text-align:center;">
        <th>
          Municipio
        </th>
        <th>
          Activo
        </th>
        <th>
          &nbsp;
        </th>
      </tr>
    </thead>
    <tbody>';
      while ($row = $mySQL->fetch_assoc($query['result'])) {
        $trRow = "
        <tr>
          <td>$row[municipio_nombre]</td>
          <td>$row[municipio_activo]</td>
          <td style='text-align:center;'>";
        if ($row['municipio_activo'] == 'SI') {
          $trRow .= "<input type='checkbox' name='check_desac' id='check_desac_" . $row[municipio_id] . "' value='" . $row[municipio_id] . "'/>";
        } else {
          $trRow .= "<input type='checkbox' name='check_acti' id='check_acti_" . $row[municipio_id] . "' value='" . $row[municipio_id] . "'/>";
        }
        $trRow .= "
          </td>
        </tr>";
        if (is_null($filtro) || empty($filtro) || strpos(strtolower($trRow), strtolower($filtro)) > 0) {
          $return .= $trRow;
        }
      }
      $return .= '
      </tbody>
  </table>';
    } else {
      $return = 'No existen municipios para este departamento';
    }
  } else {
    $return = 'Se ha generado el siguiente error: ' . $query['error'];
  }
  return $return;
}

include_once dirname(__FILE__) . '/../../general/sec_footer.php';
?>
