<?php

include_once dirname(__FILE__) . '/../../general/sec_ajax.php';
include_once dirname(__FILE__) . '/../../general/sec_header.php';

$accion = $_POST['accion'];
switch ($accion) {
  case 'listarRegistros':
    echo listarRegistros();
    break;

  case 'editarRol':
    echo editarRol();
    break;

  case 'guardarRol':
    echo guardarRol();
    break;
}

function listarRegistros() {
  global $mySQL;
  $sql = "SELECT opcion.*, menu.menu_nombre, menu.menu_orden FROM opcion JOIN menu USING(menu_id) ORDER BY menu_orden, opcion_orden";
  $query = $mySQL->query($sql);
  $menus = array();
  if ($query['success']) {
    $menuHTML = '
<table id="tablaLista" class="tablesorter" style="width: 100%">
  <thead>
    <tr>
      <th>Menú</th>
      <th>Opci&oacute;n</th>
      <th>Roles</th>
      <th>&nbsp;</th>
    </tr>
  </thead>
  <tbody>
';
    while ($row = mysql_fetch_assoc($query['result'])) {
       $menuHTML .= '
    <tr>
      <td>' . $row['menu_nombre'] . '</td>
      <td>' . $row['opcion_nombre'] . '</td>
      <td>';
      $sql = "SELECT * FROM rol JOIN opcion_rol USING(rol_id) WHERE opcion_id = $row[opcion_id] AND opcion_rol_activo = 'S' ORDER BY rol_nombre";
      $query_rol = $mySQL->query($sql);
      if ($query['success']) {
        $cont_roles = 0;
        while ($row_rol = mysql_fetch_assoc($query_rol['result'])) {
          if($cont_roles > 0){
            $menuHTML .= '<br/>';
          }
          $menuHTML .= $row_rol['rol_nombre'];
          $cont_roles++;
        }
      }
      else{
        return json_encode($query_rol);
      }
      $menuHTML .= '</td>
      <td><a href="javascript:editarRol(' . $row['opcion_id'] . ');"><img src="images/b_edit.png"/></a></td>
    </tr>';
    }
    $menuHTML .= '
  </tbody>
</table>';
    $return = array();
    $return['success'] = true;
    $return['message'] = $menuHTML;
    return json_encode($return);
  } else {
    return json_encode($query);
  }
}

function editarRol() {
  global $mySQL;
  $opcion_id = $_POST['opcion_id'];
  $return = array();
  $sql = "SELECT menu_nombre, opcion_nombre FROM opcion JOIN menu USING (menu_id) WHERE opcion_id = $opcion_id";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    $return = $mySQL->fetch_assoc($query['result']);
    $roles = array();
    $sql = "SELECT rol_id FROM opcion_rol WHERE opcion_id = $opcion_id AND opcion_rol_activo = 'S'";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $roles = array();
      if ($mySQL->num_rows($query['result']) > 0) {
        while ($row = $mySQL->fetch_assoc($query['result'])) {
          $roles[] = $row['rol_id'];
        }
      }
      $return['success'] = true;
      $return['roles'] = $roles;
    } else {
      $return = $query;
    }
  } else {
    $return = $query;
  }
  return json_encode($return);
}

function guardarRol() {
  global $mySQL;
  $return = array();
  $opcion_id = $_POST['opcion_id'];
  $roles = $_POST['roles'];
  $usuario_log = $_SESSION['preguntas_admin_user']['usuario_id'];
  $valores = '';
  if (count($roles) > 0) {
    $valores = '(';
    $count = 1;
    foreach ($roles as $value) {
      $valores .= $value;
      if ($count < count($roles)) {
        $valores .= ', ';
      }
      $count++;
    }
    $valores .= ')';
  } else {
    $valores = '(0)';
  }
  $sql = "UPDATE opcion_rol SET opcion_rol_activo = 'N', usuario_log = $usuario_log WHERE opcion_id = $opcion_id AND rol_id NOT IN $valores";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    $sql = "UPDATE opcion_rol SET opcion_rol_activo = 'S', usuario_log = $usuario_log WHERE opcion_id = $opcion_id AND rol_id IN $valores";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $sql = "INSERT INTO opcion_rol (rol_id, opcion_id, usuario_log, opcion_rol_activo)
SELECT rol.rol_id, $opcion_id, $usuario_log, 'S'
FROM rol WHERE NOT EXISTS(SELECT 1 FROM opcion_rol WHERE opcion_rol.rol_id = rol.rol_id AND opcion_id = $opcion_id)
AND rol.rol_id IN $valores";
      $return = $mySQL->query($sql);
    } else {
      $return = $query;
    }
  } else {
    $return = $query;
  }
  return json_encode($return);
}
include_once dirname(__FILE__) . '/../../general/sec_footer.php';
?>