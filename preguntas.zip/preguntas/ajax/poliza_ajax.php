<?php

include_once dirname(__FILE__) . '/../../general/sec_ajax.php';
include_once dirname(__FILE__) . '/../../general/sec_header.php';
include_once dirname(__FILE__) . '/../../model/Poliza.php';

$action = $_REQUEST['action'];

$poliza = new Poliza();
switch ($action) {
  case 'crearPoliza':
    echo json_encode($poliza->crearPoliza(), JSON_UNESCAPED_UNICODE);
    break;

  case 'cargarAdjunto':
    $clasif_docum = $_REQUEST['clasif_docum'];
    if (empty($clasif_docum)) {
      echo json_encode($poliza->cargarAdjunto(), JSON_UNESCAPED_UNICODE);
    } else {
      echo json_encode($poliza->cargarAdjunto($clasif_docum), JSON_UNESCAPED_UNICODE);
    }
    break;

  case 'listarAdjuntos':
    $clasif_docum = $_REQUEST['clasif_docum'];
    if (empty($clasif_docum)) {
      echo json_encode($poliza->listarAdjuntos(), JSON_UNESCAPED_UNICODE);
    } else {
      echo json_encode($poliza->listarAdjuntos($clasif_docum), JSON_UNESCAPED_UNICODE);
    }
    break;

  case 'cargarMunicipios':
    echo json_encode($poliza->cargarMunicipios(), JSON_UNESCAPED_UNICODE);
    break;

  case 'actualizarMunicipio':
    echo json_encode($poliza->actualizarMunicipio(), JSON_UNESCAPED_UNICODE);
    break;

  case 'cargarGarantias':
    echo json_encode($poliza->cargarGarantias(), JSON_UNESCAPED_UNICODE);
    break;

  case 'actualizarGarantias':
    echo json_encode($poliza->actualizarGarantias(), JSON_UNESCAPED_UNICODE);
    break;

  case 'buscarMunicipios':
    echo json_encode($poliza->buscarMunicipios(), JSON_UNESCAPED_UNICODE);
    break;

  case 'calcularFinVigencia':
    echo json_encode($poliza->calcularFinVigencia(), JSON_UNESCAPED_UNICODE);
    break;

  case 'actualizarFechas':
    echo json_encode($poliza->actualizarFechas(), JSON_UNESCAPED_UNICODE);
    break;

  case 'guardarAseguradora':
    echo json_encode($poliza->guardarAseguradora(), JSON_UNESCAPED_UNICODE);
    break;

  case 'actualizarInfoPoliza':
    echo json_encode($poliza->actualizarInfoPoliza(), JSON_UNESCAPED_UNICODE);
    break;

  case 'actualizarAfianzado':
    echo json_encode($poliza->actualizarAfianzado(), JSON_UNESCAPED_UNICODE);
    break;

  case 'actualizarDepartamento':
    echo json_encode($poliza->actualizarDepartamento(), JSON_UNESCAPED_UNICODE);
    break;

  case 'eliminarAsegurado':
    echo json_encode($poliza->eliminarAsegurado(), JSON_UNESCAPED_UNICODE);
    break;

  case 'agregarBeneficiario':
    echo json_encode($poliza->agregarBeneficiario(), JSON_UNESCAPED_UNICODE);
    break;

  case 'eliminarAmparo':
    echo json_encode($poliza->eliminarAmparo(), JSON_UNESCAPED_UNICODE);
    break;

  case 'cargarAmparos':
    echo json_encode($poliza->cargarAmparos(), JSON_UNESCAPED_UNICODE);
    break;

  case 'calcularFechaFinVigencias':
    echo json_encode($poliza->calcularFechaFinVigencias(), JSON_UNESCAPED_UNICODE);
    break;

  case 'buscarAmparosGarantia':
    echo json_encode($poliza->buscarAmparosGarantia(), JSON_UNESCAPED_UNICODE);
    break;

  case 'guardarAmparos':
    echo json_encode($poliza->guardarAmparos(), JSON_UNESCAPED_UNICODE);
    break;

  case 'cambiarEstadoDocumentos':
    echo json_encode($poliza->cambiarEstadoDocumentos(), JSON_UNESCAPED_UNICODE);
    break;

  case 'buscarAsegurado':
    echo json_encode($poliza->buscarAsegurado(), JSON_UNESCAPED_UNICODE);
    break;

  case 'buscarAmparo':
    echo json_encode($poliza->buscarAmparo(), JSON_UNESCAPED_UNICODE);
    break;

  case 'eliminarGarantia':
    echo json_encode($poliza->eliminarGarantia(), JSON_UNESCAPED_UNICODE);
    break;

  case 'validarPoliza':
    echo json_encode($poliza->validarPoliza(), JSON_UNESCAPED_UNICODE);
    break;

  case 'actializarPolizaEmitida':
    echo json_encode($poliza->actializarPolizaEmitida(), JSON_UNESCAPED_UNICODE);
    break;

  case 'actializarPolizaEmitida':
    echo json_encode($poliza->actializarPolizaEmitida(), JSON_UNESCAPED_UNICODE);
    break;

  case 'actualizarAseguradora':
    echo json_encode($poliza->actualizarAseguradora(), JSON_UNESCAPED_UNICODE);
    break;

  case 'listarPolizasTramite':
    echo json_encode($poliza->listarPolizasTramite(), JSON_UNESCAPED_UNICODE);
    break;
}