<?php

include_once dirname(__FILE__) . '/../../general/sec_ajax.php';
include_once dirname(__FILE__) . '/../../general/sec_header.php';

$accion = $_REQUEST['accion'];

switch ($accion) {
  case 'listarPolizas':
    echo listarPolizas();
    break;
}

function listarPolizas() {
  global $mySQL;
  $identificacion = $_POST['identificacion'];
  $ref_contrato = $_POST['ref_contrato'];
  $estado_id = $_POST['estado_id'];
  $email = $_POST['email'];

  $return = '<table class="form-table corner-round tablesorter" align= "center" id="tablaPolizas">'
          . ' <thead>'
          . '     <tr align="center">'
          . '         <th>Municipio</th>'
          . '         <th>Afianzado</th>'
          . '         <th>Ref Contrato</th>'
          . '         <th>Email</th>'
          . '         <th>Estado</th>'
          . '         <th>Ultima Actualización</th>'
          . '         <th></th>'
          . '     </tr>'
          . ' </thead>';
  $sql = " SELECT poliza.*, poliza_estado.poliza_estado_nombre, CONCAT(municipio.municipio_nombre,' - ',departamento.departamento_nombre) municipio
              FROM poliza
              INNER JOIN poliza_estado USING (poliza_estado_id)
              INNER JOIN municipio USING (municipio_id)
              INNER JOIN departamento ON (departamento.departamento_id = municipio.departamento_id)
              WHERE 1=1 ";
  if (!empty($identificacion)) {
    $sql .= " AND poliza.identificacion = '$identificacion'";
  }
  if (!empty($ref_contrato)) {
    $sql .= " AND poliza.ref_contrato = '$ref_contrato'";
  }
  if (!empty($email)) {
    $sql .= " AND poliza.email = '$email'";
  }
  if (!empty($estado_id)) {
    $sql .= " AND poliza.poliza_estado_id = $estado_id";
  }  else {
    $sql .= " AND poliza.poliza_estado_id IN (3,7)";
  }
  $sql .= " ORDER BY poliza.fec_estado DESC";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      $return .= '<tbody>';
      while ($row = $mySQL->fetch_assoc($query['result'])) {
        $return .= '<tr>';
        $return .= '<td>' . $row[municipio] . '</td>';
        $return .= '<td>' . $row[nombres] . '</td>';
        $return .= '<td>' . $row[fec_contrato] . '</td>';
        $return .= '<td>' . $row[email] . '</td>';
        $return .= '<td>' . $row[poliza_estado_nombre] . '</td>';
        $return .= '<td>' . $row[fec_estado] . '</td>';
        $return .= '<td><a href="poliza_form?poliza_id=' . $row[poliza_id] . '" target="_blank"><img src="images/b_log.png" width="30"/></a> </td>'
                . '</tr>';
      }
      $return .= '</tbody>';
    } else {
      $return = 'No se han encontrado polizas con esos criterios de búsqueda.';
    }
  }
  $return .= '</table>';
  return $return;
}

include_once dirname(__FILE__) . '/../../general/sec_footer.php';
?>
