<?php

include_once dirname(__FILE__) . '/../../general/sec_ajax.php';
include_once dirname(__FILE__) . '/../../general/sec_header.php';
include_once dirname(__FILE__) . '/../../model/Referidos.php';

$accion = $_REQUEST['accion'];
$ref = new Referidos();
switch ($accion) {

  case 'cambiarEstadoReferidos':
    echo json_encode($ref->cambiarEstadoReferidos(), JSON_UNESCAPED_UNICODE);
    break;
  
    case 'filtrarPagosRealizados':
    echo json_encode($ref->filtrarPagosRealizados(), JSON_UNESCAPED_UNICODE);
    break;
  case 'buscarReferidores':
    echo json_encode($ref->buscarReferidores(), JSON_UNESCAPED_UNICODE);
    break;
}