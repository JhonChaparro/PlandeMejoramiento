<?php

include_once dirname(__FILE__) . '/../../general/sec_ajax.php';
include_once dirname(__FILE__) . '/../../general/sec_header.php';

$accion = $_POST['accion'];
switch ($accion) {
  case 'listarPolizasEmitidas':
    echo listarPolizasEmitidas();
    break;
}

function listarPolizasEmitidas() {
  global $mySQL;
  $return = array();
  $fec_inicio_crea = $_POST["fec_inicio_crea"];
  $fec_final_crea = $_POST["fec_final_crea"];
  $fec_inicio_exp = $_POST["fec_inicio_exp"];
  $fec_final_exp = $_POST["fec_final_exp"];
  $aseguradora_id = $_POST["aseguradora_id"];

  $sql = "SELECT poliza.ref_contrato, poliza.fec_registro, poliza_aseguradora.fec_poliza, aseguradora.aseguradora_nombre, garantia.garantia_nombre, poliza_aseguradora.prima, poliza_aseguradora.expedicion, poliza_aseguradora.impuesto, poliza_aseguradora.total
          FROM poliza
          INNER JOIN poliza_aseguradora USING (poliza_id)
          INNER JOIN aseguradora ON (poliza_aseguradora.aseguradora_id = aseguradora.aseguradora_id)
          INNER JOIN garantia USING (garantia_id)
          WHERE poliza_aseguradora.es_seleccionada = 'S'";

  if (!empty($aseguradora_id)) {
    $sql .= " AND aseguradora.aseguradora_id = $aseguradora_id";
  }
  if (!empty($fec_inicio_crea)) {
    $sql .= " AND poliza.fec_registro >= '$fec_inicio_crea'";
  }
  if (!empty($fec_final_crea)) {
    $sql .= " AND poliza.fec_registro <= '$fec_final_crea'";
  }
  if (!empty($fec_inicio_crea)) {
    $sql .= " AND poliza_aseguradora.fec_poliza >= '$fec_inicio_exp'";
  }
  if (!empty($fec_final_crea)) {
    $sql .= " AND poliza_aseguradora.fec_poliza <= '$fec_final_exp'";
  }
  
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      $return = '
  <table style="width: 100%" id="tablaEmitidas" class="tablesorter">
    <thead>
      <tr style="text-align:center;">
        <th>
          Referencia del contrato
        </th>
        <th>
          Fecha de creación de la póliza
        </th>
        <th>
          Fecha de emisión de la póliza
        </th>
        <th>
          Aseguradora
        </th>
        <th>
          Garantia
        </th>
        <th>
          Valor prima
        </th>
        <th>
          Valor expedicion
        </th>
        <th>
          Valor impuesto
        </th>
        <th>
          Valor total
        </th>
      </tr>
    </thead>
    <tbody>';
      while ($row = $mySQL->fetch_assoc($query['result'])) {
        $trRow = "
        <tr>
          <td>$row[ref_contrato]</td>
          <td>$row[fec_registro]</td>
          <td>$row[fec_poliza]</td>
          <td>$row[aseguradora_nombre]</td>
          <td>$row[garantia_nombre]</td>
          <td>$row[prima]</td>
          <td>$row[expedicion]</td>
          <td>$row[impuesto]</td>
          <td>$row[total]</td>
        </tr>";
        if (is_null($filtro) || empty($filtro) || strpos(strtolower($trRow), strtolower($filtro)) > 0) {
          $return .= $trRow;
        }
      }
      $return .= '
      </tbody>
  </table>';
    } else {
      $return = 'No existen polizas emitidas con esas caracteristicas';
    }
  } else {
    $return = 'Se ha generado el siguiente error: ' . $query['error'];
  }
  return $return;
}

include_once dirname(__FILE__) . '/../../general/sec_footer.php';
?>