<?php

include_once dirname(__FILE__) . '/../../general/sec_ajax.php';
include_once dirname(__FILE__) . '/../../general/sec_header.php';

$accion = $_POST['accion'];
switch ($accion) {
  case 'buscarRol':
    echo buscarRol();
    break;

  case 'listarRoles':
    echo listarRoles();
    break;

  case 'guardarRol':
    echo guardarRol();
    break;
}

function buscarRol() {
  global $mySQL;
  $return = array();
  $rol_id = $_POST['rol_id'];
  $sql = "SELECT * FROM rol WHERE rol_id = $rol_id";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result'])) {
      $return = $mySQL->fetch_assoc($query['result']);
      $roles = array();
      $sql = "SELECT opcion_id FROM opcion_rol WHERE rol_id = $rol_id AND opcion_rol_activo = 'S'";
      $query = $mySQL->query($sql);
      if ($query['success']) {
        $roles = array();
        if ($mySQL->num_rows($query['result']) > 0) {
          while ($row = $mySQL->fetch_assoc($query['result'])) {
            $roles[] = $row['opcion_id'];
          }
        }
        $return['success'] = true;
        $return['opciones'] = $roles;
      } else {
        $return = $query;
      }
    } else {
      $return['success'] = false;
      $return['error'] = "Rol no encontrado";
    }
  } else {
    $return = $query;
  }
  return json_encode($return);
}

function listarRoles() {
  global $mySQL;
  $filtro = $_POST['filtro'];

  $return = "";
  $sql = "SELECT * FROM rol";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      $return = '
  <table style="width: 30%" id="tablaRoles" class="tablesorter">
    <thead>
      <tr style="text-align:center;">
        <th>
          Rol
        </th>
        <th>
          &nbsp;
        </th>
      </tr>
    </thead>
    <tbody>';
      while ($row = $mySQL->fetch_assoc($query['result'])) {
        $trRow = "
        <tr>
          <td>$row[rol_nombre]</td>
          <td style='text-align:center;'>
            <a href='javascript:editarRol(\"editar\", $row[rol_id]);'><img src='images/b_edit.png'/></a>
          </td>
        </tr>";
        if (is_null($filtro) || empty($filtro) || strpos(strtolower($trRow), strtolower($filtro)) > 0) {
          $return .= $trRow;
        }
      }
      $return .= '
      </tbody>
  </table>';
    } else {
      $return = 'No existen roles en el sistema';
    }
  } else {
    $return = 'Se ha generado el siguiente error: ' . $query['error'];
  }
  return $return;
}

function guardarRol() {
  global $mySQL;
  $return = array();
  $tipo = $_POST['tipo'];
  $rol_id = $_POST['rol_id'];
  $rol_nombre = $_POST['rol_nombre'];
  $opciones = $_POST['opciones'];
  $usuario_log = $_SESSION['preguntas_admin_user']['usuario_id'];
  if ($tipo == "nuevo") {
    $sql = "SELECT * FROM rol WHERE rol_nombre = '$rol_nombre'";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $return['success'] = false;
        $return['error'] = "Ya existe un rol con el nombre $rol_nombre.  Por favor utilice uno diferente.";
      } else {
        $sql = "INSERT INTO rol (rol_nombre) VALUES ('$rol_nombre')";
        $return = $mySQL->query($sql);
        $rol_id = $mySQL->insert_id();
        if (count($opciones) > 0) {
          foreach ($opciones as $value) {
            $sql = "INSERT INTO opcion_rol (opcion_id,rol_id,usuario_log,opcion_rol_activo) VALUES ($value,$rol_id,$usuario_log,'S')";
            $return = $mySQL->query($sql);
          }
        }
      }
    } else {
      $return = $query;
    }
  } else {
    $sql = "SELECT * FROM rol WHERE rol_nombre = '$rol_nombre' AND rol_id <> $rol_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $return['success'] = false;
        $return['error'] = "Ya existe un rol con el nombre $rol_nombre.  Por favor utilice uno diferente.";
      } else {
        $sql = "UPDATE rol SET rol_nombre = '$rol_nombre' WHERE rol_id = $rol_id";
        $return = $mySQL->query($sql);
        if (count($opciones) > 0) {
          $sql = "DELETE FROM opcion_rol WHERE rol_id = $rol_id";
          $return = $mySQL->query($sql);
          foreach ($opciones as $value) {
            $sql = "INSERT INTO opcion_rol (opcion_id,rol_id,usuario_log,opcion_rol_activo) VALUES ($value,$rol_id,$usuario_log,'S')";
            $return = $mySQL->query($sql);
          }
        }
      }
    } else {
      $return = $query;
    }
  }
  return json_encode($return);
}

include_once dirname(__FILE__) . '/../../general/sec_footer.php';
?>