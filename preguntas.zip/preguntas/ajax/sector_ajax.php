<?php

include_once dirname(__FILE__) . '/../../general/sec_ajax.php';
include_once dirname(__FILE__) . '/../../general/sec_header.php';

$accion = $_POST['accion'];
switch ($accion) {
  case 'cambiarActivo':
    echo cambiarActivo();
    break;

  case 'buscarSector':
    echo buscarSector();
    break;

  case 'listarSectores':
    echo listarSectores();
    break;

  case 'guardarSector':
    echo guardarSector();
    break;
}

function cambiarActivo() {
  global $mySQL;
  $return = array();
  $sector_id = $_POST['sector_id'];
  $valor = $_POST['valor'];
  $usuario_log = $_SESSION['preguntas_admin_user']['usuario_id'];
  $sql = "UPDATE sector SET sector_activo = '$valor', usuario_log = $usuario_log WHERE sector_id = $sector_id";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    $return['success'] = true;
  } else {
    $return['success'] = false;
    $return['error'] = 'Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
    //$return['error'] = $query['error'];
  }
  return json_encode($return);
}

function buscarSector() {
  global $mySQL;
  $return = array();
  $sector_id = $_POST['sector_id'];
  $sql = "SELECT * FROM sector WHERE sector_id = $sector_id";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      $return = $mySQL->fetch_assoc($query['result']);
      $return['success'] = true;
    } else {
      $return['success'] = false;
      $return['error'] = "Sector no encontrado";
    }
  } else {
    $return['success'] = false;
    $return['error'] = 'Ocurrió un error al momento de consultar la información del sector, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
    //$return['error'] = $query['error'];
  }
  return json_encode($return);
}

function listarSectores() {
  global $mySQL;
  $filtro = $_POST['filtro'];

  $return = "";
  $sql = "SELECT sector.*, elt(field(sector.sector_activo, 'S','N'), 'SI', 'NO') AS sector_activo FROM sector";
  $query = $mySQL->query($sql);
  if ($query['success']) {
    if ($mySQL->num_rows($query['result']) > 0) {
      $return = '
  <table style="width: 60%" id="tablaSectores" class="tablesorter">
    <thead>
      <tr style="text-align:center;">
        <th>
          Nombre
        </th>
        <th>
          Descripción
        </th>
        <th>
          Activo
        </th>
        <th>
          &nbsp;
        </th>
      </tr>
    </thead>
    <tbody>';
      while ($row = $mySQL->fetch_assoc($query['result'])) {
        $trRow = "
        <tr>
          <td>$row[sector_nombre]</td>
          <td>$row[sector_desc]</td>
          <td style='text-align:center;'>$row[sector_activo]</td>
          <td style='text-align:center;'>
            <a href='javascript:editarSector(\"editar\", $row[sector_id]);'><img src='images/b_edit.png'/></a>";
        if ($row['sector_activo'] == 'SI') {
          $trRow .= "<a href='javascript:cambiarActivoSector($row[sector_id], \"N\");'><img src='images/turn_off.png'/></a>";
        } else {
          $trRow .= "<a href='javascript:cambiarActivoSector($row[sector_id], \"S\");'><img src='images/turn_on.png'/></a>";
        }
        $trRow .= "
          </td>
        </tr>";
        if (is_null($filtro) || empty($filtro) || strpos(strtolower($trRow), strtolower($filtro)) > 0) {
          $return .= $trRow;
        }
      }
      $return .= '
      </tbody>
  </table>';
    } else {
      $return = 'No existen sectores en el sistema';
    }
  } else {
    $return = 'Se ha generado el siguiente error: ' . $query['error'];
  }
  return $return;
}

function guardarSector() {
  global $mySQL;
  $return = array();
  $tipo = $_POST['tipo'];
  $sector_id = $_POST['sector_id'];
  $sector_nombre = $_POST['sector_nombre'];
  $sector_desc = $_POST['sector_desc'];
  $usuario_log = $_SESSION['preguntas_admin_user']['usuario_id'];
  //die;
  if ($tipo == "nuevo") {
    $sql = "SELECT * FROM sector WHERE sector_nombre = '$sector_nombre'";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $return['success'] = false;
        $return['error'] = "Ya existe un sector con el nombre $sector_nombre.  Por favor utilice uno diferente.";
      } else {
        $sql = "INSERT INTO sector (sector_nombre, sector_desc, usuario_log, sector_activo) VALUES('$sector_nombre', '$sector_desc', $usuario_log, 'S')";
        $query = $mySQL->query($sql);
        $sector_id = $mySQL->insert_id();
        if ($query['success']) {
          $return['success'] = true;
        } else {
          $return['success'] = false;
          $return['error'] = 'Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
          //$return['error'] = $query['error'];
        }
      }
    } else {
      $return['success'] = false;
      $return['error'] = 'Ocurrió un error al momento de consultar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
    }
  } else {
    $sql = "SELECT * FROM sector WHERE sector_nombre = '$sector_nombre' AND sector_id <> $sector_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $return['success'] = false;
        $return['error'] = "Ya existe un sector con el nombre $sector_nombre.  Por favor utilice uno diferente.";
      } else {
        $sql = "UPDATE sector SET sector_nombre = '$sector_nombre', sector_desc = '$sector_desc', usuario_log = $usuario_log WHERE sector_id = $sector_id";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          $return['success'] = true;
        } else {
          $return['success'] = false;
          $return['error'] = 'Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
          //$return['error'] = $query['error'];
        }
      }
    } else {
      $return['success'] = false;
      $return['error'] = 'Ocurrió un error al momento de consultar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
    }
  }
  return json_encode($return);
}

include_once dirname(__FILE__) . '/../../general/sec_footer.php';
?>
