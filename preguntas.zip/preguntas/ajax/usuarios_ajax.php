<?php

include_once dirname(__FILE__) . '/../general/sec_ajax.php';
include_once dirname(__FILE__) . '/../general/sec_header.php';
include_once dirname(__FILE__) . '/../model/Usuarios.php';

$accion = $_REQUEST['accion'];

$usuario = new Usuarios();
switch ($accion) {
  case 'cambiarActivo':
    echo json_encode($usuario->cambiarActivo(), JSON_UNESCAPED_UNICODE);
    break;

  case 'buscarUsuario':
    echo json_encode($usuario->buscarUsuario(), JSON_UNESCAPED_UNICODE);
    break;

  case 'listarUsuarios':
    echo $usuario->listarUsuarios();
    break;

  case 'guardarUsuario':
    echo json_encode($usuario->guardarUsuario(), JSON_UNESCAPED_UNICODE);
    break;
}

?>