<?php

$server_name = $_SERVER['SERVER_NAME'];
$www_url = 'http://192.168.1.30/seguros/sepol/';
/*
$www_url = 'http' . ((intval($_SERVER['SERVER_PORT']) == 443)?'s':'') . '://' . $server_name;
$uri = $_SERVER['REQUEST_URI'];
$uri = explode("/", $uri);
for ($uri_item = 0; $uri_item < count($uri) - 1; $uri_item++) {
    if (!empty($uri[$uri_item])) {
        $www_url .= "/" . $uri[$uri_item];
    }
}
*/

$config_vars = array(
  'server.name' => $server_name,
  'mail.test' => "yparra@loaseguramos.com",
  'server.env' => "dev",
  'db.host' => "localhost",
  'db.user' => "seguros",
  'db.pwd' => "%Judkjhf384324u$@",
  'db.name' => "seguros",
  'server.url' => $www_url,
  'mail.errors' => 'jimmy@netstudio.co',
  'mail.host' => "smtp.gmail.com",
  'mail.port' => 587,
  'mail.user' => "jchaparro@netstudio.co",
  'mail.pwd' => "Magaoscura99",
  'mail.auth' => true,
  'mail.from' => "sepol@loaseguramos.com",
  'mail.reply' => "sepol@loaseguramos.com",
  'mail.from.name' => "SEPOL - loaseguramos.com",
  'mail.logo' => "<img src='" . $www_url . "images/logo_mail.png' width='200px'/>",
  'www_path' => 'http://localhost/seguros/www',
  'ep_url_action' => 'https://secure.payco.co/checkout.php',
  'ep_cust_id_cliente' => '10800',
  'ep_key' => '65c2b479c6e9710df46dd2e33e336a978c496054',
  'ep_currency_code' => 'COP',
  'ep_test_request' => 'TRUE'
);
?>
