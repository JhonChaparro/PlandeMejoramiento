<?php

$key = $_REQUEST['key'];
$documento = json_decode(base64_decode(strrev($key)));
if (!empty($documento->poliza_docum_id)) {
  $path_documento = getPathDocumentos() . $documento->path_documento;
  if (file_exists($path_documento)) {
    $mime = mime_content_type($path_documento);
    $nom_documento = substr($documento->path_documento, strrpos($documento->path_documento, "/") + 1);
    ob_start();
    header($_SERVER['SERVER_PROTOCOL'] . ' 200 OK');
    header('Content-Type: ' . $mime);
    header("Content-Transfer-Encoding: Binary");
    header("Content-Length: " . filesize($path_documento));
    header('Pragma: no-cache');
    header('Content-disposition: attachment; filename=' . $nom_documento);
    ob_flush();
    ob_clean();
    readfile($path_documento);
    exit;
  }
}

function getPathDocumentos() {
  return dirname(__FILE__) . '/../documents/';
}

?>
