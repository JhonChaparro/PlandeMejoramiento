<?php

require_once dirname(__FILE__) . '/Tools.php';

class MySQL {

  private $conn;
  private $results;

  public function MySQL($domain = NULL) {
    $config_vars = $this->getConfigVars($domain);
    if (!isset($this->conn)) {
      $this->conn = (mysql_connect($config_vars['db.host'], $config_vars['db.user'], $config_vars['db.pwd'])) or die(mysql_error());
      mysql_query("SET NAMES 'utf8'");
      mysql_select_db($config_vars['db.name'], $this->conn) or die(mysql_error());
      $this->results = array();
    }
  }

  public function getConfigVars($domain = NULL) {
    if (empty($domain)) {
      $domain = $_SERVER['SERVER_NAME'];
    }
    $path = dirname(__FILE__);
    $confFile = $path . '/../conf/' . $domain . '.php';
    if (file_exists($confFile)) {
      include $confFile;
      return $config_vars;
    } else {
      die("El archivo de configuración para el dominio $domain no existe o esta dañado.  Por favor contacte al administrador del sistema al correo soporte@loaseguramos.com");
    }
  }

  public function query($sql) {
    $return = array();
    $query = mysql_query($sql, $this->conn);
    $config_vars = $this->getConfigVars();
    if ($query) {
      if ($config_vars['server.env'] != 'prod') {
        $tools = new Tools();
        $tools->createLog($sql);
      }
      $return['success'] = true;
      $return['result'] = $query;
      $this->results[] = $query;
    } else {
      $return['success'] = false;
      $return['error'] = 'MySQL Error: ' . mysql_error();
      
      $tools = new Tools();
      $tools->createLog($sql);
      $tools->createLog($return['error']);
      $backtrace = debug_backtrace();
      $tools->createLog(json_encode($backtrace));
      if ($config_vars['server.env'] == 'prod') {
        $subject = "Error in MySQL";
        $message = $sql . "<br/>" . $return['error'];
        $tools->sendEmail($subject, $message, NULL, NULL, NULL, $config_vars['mail.errors']);
      }
    }
    return $return;
  }

  public function result($sql, $row = 0) {
    $return = $this->query($sql);
    if ($return['success']) {
      $return['result'] = mysql_result($return['result'], $row);
    }
    return $return;
  }

  public function insert_id() {
    return mysql_insert_id($this->conn);
  }

  public function fetch_array($query) {
    return mysql_fetch_array($query);
  }

  public function fetch_assoc($query) {
    return mysql_fetch_assoc($query);
  }

  public function num_rows($query) {
    return mysql_num_rows($query);
  }

  public function close_connection() {
    foreach ($this->results as $result) {
      if (!empty($result)) {
        @mysql_free_result($result);
      }
    }
    mysql_close($this->conn);
  }

  public function free_result($query) {
    if (!empty($query)) {
      @mysql_free_result($query);
    }
  }

  public function get_options_from_query($table, $pkey, $name, $where = '', $order = '', $val_selected = '', $with_empty = false) {
    $response = "";
    if ($with_empty) {
      $response .= "<option value=''>Seleccione... </option>";
    }
    $sql = "select distinct " . $pkey . ", " . $name . " from " . $table;
    if (isset($where) && !empty($where)) {
      $sql = $sql . " where " . $where;
    }
    $sql = $sql . " order by " . ((isset($order) && !empty($order)) ? $order : $name);
    $query = $this->query($sql);
    if ($query['success']) {
      if ($this->num_rows($query['result']) > 0) {
        while ($row = mysql_fetch_array($query['result'])) {
          $response = $response . "<option value='" . $row[$pkey] . "'";
          if ($val_selected != null && $val_selected == $row[$pkey]) {
            $response = $response . " selected='true'";
          }
          $response = $response . ">" . $row[$name] . "</option>";
        }
      }
      $this->free_result($query['result']);
    }
    return $response;
  }

  public function set_checkbox_from_query($table, $pkey, $label, $where, $name, $val_selected, $with_br, $order_by = NULL, $functionJS) {
    $response = "";
    $sql = "select distinct " . $pkey . ", " . $label . " from " . $table;
    if ($where != null) {
      $sql = $sql . " where " . $where;
    }
    if (!empty($order_by)) {
      $sql = $sql . " order by " . $order_by;
    } else {
      $sql = $sql . " order by " . $label;
    }
    $query = $this->query($sql);
    if ($query['success']) {
      if ($this->num_rows($query['result']) > 0) {
        while ($result = mysql_fetch_array($query['result'])) {
          $response = $response . '<input type="checkbox" name="' . $name . '" id="' . $name . '_' . $result[$pkey] . '" value="' . $result[$pkey] . '" ' . $functionJS;
          if ($val_selected == 'all') {
            $response = $response . ' checked="true"';
          } else if ($val_selected != null && count($val_selected) > 0) {
            for ($i = 0; $i < count($val_selected); $i = $i + 1) {
              if ($result[$pkey] == $val_selected[$i]) {
                $response = $response . ' checked="true"';
              }
            }
          }
          $response = $response . '/>' . $result[$label];
          if ($with_br == true) {
            $response = $response . "<br/>";
          } else {
            $response = $response . "&nbsp;&nbsp;";
          }
        }
      }
      $this->free_result($query['result']);
    }
    return $response;
  }

  public function get_conn() {
    return $this->conn;
  }

}

?>
