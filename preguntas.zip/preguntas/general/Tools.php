<?php

require_once dirname(__FILE__) . '/../general/sec_header.php';
require_once dirname(__FILE__) . '/../phpmailer/class.phpmailer.php';
require_once dirname(__FILE__) . '/../phpmailer/class.smtp.php';

class Tools {

  function sendEmail($subject, $message, $from = NULL, $replyTo = null, $fromName = NULL, $to = NULL, $cc = NULL, $bcc = NULL, $attachments = null, $domain = NULL, $embeddedImages = NULL) {
    $return = array();
    global $mySQL;
    global $configVars;
    if ($configVars['server.env'] != 'prod') {
      $to = $configVars['mail.test'];
      $cc = NULL;
      $bcc = NULL;
      $subject = "** CORREO DE PRUEBA ** - " . $subject;
      $message = '<span style="color:RED;font-size: 2em;">** ESTE CORREO ES DE PRUEBA, POR FAVOR NO LO TENGA EN CUENTA **</span><br/><br/>' . $message;
    }
    $mail = new PHPMailer();

    $mail->Host = $configVars['mail.host'];
    $mail->Port = $configVars['mail.port'];
    $mail->Username = $configVars['mail.user'];
    $mail->Password = $configVars['mail.pwd'];
    $mail->SMTPAuth = $configVars['mail.auth'];
    
    if($configVars['mail.host'] == 'smtp.gmail.com'){
      $mail->SMTPSecure = 'tls';
    }
    $mail->addEmbeddedImage(dirname(__FILE__) . '/../sepol/images/logo_mail.png', 'logo');
    $mail->addEmbeddedImage(dirname(__FILE__) . '/../sepol/images/facebook.png', 'facebook');
    $mail->addEmbeddedImage(dirname(__FILE__) . '/../sepol/images/twitter.png', 'twitter');
    $mail->addEmbeddedImage(dirname(__FILE__) . '/../sepol/images/google.png', 'gplus');
    
    if(!empty($embeddedImages)){
      foreach ($embeddedImages as $key => $value) {
        $mail->addEmbeddedImage(dirname(__FILE__) . $value, $key);
      }
    }

    if (empty($from)) {
      $from = $configVars['mail.from'];
    }
    $mail->From = $from;
    if (empty($replyTo)) {
      $replyTo = $configVars['mail.reply'];
    }
    $mail->AddReplyTo($replyTo);
    if (empty($fromName)) {
      $fromName = $configVars['mail.from.name'];
    }
    $mail->FromName = $fromName;
    $mail->Subject = $subject;
    $mail->msgHTML($message);
    if (!empty($to)) {
      $to = str_replace(" ", "", $to);
      $to = str_replace(";", ",", $to);
      $to = explode(",", $to);
      if (is_array($to)) {
        foreach ($to as $email) {
          $mail->AddAddress($email);
        }
      } else {
        $mail->AddAddress($to);
      }
    }
    if (!empty($cc)) {
      $cc = str_replace(" ", "", $cc);
      $cc = str_replace(";", ",", $cc);
      $cc = explode(",", $cc);
      if (is_array($cc)) {
        foreach ($cc as $email) {
          $mail->AddCC($email);
        }
      } else {
        $mail->AddCC($cc);
      }
    }
    if (!empty($bcc)) {
      $bcc = str_replace(" ", "", $bcc);
      $bcc = str_replace(";", ",", $bcc);
      $bcc = explode(",", $bcc);
      if (is_array($bcc)) {
        foreach ($bcc as $email) {
          $mail->AddBCC($email);
        }
      } else {
        $mail->AddBCC($bcc);
      }
    }
    if (!empty($attachments)) {
      foreach ($attachments as $name => $path) {
        $mail->AddAttachment($path, $name);
      }
    }
    if ($mail->Send()) {
      $return['success'] = true;
      $return['message'] = 'El mensaje ha sido enviado.';
    } else {
      $return['success'] = false;
      $return['error'] = "Ha ocurrido un error tratando de enviar el correo electrónico ($mail->ErrorInfo), por favor intente nuevamente";
    }
    return $return;
  }

  public function parseEnterKey($text, $parser = "\n", $li = 'none') {
    // Damn pesky carriage returns...
    $text = str_replace("\r\n", $parser, $text);
    $text = str_replace("\r", $parser, $text);
    $text = str_replace("\n\r", $parser, $text);
    $text = str_replace("\n", $parser, $text);
    $text = explode($parser, $text);
    $return = '';
    foreach ($text as $key => $line) {
      if (!empty($line)) {
        switch ($li) {
          case 'number':
            $return .= ($key + 1) . ". ";
            break;

          case 'dot':
            $return .= '';
            break;

          case 'line':
            $return .= '- ';
            break;
        }
        $return .= $line . $parser;
      }
    }
    return $return;
  }

  public function checkNote($notes, $length) {
    $isvalid = true;
    $error = array();
    if ($notes != null && $notes != "") {
      $notes = $this->parseEnterKey($notes);
      $notes = explode("\n", $notes);
      $successNotes = "";
      foreach ($notes as $i => $note) {
        if (!preg_match("/^([a-zA-Z0-9 ]+)$/i", $note)) {
          $note = preg_replace('/[^a-zA-Z0-9 ]/', '', $note);
          $isvalid = false;
          $error[] = "Las observaciones solo pueden contener números, letras y espacios";
        }
        $note = str_replace('   ', ' ', $note);
        $note = trim(str_replace('  ', ' ', $note));
        $successNotes .= $note;
        if ($i < count($notes) - 1) {
          $successNotes .= "\\n";
        }
        if (strlen($successNotes) > $length) {
          $successNotes = substr($successNotes, 0, 250);
          $error[] = "Las observaciones deben tener maximo " . $length . " caracteres";
          $isvalid = false;
          break;
        }
      }
    }
    if (count($error) > 0) {
      $textError = "";
      foreach ($error as $i => $errorLine) {
        $textError .= $errorLine;
        if ($i < count($error) - 1) {
          $textError .= "\\n";
        }
      }
      $error = $textError;
    } else {
      $error = "";
    }
    $return = array("isvalid" => $isvalid, "text" => $successNotes, "error" => $error);
    return $return;
  }

  public function decodeRestString($string) {
    global $mySQL;
    $configVars = $mySQL->getConfigVars();
    $string = urldecode($string);

    return json_decode(base64_decode(strrev($string)));
  }

  public function encodeRestArray($array) {
    global $mySQL;
    $configVars = $mySQL->getConfigVars();
    $json = json_encode($array, JSON_UNESCAPED_UNICODE);

    return strrev(base64_encode($json));
  }

  public function checkEmailSyntax($email) {
    return (preg_match("/^(\w+[\-\.])*\w+@(\w+\.)+[A-Za-z]+$/", $email) ? true : false);
  }

  public function addPixelsToCurLinePDF($curline, $pixels, $pdf) {
    //CALCULATE THE NEXT POSITION OF Y
    $newPos = $curline + $pixels;
    //CHECK IF Y > 270 THEN NEEDS ADD A NEW PAGE
    if ($newPos >= 220) {
      $pdf->AddPage();
      $newPos = $pdf->minY;
    }
    return $newPos;
  }

  function loadTemplate($name, $params) {
    $return = array();
    $path = dirname(__FILE__);
    $filepath = $path . '/../templates/' . $name;
    if ($file = fopen($filepath, 'r')) {
      $content = "";
      while (!feof($file)) {
        $content .= fgets($file);
      }
      fclose($file);
      foreach ($params as $key => $value) {
        $content = str_replace($key, $value, $content);
      }
      $return['success'] = true;
      $return['content'] = $content;
    } else {
      $return['success'] = false;
      $return['error'] = "Error al tratar de cargar la plantilla " . $name;
    }
    return $return;
  }

  public function convertMDYToYMD($date, $delimiter) {
    $date = explode($delimiter, $date);
    return $date[2] . '-' . $date[0] . '-' . $date[1];
  }

  public function createLog($text) {
    $path = dirname(__FILE__);
    $confFile = $path . '/../log/' . date('Y-m-d') . '.log';
    $file = fopen($confFile, 'a');
    $text = date("Y-m-d H:i:s") . "\t" . $_SERVER['REMOTE_ADDR'] . "\t" . $text . "\n";
    fwrite($file, $text);
    fclose($file);
  }

  public function getConfigVars($domain = NULL) {
    if (empty($domain)) {
      $domain = $_SERVER['SERVER_NAME'];
    }
    $path = dirname(__FILE__);
    $confFile = $path . '/../conf/' . $domain . '.php';
    if (file_exists($confFile)) {
      include $confFile;
      return $config_vars;
    } else {
      die("Config file of domain $domain is wrong or does not exists.  Please contact our system administrator");
    }
  }

  /**
   * 
   * @param type $type Way in which the name will be built,
   *        NA = firstName + middleName + lastName + secondLastName
   *        AN = lastName + secondLastName + firstName + middleName
   * @param type $firstName
   * @param type $middleName
   * @param type $lastName
   * @param type $secondLastName
   * @return string 
   */
  public function buildName($type, $firstName, $middleName, $lastName, $secondLastName) {
    $return = '';
    switch ($type) {
      //first name - middle name - last name - second name
      case 'NA':
        if (!empty($firstName)) {
          $return .= $firstName;
        }
        if (!empty($middleName)) {
          $return .= ' ' . $middleName;
        }
        if (!empty($lastName)) {
          $return .= ' ' . $lastName;
        }
        if (!empty($secondLastName)) {
          $return .= ' ' . $secondLastName;
        }
        break;
      //last name - second name - first name - middle name
      case 'AN':
        if (!empty($lastName)) {
          $return .= $lastName;
        }
        if (!empty($secondLastName)) {
          $return .= ' ' . $secondLastName;
        }
        if (!empty($firstName)) {
          $return .= ' ' . $firstName;
        }
        if (!empty($middleName)) {
          $return .= ' ' . $middleName;
        }
        break;
    }
    return $return;
  }

  public function formatearTexto($texto, $limite) {
    $return = array();
    $arrPal = split(' ', $texto);
    $renglon = '';
    for ($i = 0; $i < count($arrPal); $i++) {
      if (strlen($renglon) <= $limite) {
        $renglon .= $arrPal[$i] . ' ';
        if (($i + 1) == count($arrPal)) {
          $return[] = $renglon;
        }
      } else {
        $i--;
        $return[] = $renglon;
        $renglon = '';
      }
    }
    return $return;
  }

  public function getCompanyInstance() {
    $uri = $_SERVER['REQUEST_URI'];
    $instance = split('/', $uri);
    if (!empty($instance) && count($instance) > 0) {
      return $instance[1];
    }
  }

  public function getRandowPassword($length) {
    $characters = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $string = '';
    for ($p = 0; $p < $length; $p++) {
      $string .= $characters[mt_rand(0, strlen($characters) - 1)];
    }
    return $string;
  }

  public function getRandowCode($length) {
    $characters = "0123456789abcdefghijklmnopqrstuvwxyz";
    $string = '';
    for ($p = 0; $p < $length; $p++) {
      $string .= $characters[mt_rand(0, strlen($characters) - 1)];
    }
    return $string;
  }

}

?>
