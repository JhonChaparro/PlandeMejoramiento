<?php

//     DESCRIPCION:	Pagina principal del sitio
//         VERSION:	1.0
//           AUTOR:	NETStudio
//           FECHA:	2012-12-26
//
//  MODIFICACIONES:
//
//
// No cache [Development purposes]
header("Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0", false);
header("Expires: Tue, 01 Jan 1980 00:00:01 GMT");
header("Pragma: no-cache");
header('Content-Type: text/html');
error_reporting(0);
session_start();
require_once 'MySQL.php';
$mySQL = new MySQL();
$configVars = $mySQL->getConfigVars();
date_default_timezone_set('America/Bogota');

?>
