<script type="text/javascript">
  $(document).ready(function () {
    $("#menu").mmenu({
      // Options
    });
  });
</script>
<div class="container-fluid navbar navbar-default" id="mHeader" style="background-color: #F8F8F8; color: black;">
  <div class="col-md-1" style="min-height: 76px;">
    <?php if (isset($_SESSION['preguntas_admin_user'])) { ?>
      <a href="#menu"><span class="glyphicon glyphicon-menu-hamburger" style="font-size: 30px; margin-top: 20px; color: black;"></span></a>
    <?php } ?>
  </div>
  <div class="col-md-3">
    <br/><strong>Sistema de preguntas</strong>
  </div>
  <div class="col-md-4" style="font-weight: 600; vertical-align: middle; text-align: center;">
    <br/>
    PREGUNTAS - Sistema de gestión de preguntas.
    <br/>
  </div>
</div>

<div id="page">
  <nav id="menu">
    <ul>
      <?php
      if (isset($_SESSION['preguntas_admin_user'])) {
        if (empty($_SESSION['hide_menu'])) {
          echo '<ul>';
          echo $_SESSION['preguntas_admin_menu'];
          echo '</ul>';
        }
      }
      ?>
    </ul>
  </nav>
</div>



