<?php
require_once 'general/sec_header.php';
require_once 'general/Tools.php';
$usuario_seguros = $_SESSION['preguntas_admin_user'];
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <title>PREGUNTAS</title>
    <meta name="viewport" content="width=device-width, initial-scale = 1.0,maximum-scale = 1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
    <link href="css/site-1.0.css" rel="stylesheet">
    <link href="css/blitzer/jquery-ui-1.10.4.custom.css" rel="stylesheet">
    <link href="css/jquery.tablesorter.css" rel="stylesheet">
    <link href="css/jquery.mmenu.all.css" rel="stylesheet" type="text/css"/>

    <script type="text/javascript" src="js/jquery-1.9.1.js"></script>
    <script type="text/javascript" src="js/jquery-ui-1.10.3.min.js"></script>
    <script type="text/javascript" src="js/jquery.tablesorter.min.js"></script>
    <script type="text/javascript" src="js/jquery.metadata.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/language.js?time=<?php echo time(); ?>"></script>
    <script type="text/javascript" src="js/tools.js?time=<?php echo time(); ?>"></script>
    <script type="text/javascript" src="js/jquery.mmenu.all.min.js"></script>

    <script type="text/javascript">
      $(document).ready(function () {
        moveFooter();
        $(window).resize(function () {
          moveFooter();
        });
      });

      function moveFooter() {
        heightWindow = window.innerHeight;
        topFooter = $("#footer").position().top;
        heightFooter = $("#footer").height();
        if (heightWindow > topFooter + heightFooter) {
          $("#footer").css("position", "fixed");
          $("#footer").css("top", (heightWindow - heightFooter) + "px");
        }
      }


      function footer() {
        heightWindow = Math.max($(document).height(), $(window).height());

        topFooter = $("#footer").position().top;
        heightFooter = $("#footer").height();
        if (heightWindow >= topFooter + heightFooter - 3 && $(document).height() <= $(window).height()) {
          $("#footer").css("position", "fixed");
          $("#footer").css("top", (heightWindow - heightFooter) + "px");
        } else {
          $("#footer").css("position", "relative");
          $("#footer").css("top", "0px");
        }
      }
    </script>
    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
    <![endif]-->
  </head>

  <body style="<?php echo (($config_vars['server.env'] != 'prod') ? "background-image: url('images/modo_prueba.png');" : ''); ?>">

    <?php include_once ('header.php'); ?>
    <div align="center">
      <div style="width: 90%;">
        <div id="divMessage" style="text-align: center;"></div>
        <div id="divProcessing" align="center" style="display: none;">
          <img src="images/spinner.gif"/><br><span id="divProcessMessage"></span>
        </div>
        <div id="divDialog" style="display:none;"></div>
        <?php
        $tools = new Tools();
        $page = 'login.php';
        if (isset($_REQUEST['p']) && (isset($_SESSION['preguntas_admin_user']))) {
          $page = $_REQUEST['p'] . ".php";
        }
        if (isset($_REQUEST['opcion_id'])) {
          $_SESSION['opcion_id'] = $_REQUEST['opcion_id'];
        }
        include_once ('view/' . $page);
        ?>
      </div>
      <br/>
      <br/>
    </div>
    <div style="overflow: auto; vertical-align: bottom;bottom: 0; width: 100%; background-color: #F8F8F8; color: black;" class="navbar navbar-default" id="footer">
      <br/>
      <div style="text-align: center;">
        <p>PREGUNTAS - Todos los derechos reservados -  <?php echo date('Y'); ?></p>

      </div>
    </div>
    <!-- BEGIN JIVOSITE CODE {literal} -->
    <script type='text/javascript'>
      (function () {
        var widget_id = 'mqZ6y11sSH';
        var d = document;
        var w = window;
        function l() {
          var s = document.createElement('script');
          s.type = 'text/javascript';
          s.async = true;
          s.src = '//code.jivosite.com/script/widget/' + widget_id;
          var ss = document.getElementsByTagName('script')[0];
          ss.parentNode.insertBefore(s, ss);
        }
        if (d.readyState == 'complete') {
          l();
        } else {
          if (w.attachEvent) {
            w.attachEvent('onload', l);
          } else {
            w.addEventListener('load', l, false);
          }
        }
      })();
    </script>
    <!-- {/literal} END JIVOSITE CODE -->
  </body>
</html>
<?php
require_once 'general/sec_footer.php';
?>