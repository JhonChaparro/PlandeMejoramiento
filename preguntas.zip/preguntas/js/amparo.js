var title = "Control de Amparos";
var subAccion = "";
$(document).ready(function () {

  setTitle(title);
  $("#btnBusqueda").button().click(function (event) {
    event.preventDefault();
    listarAmparos();
  });
  $("#textBusqueda").keyup(function (event) {
    event.preventDefault();
    if (event.keyCode == 13) {
      listarAmparos();
    }
  });
  $("#btnGuardar").button().click(function (event) {
    event.preventDefault();
    guardarAmparo();
  });
  $("#btnCancelar").button().click(function (event) {
    event.preventDefault();
    $("#divEditAmparos").dialog("close");
  });

  $("#divEditAmparos").dialog({
    autoOpen: false,
    modal: true,
    width: 900,
    height: "auto",
    title: title
  });

  listarAmparos();
});

function listarAmparos() {
  showMessage('divMessage', "Listando amparos . . .", 'message', 0);

  var params = {
    accion: 'listarAmparos',
    filtro: $("#textBusqueda").val()
  };
  $.post('ajax/amparo_ajax.php', params, function (data) {
    hideMessage('divMessage');
    $("#divListaAmparos").html(data);
    $("#tablaAmparos").tablesorter({
      sortList: [[0, 0]],
      widthFixed: true,
      widgets: ['zebra']
    });
  }, 'html');

}

function editarAmparo(tipo, amparo_id) {
  subAccion = tipo;
  hideMessage('divEditAmparosMessage');
  $('input[name=tipo_liqui_id]').each(function (index) {
    if ($(this).is(':checked')) {
      $(this).attr('checked', false);
    }
  });

  if (tipo == 'nuevo') {
    $("#amparo_nombre").val("");
    $("#divEditAmparos").dialog('open');
  }
  else {
    showMessage('divMessage', "Cargando datos del amparo . . .", 'message', 0);
    var params = {
      accion: 'buscarAmparo',
      amparo_id: amparo_id
    };
    $.post('ajax/amparo_ajax.php', params, function (data) {
      if (data.success) {
        hideMessage('divMessage');
        $("#amparo_id").val(data.amparo_id);
        $("#amparo_nombre").val(data.amparo_nombre);
        $("#vig_no_def").val(data.vig_no_def);
        $("#garantia_id").val(data.garantia_id);
        $("#tipo_amparo_id").val(data.tipo_amparo_id);
        if (data.tipo_liqui_ids) {
          for (i in data.tipo_liqui_ids) {
            tipo_liqui_id = data.tipo_liqui_ids[i];
            $("#tipo_liqui_id_" + tipo_liqui_id).prop("checked", true);
          }
        }
        $("#divEditAmparos").dialog('open');
      }
      else {
        showMessage('divMessage', data.error, 'error', 8000);
      }
    }, 'json');
  }
}

function guardarAmparo() {
  var tipo_liqui_ids = new Array();
  $('input[name=tipo_liqui_id]').each(function (index) {
    if ($(this).prop('checked')) {
      tipo_liqui_ids[tipo_liqui_ids.length] = $(this).val();
    }
  });
  var checkArray = checkField('amparo_nombre', 'Nombre', true, "string");
  if (checkArray.success) {
    var esNuevo = (subAccion == "nuevo");
    var texto = ((esNuevo) ? "Ingresando" : "Actualizando");

    showMessage('divEditAmparosMessage', texto + " amparo . . .", 'message', 0);
    var params = {
      accion: 'guardarAmparo',
      tipo: subAccion,
      amparo_id: $('#amparo_id').val(),
      amparo_nombre: $('#amparo_nombre').val(),
      vig_no_def: $('#vig_no_def').val(),
      tipo_amparo_id: $('#tipo_amparo_id').val(),
      garantia_id: $('#garantia_id').val(),
      tipo_liqui_ids: tipo_liqui_ids
    };
    $.post('ajax/amparo_ajax.php', params, function (data) {
      if (data.success) {
        hideMessage('divEditAmparosMessage');
        $("#divEditAmparos").dialog('close');
        listarAmparos();
      }
      else {
        showMessage('divEditAmparosMessage', data.error, 'error', 8000);
      }
    }, 'json');

  }
  else {
    showMessage('divEditAmparosMessage', checkArray.message, 'error', 8000);
    return false;
  }
}

function cambiarActivoAmparo(amparo_id, valor) {
  var texto = "";
  var accion = "";
  switch (valor) {
    case 'N':
      texto = "Desactivar";
      accion = "Desactivando";
      break;

    case 'S':
      texto = "Activar";
      accion = "Activando";
      break;
  }
  texto = "¿Esta seguro que desea " + texto + " este amparo?";
  $("#divDialog").html(texto);
  $("#divDialog").dialog({
    modal: true,
    width: "600px",
    height: "auto",
    resize: true,
    title: title,
    buttons: {
      "Si": function () {
        $("#divDialog").dialog("close");
        showMessage('divMessage', accion + " amparo . . .", 'message', 0);
        var params = {
          accion: 'cambiarActivo',
          amparo_id: amparo_id,
          valor: valor
        };
        $.post('ajax/amparo_ajax.php', params, function (data) {
          if (data.success) {
            listarAmparos();
          }
          else {
            showMessage('divMessage', data.error, 'error', 0);
          }
        }, 'json');
      },
      "No": function () {
        $("#divDialog").dialog("close");
      }
    }
  });
}
