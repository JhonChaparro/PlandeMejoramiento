var title = "Control de Aseguradoras";
var subAccion = "";
$(document).ready(function () {

  setTitle(title);
  $("#btnBusqueda").button().click(function (event) {
    event.preventDefault();
    listarAseguradoras();
  });
  $("#textBusqueda").keyup(function (event) {
    event.preventDefault();
    if (event.keyCode == 13) {
      listarAseguradoras();
    }
  });
  $("#btnGuardar").button().click(function (event) {
    event.preventDefault();
    guardarAseguradora();
  });
  $("#btnCancelar").button().click(function (event) {
    event.preventDefault();
    $("#divEditAseguradoras").dialog("close");
  });

  $("#divEditAseguradoras").dialog({
    autoOpen: false,
    modal: true,
    width: 700,
    height: "auto",
    title: title
  });

  listarAseguradoras();
});

function listarAseguradoras() {
  showMessage('divMessage', "Listando aseguradoras . . .", 'message', 0);

  var params = {
    accion: 'listarAseguradoras',
    filtro: $("#textBusqueda").val()
  };
  $.post('ajax/aseguradora_ajax.php', params, function (data) {
    hideMessage('divMessage');
    $("#divListaAseguradoras").html(data);
    $("#tablaAseguradoras").tablesorter({
      sortList: [[0, 0]],
      widthFixed: true,
      widgets: ['zebra']
    });
  }, 'html');

}

function editarAseguradora(tipo, aseguradora_id) {
  subAccion = tipo;
  hideMessage('divEditAseguradorasMessage');

  if (tipo == 'nuevo') {
    $("#aseguradora_nombre").val("");
    $("#divEditAseguradoras").dialog('open');
  }
  else {
    showMessage('divMessage', "Cargando datos del aseguradora . . .", 'message', 0);
    var params = {
      accion: 'buscarAseguradora',
      aseguradora_id: aseguradora_id
    };
    $.post('ajax/aseguradora_ajax.php', params, function (data) {
      if (data.success) {
        hideMessage('divMessage');
        $("#aseguradora_id").val(data.aseguradora_id);
        $("#aseguradora_nombre").val(data.aseguradora_nombre);
        $("#divEditAseguradoras").dialog('open');
      }
      else {
        showMessage('divMessage', data.error, 'error', 8000);
      }
    }, 'json');
  }
}

function guardarAseguradora() {
  var checkArray = checkField('aseguradora_nombre', 'Nombre', true, "string");
  if (checkArray.success) {
    var esNuevo = (subAccion == "nuevo");
    var texto = ((esNuevo) ? "Ingresando" : "Actualizando");

    showMessage('divEditAseguradorasMessage', texto + " aseguradora . . .", 'message', 0);
    var params = {
      accion: 'guardarAseguradora',
      tipo: subAccion,
      aseguradora_id: $('#aseguradora_id').val(),
      aseguradora_nombre: $('#aseguradora_nombre').val()
    };
    $.post('ajax/aseguradora_ajax.php', params, function (data) {
      if (data.success) {
        hideMessage('divEditAseguradorasMessage');
        $("#divEditAseguradoras").dialog('close');
        listarAseguradoras();
      }
      else {
        showMessage('divEditAseguradorasMessage', data.error, 'error', 8000);
      }
    }, 'json');

  }
  else {
    showMessage('divEditAseguradorasMessage', checkArray.message, 'error', 8000);
    return false;
  }
}

function cambiarActivoAseguradora(aseguradora_id, valor) {
  var texto = "";
  var accion = "";
  switch (valor) {
    case 'N':
      texto = "Desactivar";
      accion = "Desactivando";
      break;

    case 'S':
      texto = "Activar";
      accion = "Activando";
      break;
  }
  texto = "¿Esta seguro que desea " + texto + " esta aseguradora?";
  $("#divDialog").html(texto);
  $("#divDialog").dialog({
    modal: true,
    width: "600px",
    height: "auto",
    resize: true,
    title: title,
    buttons: {
      "Si": function () {
        $("#divDialog").dialog("close");
        showMessage('divMessage', accion + " aseguradora . . .", 'message', 0);
        var params = {
          accion: 'cambiarActivo',
          aseguradora_id: aseguradora_id,
          valor: valor
        };
        $.post('ajax/aseguradora_ajax.php', params, function (data) {
          if (data.success) {
            listarAseguradoras();
          }
          else {
            showMessage('divMessage', data.error, 'error', 0);
          }
        }, 'json');
      },
      "No": function () {
        $("#divDialog").dialog("close");
      }
    }
  });
}
