var title = "Control de Campañas";
var subAccion = "";
$(document).ready(function () {

  setTitle(title);
  $("#btnBusqueda").button().click(function (event) {
    event.preventDefault();
    listarCampanias();
  });
  $("#textBusqueda").keyup(function (event) {
    event.preventDefault();
    if (event.keyCode == 13) {
      listarCampanias();
    }
  });
  $("#btnGuardar").button().click(function (event) {
    event.preventDefault();
    guardarCampanias();
  });
  $("#btnCancelar").button().click(function (event) {
    event.preventDefault();
    $("#divEditCampanias").dialog("close");
  });

  $("#divEditCampanias").dialog({
    autoOpen: false,
    modal: true,
    width: 700,
    height: "auto",
    title: title
  });

  listarCampanias();
});

function listarCampanias() {
  showMessage('divMessage', "Listando campañas . . .", 'message', 0);

  var params = {
    accion: 'listarCampanias',
    filtro: $("#textBusqueda").val()
  };
  $.post('ajax/campanias_ajax.php', params, function (data) {
    hideMessage('divMessage');
    $("#divListaCampanias").html(data);
    $("#tablaCampanias").tablesorter({
      sortList: [[0, 0]],
      widthFixed: true,
      widgets: ['zebra']
    });
  }, 'html');

}

function editarCampania(tipo, campania_id) {
  subAccion = tipo;
  hideMessage('divEditCampaniasMessage');

  if (tipo == 'nuevo') {
    $("#campania_nombre").val("");
    $("#llave").val("");
    $("#divEditCampanias").dialog('open');
  }
  else {
    showMessage('divMessage', "Cargando datos de la campaña . . .", 'message', 0);
    var params = {
      accion: 'buscarCampania',
      campania_id: campania_id
    };
    $.post('ajax/campanias_ajax.php', params, function (data) {
      if (data.success) {
        hideMessage('divMessage');
        $("#campania_id").val(data.campania_id);
        $("#campania_nombre").val(data.campania_nombre);
        $("#llave").val(data.llave);
        $("#divEditCampanias").dialog('open');
      }
      else {
        showMessage('divMessage', data.error, 'error', 8000);
      }
    }, 'json');
  }
}

function guardarCampanias() {
  var checkArray = checkField('campania_nombre', 'Nombre', true, "string");
  if (checkArray.success) {
    var checkArray = checkField('llave', 'Llave', true, "string");
    if (checkArray.success) {
      var esNuevo = (subAccion == "nuevo");
      var texto = ((esNuevo) ? "Ingresando" : "Actualizando");

      showMessage('divEditCampaniasMessage', texto + " aseguradora . . .", 'message', 0);
      var params = {
        accion: 'guardarCampanias',
        tipo: subAccion,
        campania_id: $('#campania_id').val(),
        campania_nombre: $('#campania_nombre').val(),
        llave: $('#llave').val()
      };
      $.post('ajax/campanias_ajax.php', params, function (data) {
        if (data.success) {
          hideMessage('divEditCampaniasMessage');
          $("#divEditCampanias").dialog('close');
          listarCampanias();
        }
        else {
          showMessage('divEditCampaniasMessage', data.error, 'error', 8000);
        }
      }, 'json');
    }
    else {
      showMessage('divEditCampaniasMessage', checkArray.message, 'error', 8000);
      return false;
    }
  }
  else {
    showMessage('divEditCampaniasMessage', checkArray.message, 'error', 8000);
    return false;
  }
}

function cambiarActivoAseguradora(aseguradora_id, valor) {
  var texto = "";
  var accion = "";
  switch (valor) {
    case 'N':
      texto = "Desactivar";
      accion = "Desactivando";
      break;

    case 'S':
      texto = "Activar";
      accion = "Activando";
      break;
  }
  texto = "¿Esta seguro que desea " + texto + " esta aseguradora?";
  $("#divDialog").html(texto);
  $("#divDialog").dialog({
    modal: true,
    width: "600px",
    height: "auto",
    resize: true,
    title: title,
    buttons: {
      "Si": function () {
        $("#divDialog").dialog("close");
        showMessage('divMessage', accion + " aseguradora . . .", 'message', 0);
        var params = {
          accion: 'cambiarActivo',
          aseguradora_id: aseguradora_id,
          valor: valor
        };
        $.post('ajax/campanias_ajax.php', params, function (data) {
          if (data.success) {
            listarCampanias();
          }
          else {
            showMessage('divMessage', data.error, 'error', 0);
          }
        }, 'json');
      },
      "No": function () {
        $("#divDialog").dialog("close");
      }
    }
  });
}
