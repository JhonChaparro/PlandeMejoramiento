$(document).ready(function () {
  $("#tablaLista").tablesorter({
    widthFixed: true,
    widgets: ['zebra']
  });

  $("#btnAplicar").button().click(function (event) {
    event.preventDefault();
    aplicarCambios();
  });

  traerConfiguracion();
});

function aplicarCambios() {
  var config_ids = new Array();
  var config_valores = new Array();
  $("input:hidden[name=config_id]").each(function () {
    config_ids.push($(this).val());
  });
  $("[name=config_valor]").each(function () {
    config_valores.push($(this).val());
  });
  for (i = 0; i < config_valores.length; i++) {
    if (config_valores[i] == null || config_valores[i] == "") {
      var mensaje = "El valor del parametro " + $("#config_nombre_" + config_ids[i]).html() + " es requerido";
      showMessage('divConfigMessage', mensaje, 'error', 8000);
      return;
    }
  }
  var params = {
    accion: 'aplicarCambios',
    config_ids: config_ids,
    config_valores: config_valores
  };
  showMessage('divMessage', "Aplicando cambios . . .", 'message', 0);
  $.post("ajax/config_ajax.php", params, function (data) {
    if (data.success) {
      if(data.forward != null){
        $("#divDialog").html(data.message);
            $("#divDialog").dialog({
              modal: true,
              width: "auto",
              heigh: "auto",
              title: "Información",
              buttons: {
                "Aceptar": function(){
                  window.location = data.forward;
                }
              }
            });
      }
      else{
      showMessage('divConfigMessage', data.message, 'message', 0);
    }
    }
    else {
      showMessage('divConfigMessage', data.error, 'error', 8000);
    }
  }, 'json');
}

function traerConfiguracion() {
  var params = {
    accion: 'buscarConfiguracion'
  };
  $.post('ajax/config_ajax.php', params, function (data) {
    if (data.success) {
      $.each(data, function (key, value) {
        $('#config_id_' + key).val(value);
      });
    }
    else {
      showMessage('divMessage', data.error, 'error', 8000);
    }
  }, 'json');
}