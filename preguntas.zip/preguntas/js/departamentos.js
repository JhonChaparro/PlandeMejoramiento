$(document).ready(function () {

  $("#btnBusqueda").button().click(function (event) {
    event.preventDefault();
    listarDepartamentos();
  });
  $("#textBusqueda").keyup(function (event) {
    event.preventDefault();
    if (event.keyCode == 13) {
      listarDepartamentos();
    }
  });
  $("#btnEstado").button().click(function (event) {
    event.preventDefault();
    cambiarActivoUsuario();
  });

  listarDepartamentos();
});

function listarDepartamentos() {
  showMessage('divMessage', "Listando municipios . . .", 'message', 0);

  var params = {
    accion: 'listarDepartamentos',
    filtro: $("#textBusqueda").val()
  };
  $.post('ajax/departamentos_ajax.php', params, function (data) {
    hideMessage('divMessage');
    $("#divListaDepartamentos").html(data);
    $("#tablaDepartamentos").tablesorter({
      sortList: [[0, 0]],
      widthFixed: true,
      widgets: ['zebra']
    });
  }, 'html');

}

function cambiarActivoUsuario() {
  var params = {
    accion: 'cambiarEstado'
  };

  var cantDesac = 0;
  $("input[name=check_desac]").each(function () {
    if ($(this).prop('checked')) {
      params[$(this).prop("id")] = $(this).val();
      cantDesac++;
    }
  });

  var cantActi = 0;
  $("input[name=check_acti]").each(function () {
    if ($(this).prop('checked')) {
      params[$(this).prop("id")] = $(this).val();
      cantActi++;
    }
  });

  if (cantDesac > 0 || cantActi > 0) {
    var texto = "";
    texto = "¿Esta seguro que desea Desactivar " + cantDesac + " Departamentos?<br>";
    texto += "¿Esta seguro que desea Activar " + cantActi + " Departamentos?";
    $("#divDialog").html(texto);
    $("#divDialog").dialog({
      modal: true,
      width: "600px",
      height: "auto",
      resize: true,
      buttons: {
        "Si": function () {
          $("#divDialog").dialog("close");
          $.post('ajax/departamentos_ajax.php', params, function (data) {
            if (data.success) {
              listarDepartamentos();
            }
            else {
              showMessage('divEditDepartamentosMessage', data.error, 'error', 0);
            }
          }, 'json');
        },
        "No": function () {
          $("#divDialog").dialog("close");
        }
      }
    });
  } else {
    showMessage('divEditDepartamentosMessage', 'Debe seleccionar al menos un departamento para poder cambiar su estado', 'error', 8000);
  }


}
