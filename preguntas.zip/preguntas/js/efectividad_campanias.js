var title = "Efectividad de campañas";
var subAccion = "nuevo";
$(document).ready(function () {
  setTitle(title);
  $("#btnBuscar").button().click(function (event) {
    event.preventDefault();
    listarCampanias();
  });
  
  $("#fec_inicio, #fec_final").datepicker({
    dateFormat: 'yy-mm-dd'
  });
});

function listarCampanias() {
  showMessage('divMessage', "Listando las campañas . . .", 'message', 0);
  var params = {
    accion: 'listarCampanias',
    fec_inicio: $("#fec_inicio").val(),
    fec_final: $("#fec_final").val()
  };
  $.post('ajax/efectividad_campanias_ajax.php', params, function (data) {
    hideMessage('divMessage');
    $("#divReportCampanias").html(data);
    $("#tablaCampanias").tablesorter({
      sortList: [[0, 0]],
      widthFixed: true,
      widgets: ['zebra']
    });
  }, 'html');
}