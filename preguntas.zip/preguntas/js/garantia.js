var title = "Control de Garantias";
var subAccion = "";
$(document).ready(function () {

  setTitle(title);
  $("#btnBusqueda").button().click(function (event) {
    event.preventDefault();
    listarGarantias();
  });
  $("#textBusqueda").keyup(function (event) {
    event.preventDefault();
    if (event.keyCode == 13) {
      listarGarantias();
    }
  });
  $("#btnGuardar").button().click(function (event) {
    event.preventDefault();
    guardarGarantia();
  });
  $("#btnCancelar").button().click(function (event) {
    event.preventDefault();
    $("#divEditGarantias").dialog("close");
  });

  $("#divEditGarantias").dialog({
    autoOpen: false,
    modal: true,
    width: 700,
    height: "auto",
    title: title
  });

  listarGarantias();
});

function listarGarantias() {
  showMessage('divMessage', "Listando garantias . . .", 'message', 0);

  var params = {
    accion: 'listarGarantias',
    filtro: $("#textBusqueda").val()
  };
  $.post('ajax/garantia_ajax.php', params, function (data) {
    hideMessage('divMessage');
    $("#divListaGarantias").html(data);
    $("#tablaGarantias").tablesorter({
      sortList: [[0, 0]],
      widthFixed: true,
      widgets: ['zebra']
    });
  }, 'html');

}

function editarGarantia(tipo, garantia_id) {
  subAccion = tipo;
  hideMessage('divEditGarantiasMessage');

  if (tipo == 'nuevo') {
    $("#garantia_nombre").val("");
    $("#divEditGarantias").dialog('open');
  }
  else {
    showMessage('divMessage', "Cargando datos del garantia . . .", 'message', 0);
    var params = {
      accion: 'buscarGarantia',
      garantia_id: garantia_id
    };
    $.post('ajax/garantia_ajax.php', params, function (data) {
      if (data.success) {
        hideMessage('divMessage');
        $("#garantia_id").val(data.garantia_id);
        $("#sector_id").val(data.sector_id);
        $("#garantia_nombre").val(data.garantia_nombre);
        $("#divEditGarantias").dialog('open');
      }
      else {
        showMessage('divMessage', data.error, 'error', 8000);
      }
    }, 'json');
  }
}

function guardarGarantia() {
  var checkArray = checkField('garantia_nombre', 'Nombre', true, "string");
  if (checkArray.success) {
    var esNuevo = (subAccion == "nuevo");
    var texto = ((esNuevo) ? "Ingresando" : "Actualizando");

    showMessage('divEditGarantiasMessage', texto + " garantia . . .", 'message', 0);
    var params = {
      accion: 'guardarGarantia',
      tipo: subAccion,
      garantia_id: $('#garantia_id').val(),
      sector_id: $('#sector_id').val(),
      garantia_nombre: $('#garantia_nombre').val()
    };
    $.post('ajax/garantia_ajax.php', params, function (data) {
      if (data.success) {
        hideMessage('divEditGarantiasMessage');
        $("#divEditGarantias").dialog('close');
        listarGarantias();
      }
      else {
        showMessage('divEditGarantiasMessage', data.error, 'error', 8000);
      }
    }, 'json');

  }
  else {
    showMessage('divEditGarantiasMessage', checkArray.message, 'error', 8000);
    return false;
  }
}

function cambiarActivoGarantia(garantia_id, valor) {
  var texto = "";
  var accion = "";
  switch (valor) {
    case 'N':
      texto = "Desactivar";
      accion = "Desactivando";
      break;

    case 'S':
      texto = "Activar";
      accion = "Activando";
      break;
  }
  texto = "¿Esta seguro que desea " + texto + " esta garantia?";
  $("#divDialog").html(texto);
  $("#divDialog").dialog({
    modal: true,
    width: "600px",
    height: "auto",
    resize: true,
    title: title,
    buttons: {
      "Si": function () {
        $("#divDialog").dialog("close");
        showMessage('divMessage', accion + " garantia . . .", 'message', 0);
        var params = {
          accion: 'cambiarActivo',
          garantia_id: garantia_id,
          valor: valor
        };
        $.post('ajax/garantia_ajax.php', params, function (data) {
          if (data.success) {
            listarGarantias();
          }
          else {
            showMessage('divMessage', data.error, 'error', 0);
          }
        }, 'json');
      },
      "No": function () {
        $("#divDialog").dialog("close");
      }
    }
  });
}
