$(document).ready(function () {
  $("#button_login").button().click(function (event) {
    event.preventDefault();
    iniciarSesion();
  });
  $("#btnRecuperar").button().click(function (event) {
    event.preventDefault();
    recuperarContraseña();
  });
  $("#btnCancelar").button().click(function (event) {
    event.preventDefault();
    $("#divOSC").dialog('close');
  });
});

function iniciarSesion() {
  var checkArray = checkField('usuario_email', 'Email', true, "string");
  if (checkArray.success) {
    checkArray = checkField('usuario_passwd', 'Contraseña', true, "string");
    if (checkArray.success) {
      var params = {
        accion: 'iniciarSesion',
        email: $("#usuario_email").val(),
        password: $("#usuario_passwd").val()
      };
      $.post("ajax/login_ajax.php", params, function (data) {
        if (data.success) {
            window.location = "default_login";
          }
        else {
          showMessage('divMessage', data.error, 'error', 8000);
        }
      }, "json");
    }
    else {
      showMessage('divMessage', checkArray.message, 'error', 8000);
      return false;
    }
  }
  else {
    showMessage('divMessage', checkArray.message, 'error', 8000);
    return false;
  }
}

function iniciarOSC() {
  hideMessage('divEditMessage');
  $("#divOSC").dialog({
    modal: true,
    width: 400,
    height: 300
  });
}

function recuperarContraseña() {
  var checkArray = checkField('usuario_osc', 'Correo electrónico', true, "email");
  if (checkArray.success) {
    showMessage('divEditMessage', 'Validando el usuario . . .', 'message', 0);
    var params = {
      accion: 'recuperarContrasena',
      usuario_osc: $("#usuario_osc").val()
    };
    $.post('ajax/login_ajax.php', params, function (data) {
      if (data.success) {
        $("#divOSC").dialog('close');
        showMessage('divMessage', data.message, 'message', 8000);
      }
      else {
        showMessage('divOSCMessage', data.error, 'error', 8000);
      }
    }, 'json')
  }
  else {
    showMessage('divOSCMessage', checkArray.message, 'error', 8000);
    return false;
  }
}

function cancelarLogin() {
  window.location = "logout.php";
}



