var title = "Control de opciones";
var subAccion = "";
$(document).ready(function(){
  setTitle(title);
  $("#btnRoles").button().click(function(event){
    event.preventDefault();
    editarRol();
  });
  $("#btnAplicar").button().click(function(event){
    event.preventDefault();
    guardarRol();
  });
  $("#btnCancelar").button().click(function(event){
    event.preventDefault();
    $("#divEdit").dialog('close');
  });
  listarRegistros();
});

function listarRegistros(){
  var params = {
    accion : 'listarRegistros'
  };
  $.post('ajax/opciones_ajax.php', params, function(data){
    if(data.success){
      $("#divLista").html(data.message);
      $("#tablaLista").tablesorter({
      widthFixed: true,
      widgets: ['zebra']
    });
    }
    else{
      showMessage('divMessage', data.error, 'error', 8000);
    }
  }, 'json');
}

function editarRol(opcion_id){
  if(parseInt(opcion_id) > 0){
    $("#opcion_id").val(opcion_id);
    showMessage('divMessage', "Cargando roles . . .", 'message', 0);
    var params = {
      accion : 'editarRol',
      opcion_id : opcion_id
    };
    $.post('ajax/opciones_ajax.php', params, function(data){
      if(data.success){
        hideMessage('divMessage');
        hideMessage('divEditMessage');
        var titleEdit = "Roles para " + data.menu_nombre + ", " + data.opcion_nombre;
        showMessage('divNombreOpcion',titleEdit, 'message', 0);
        $("input:checkbox[name=rol_id]").prop('checked', false);
        if(data.roles != null){
          for(i = 0; i < data.roles.length; i++){
            $("#rol_id_" + data.roles[i]).prop('checked', true);
          }
        }
        $("#divEdit").dialog({
          modal: true,
          width : 400,
          height : "auto",
          title : title
        });
      }
      else{
        showMessage('divMessage', data.error, 'error', 8000);
      }
    
    }, 'json');
  }
  else{
    showMessage('divMessage', "Debe seleccionar una opción", 'error', 8000);
  }
}

function guardarRol(){
  var selectedItems = new Array();
		
  $("input:checkbox[name=rol_id]:checked").each(function(){
    selectedItems.push($(this).val());
  });
  var opcion_id = $("#opcion_id").val();
  var params = {
    accion : 'guardarRol',
    opcion_id : opcion_id,
    roles : selectedItems
  };
  showMessage('divEditMessage', "Aplicando cambios  . . .", 'message', 0);
  $.post('ajax/opciones_ajax.php', params, function(data){
    if(data.success){
      $("#divEdit").dialog('close');
      showMessage('divMessage', 'Los roles han sido aplicados!', 'message', 8000);
      listarRegistros();
    }
    else{
      showMessage('divEditMessage', data.error, 'error', 8000);
    }
  }, 'json');
}

