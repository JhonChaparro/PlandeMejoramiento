var title = "Póliza en trámite";
var subAccionAmparos = "nuevo";
var subAccionAsegurado = "";
$(document).ready(function () {

  setTitle(title);

  $("#btnGuardar").button().click(function (event) {
    event.preventDefault();
    guardarAseguradora();
  });
  $("#btnRechazar").button().click(function (event) {
    event.preventDefault();
    $("#estado").val('rechazada');
    estadoPoliza();

  });
  $("#btnReqInfo").button().click(function (event) {
    event.preventDefault();
    $("#estado").val('requiereInfo');
    estadoPoliza();

  });
  $("#btnConfirmarPago").button().click(function (event) {
    event.preventDefault();
    $("#estado").val('aprobarPago');
    ConfirmarPago();

  });

  $("#btnCancelar").button().click(function (event) {
    event.preventDefault();
    $("#popUpAseguradora").dialog("close");
  });

  $("#infopoliza").button().click(function (event) {
    event.preventDefault();
    $("#popUpinfoPoliza").dialog("open");
    $("#valor_contrato_info").val($("#valor_contrato_info_def").val());
    $("#valor_anticipo_info").val($("#valor_anticipo_info_def").val());
    $("#ref_contrato").val($("#ref_contrato_def").val());
    $("#motivo_poliza").val($("#motivo_poliza_def").val());
    $("#objeto").val($("#objeto_def").val());
    $("#sector").val($("#sector_def").val());
  });

  $("#btnCancelarInfopliza").button().click(function (event) {
    event.preventDefault();
    $("#popUpinfoPoliza").dialog("close");
  });

  $("#btnGuardarInfopliza").button().click(function (event) {
    event.preventDefault();
    actualizarInfoPoliza();
  });

  $("#afianzados").button().click(function (event) {
    event.preventDefault();
    $("#popUpAfianzados").dialog("open");
    $("#afi_nombre").val($("#afi_nombre_def").val());
    $("#afi_tipo_documento").val($("#afi_tipo_documento_def").val());
    $("#afi_identificacion").val($("#afi_identificacion_def").val());
    $("#afi_digit_ver").val($("#afi_digit_ver_def").val());
    $("#municipio_nombre").val($("#municipio_nombre_def").val());
    $("#municipio_id").val($("#municipio_id_def").val());
    $("#afi_direccion").val($("#afi_direccion_def").val());
    $("#afi_telefono").val($("#afi_telefono_def").val());
    $("#afi_email").val($("#afi_email_def").val());
  });

  $("#btnCancelarAfianzado").button().click(function (event) {
    event.preventDefault();
    $("#popUpAfianzados").dialog("close");
  });

  $("#btnGuardarAfianzado").button().click(function (event) {
    event.preventDefault();
    actualizarAfianzado();
  });

  $("#CambiarDepartamento").button().click(function (event) {
    event.preventDefault();
    $("#popUpDepartamento").dialog("open");
  });

  $("#btnCancelarDepartamento").button().click(function (event) {
    event.preventDefault();
    $("#popUpDepartamento").dialog("close");
  });

  $("#btnGuardarDepartamento").button().click(function (event) {
    event.preventDefault();
    actualizarDepartamento();
  });

  $("#btnCancelarAsegurados").button().click(function (event) {
    event.preventDefault();
    $("#popUpAsegurado").dialog("close");
  });

  $("#btnGuardarAsegurados").button().click(function (event) {
    event.preventDefault();
    agregarAsegurados();
  });

  $("#agregarDocumentos").button().click(function (event) {
    event.preventDefault();
    listarAdjuntos();
    $("#popUpDocumentos").dialog("open");
  });

  $("#btnCancelarDocumentos").button().click(function (event) {
    event.preventDefault();
    $("#popUpDocumentos").dialog("close");
    listarAdjuntos('tbodyAdjuntosOuter');
  });

  $("button[name=agregarAmparo]").button().click(function (event) {
    event.preventDefault();
  });

  $("button[name=EliminarGarantia]").button().click(function (event) {
    event.preventDefault();
  });

  $("#CambiarFechas").button().click(function (event) {
    event.preventDefault();
    $("#popUpFechas").dialog("open");
    $("#fec_contrato").val($("#fec_contrato_def").val());
    $("#fec_inicio").val($("#fec_inicio_def").val());
    $("#duracion_periodo").val($("#duracion_periodo_def").val());
    $("#periodo_tiempo_id").val($("#periodo_tiempo_id_def").val());
    $("#fec_final").val($("#fec_final_def").val());
    $("#dias_contrato").val($("#dias_def").val());
    $("#meses_contrato").val($("#meses_def").val());
    $("#anios_contrato").val($("#anios_def").val());
  });

  $("#btnCancelarFechas").button().click(function (event) {
    event.preventDefault();
    $("#popUpFechas").dialog("close");
  });

  $("#btnCargarArchivo").button().click(function (event) {
    event.preventDefault();
    if ($('#req_sarlaft').val() == 'S') {
      alertaSarlaft();
    } else {
      abrirPopUpCargarArchivos();
    }

  });

  $("#btnCancelarArchivo").button().click(function (event) {
    event.preventDefault();
    enviarCorreoEmitida();
  });

  $("#btnGuardarCodPol").button().click(function (event) {
    event.preventDefault();
    actualizarAseguradora();
  });
  $("#btnSiguiente1").button().click(function (event) {
    $("#cargarDocs").css("display", "none");
    $("#divObserv").css("display", "none");
    $("#btnSiguiente1").css("display", "none");
    $("#btnCancelarArchivo").css("display", "none");
    $("#cargarCod").css("display", "block");
    $("#btnSiguiente2").css("display", "inline-block");
  });
  $("#btnSiguiente2").button().click(function (event) {
    $("#cargarDocs").css("display", "none");
    $("#cargarCod").css("display", "none");
    $("#btnSiguiente1").css("display", "none");
    $("#btnSiguiente2").css("display", "none");
    $("#divObserv").css("display", "block");
    $("#btnCancelarArchivo").css("display", "inline-block");
  });
  $("#btnAgregarAmparo").button().click(function (event) {
    event.preventDefault();
    $("#divAmparos").dialog("open");
  });
  $("#btnCancelarCargarArchivos").button().click(function (event) {
    event.preventDefault();
    $("#popUpCargarArchivos").dialog("close");
  });

  $("#municipio_nombre_poliza").bind("keyup", function (event) {
    if ((event.keyCode === $.ui.keyCode.TAB || event.keyCode === $.ui.keyCode.ENTER) &&
            $(this).data("ui-autocomplete").menu.active) {
      event.preventDefault();
    }
    else {
      if ($(this).val().length > 1) {
        $(this).autocomplete({
          source: "ajax/poliza_ajax.php?action=buscarMunicipios",
          minLength: 1,
          select: function (event, ui) {
            $("#municipio_id_poliza").val(ui.item.id);
            $('#municipio_nombre_poliza').val(ui.item.value);
          },
          search: function () {
            $("#municipio_id").val("");
          },
          open: function (event, ui) {
            $(".ui-autocomplete").css("z-index", 1000);
          }
        });
      }
    }
  });

  $("#municipio_nombre").bind("keyup", function (event) {
    if ((event.keyCode === $.ui.keyCode.TAB || event.keyCode === $.ui.keyCode.ENTER) &&
            $(this).data("ui-autocomplete").menu.active) {
      event.preventDefault();
    }
    else {
      if ($(this).val().length > 1) {
        $(this).autocomplete({
          source: "ajax/poliza_ajax.php?action=buscarMunicipios",
          minLength: 1,
          select: function (event, ui) {
            $("#municipio_id").val(ui.item.id);
            $('#municipio_nombre').val(ui.item.value);
          },
          search: function () {
            $("#municipio_id").val("");
          },
          open: function (event, ui) {
            $(".ui-autocomplete").css("z-index", 1000);
          }
        });
      }
    }
  });

  $("#AsBe_municipio_nombre").bind("keyup", function (event) {
    if ((event.keyCode === $.ui.keyCode.TAB || event.keyCode === $.ui.keyCode.ENTER) &&
            $(this).data("ui-autocomplete").menu.active) {
      event.preventDefault();
    }
    else {
      if ($(this).val().length > 1) {
        $(this).autocomplete({
          source: "ajax/poliza_ajax.php?action=buscarMunicipios",
          minLength: 1,
          select: function (event, ui) {
            $("#AsBe_municipio_id").val(ui.item.id);
            $('#AsBe_municipio_nombre').val(ui.item.value);
          },
          search: function () {
            $("#municipio_id").val("");
          },
          open: function (event, ui) {
            $(".ui-autocomplete").css("z-index", 1000);
          }
        });
      }
    }
  });

  $('#popUpDocumentos').dialog({
    autoOpen: false,
    modal: true,
    height: "auto",
    width: 750,
    title: 'Agregar Documentos',
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    }
  });

  $('#popUpAsegurado').dialog({
    autoOpen: false,
    modal: true,
    height: "auto",
    width: 750,
    title: 'Agregar Asegurados o Beneficiarios',
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    }
  });

  $('#popUpDepartamento').dialog({
    autoOpen: false,
    modal: true,
    height: "auto",
    width: 750,
    title: 'Cambiar Municipio',
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    }
  });

  $('#popUpinfoPoliza').dialog({
    autoOpen: false,
    modal: true,
    height: "auto",
    width: 750,
    title: 'Cambiar Información Póliza',
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    }
  });

  $('#popUpPoliza').dialog({
    autoOpen: false,
    modal: true,
    height: "auto",
    width: 400,
    title: '',
    closeOnEscape: false,
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    }
  });

  $('#popUpAseguradora').dialog({
    autoOpen: false,
    modal: true,
    height: "auto",
    width: 1210,
    title: title,
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    }
  });

  $("#popUpAfianzados").dialog({
    autoOpen: false,
    modal: true,
    width: 700,
    height: "auto",
    title: "Cambiar Afianzado",
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    }
  });

  $("#popUpGarantia").dialog({
    autoOpen: false,
    modal: true,
    width: 700,
    height: "auto",
    title: "Cambiar Afianzado",
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    }
  });

  $("#popUpFechas").dialog({
    autoOpen: false,
    modal: true,
    width: 700,
    height: "auto",
    title: "Cambiar Fechas Del Contrato",
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    }
  });

  $("#popUpCargarArchivos").dialog({
    autoOpen: false,
    modal: true,
    width: 700,
    height: "auto",
    title: "Cargar archivos emitidos",
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    }
  });

  $('#validacionPoliza').dialog({
    autoOpen: false,
    modal: true,
    height: "auto",
    width: 400,
    title: 'Información Invalida',
    closeOnEscape: false,
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    },
    buttons: {
      "Cancelar": {
        click: function () {
          $(this).dialog('close');
        },
        text: 'Aceptar',
        class: 'btn btn-info'
      }
    }
  });

  $('#divAmparos').dialog({
    autoOpen: false,
    modal: true,
    height: "auto",
    width: "auto",
    title: 'Agregar Amparos',
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    }
  });

  $("#fec_contrato").datepicker({
    dateFormat: 'yy-mm-dd'
  });
  $("#fec_inicio").datepicker({
    dateFormat: 'yy-mm-dd',
    onSelect: recalcularFinVigencia
  });
  $("input[name=fec_poliza]").datepicker({
    dateFormat: 'yy-mm-dd'
  });
  $("#dias").keyup(function () {
    calcularFinVigencia('fec_inicio', 'dias', 'meses', 'anios', 'fec_final_amparo');
  });
  $("#meses").keyup(function () {
    calcularFinVigencia('fec_inicio', 'dias', 'meses', 'anios', 'fec_final_amparo');
  });
  $("#anios").keyup(function () {
    calcularFinVigencia('fec_inicio', 'dias', 'meses', 'anios', 'fec_final_amparo');
  });
  $("#dias_contrato").keyup(function () {
    calcularFinVigencia('fec_inicio', 'dias_contrato', 'meses_contrato', 'anios_contrato', 'fec_final');
  });
  $("#meses_contrato").keyup(function () {
    calcularFinVigencia('fec_inicio', 'dias_contrato', 'meses_contrato', 'anios_contrato', 'fec_final');
  });
  $("#anios_contrato").keyup(function () {
    calcularFinVigencia('fec_inicio', 'dias_contrato', 'meses_contrato', 'anios_contrato', 'fec_final');
  });

  listarAdjuntos('tbodyAdjuntosOuter', 'E');

  calcularTotalAsegurado();

});

function guardarAseguradora() {

  if ($("#estado").val() == 'aprobada') {
    $("input[name=check_aseg]").each(function () {
      if ($(this).prop('checked')) {
        aseguradora_id = $(this).val();
        aseguradora_nombre = $("#nombre_aseguradora_" + aseguradora_id).html();
        $("input[name=garantia_id_" + aseguradora_id + "]").each(function () {
          garantia_id = $(this).val();
          garantia_nombre = $("#garantia_nombre_" + aseguradora_id + "_" + garantia_id).val();
          if ($("#valor_prima_" + aseguradora_id + "_" + garantia_id).val() != '') {
            if (!$.isNumeric($("#valor_prima_" + aseguradora_id + "_" + garantia_id).val())) {
              showMessage('divPolizaMessage', 'La prima para la garantia ' + garantia_nombre + ' de la aseguradora ' + aseguradora_nombre + ' debe ser numerico', 'error', 8000);
              $.end();
            }
          } else {
            $('#popUpPoliza').dialog('close');
            showMessage('divPolizaMessage', 'La prima para la garantia ' + garantia_nombre + ' de la aseguradora ' + aseguradora_nombre + ' no puede estar vacia', 'error', 8000);
            $.end();
          }

          if ($("#gastos_expedicion_" + aseguradora_id + "_" + garantia_id).val() != '') {
            if (!$.isNumeric($("#gastos_expedicion_" + aseguradora_id + "_" + garantia_id).val())) {
              showMessage('divPolizaMessage', 'Los gastos de expedición para la garantia ' + garantia_nombre + ' de la aseguradora ' + aseguradora_nombre + ' debe ser numerico', 'error', 8000);
              $.end();
            }
          } else {
            $('#popUpPoliza').dialog('close');
            showMessage('divPolizaMessage', 'Los gastos de expedición para la garantia ' + garantia_nombre + ' de la aseguradora ' + aseguradora_nombre + ' no puede estar vacia', 'error', 8000);
            $.end();
          }

          if ($("#iva_" + aseguradora_id + "_" + garantia_id).val() != '') {
            if (!$.isNumeric($("#iva_" + aseguradora_id + "_" + garantia_id).val())) {
              showMessage('divPolizaMessage', 'El iva para la garantia ' + garantia_nombre + ' de la aseguradora ' + aseguradora_nombre + ' debe ser numerico', 'error', 8000);
              $.end();
            }
          } else {
            $('#popUpPoliza').dialog('close');
            showMessage('divPolizaMessage', 'El iva para la garantia ' + garantia_nombre + ' de la aseguradora ' + aseguradora_nombre + ' no puede estar vacia', 'error', 8000);
            $.end();
          }
        });
      }
    });
  }

  var checkArray = checkField('observaciones', 'observaciones', ($("#estado").val() != 'aprobada'), 'string');
  if (checkArray.success) {
    showProcessingDialog("Guardando la información, por favor espere un momento...");
    var params = {
      action: 'guardarAseguradora',
      poliza_id: $('#poliza_id').val(),
      observaciones: $('#observaciones').val(),
      estado: $('#estado').val(),
      correo_afianzado: $('#correo_afianzado').val(),
      metodo_pago_id: $('#metodo_pago_id').val(),
      aseguradora_id: $('#aseguradora_id').val()
    };

    var valAseguradora = 0;
    if ($("#estado").val() == 'aprobada') {
      $("input[name=check_aseg]").each(function () {
        if ($(this).prop('checked')) {
          params[$(this).prop("id")] = $(this).val();
          valAseguradora++;

          aseguradora_id = $(this).val();
          $("input[name=garantia_id_" + aseguradora_id + "]").each(function () {
            garantia_id = $(this).val();
            params[$("#valor_prima_" + aseguradora_id + "_" + garantia_id).prop("id")] = $("#valor_prima_" + aseguradora_id + "_" + garantia_id).val();

            params[$("#gastos_expedicion_" + aseguradora_id + "_" + garantia_id).prop("id")] = $("#gastos_expedicion_" + aseguradora_id + "_" + garantia_id).val();

            params[$("#iva_" + aseguradora_id + "_" + garantia_id).prop("id")] = $("#iva_" + aseguradora_id + "_" + garantia_id).val();

          });


          params[$("#dia_" + aseguradora_id).prop("id")] = $("#dia_" + aseguradora_id).val();

          params[$("#hora_" + aseguradora_id).prop("id")] = $("#hora_" + aseguradora_id).val();

          params[$("#min_" + aseguradora_id).prop("id")] = $("#min_" + aseguradora_id).val();
          
          params[$("#obser_aseg_" + aseguradora_id).prop("id")] = $("#obser_aseg_" + aseguradora_id).val();

        }
      });

      $("input[name=req_sarlaft]").each(function () {
        if ($(this).prop('checked')) {
          params[$(this).prop("id")] = $(this).val();
        }
      });
    } else {
      valAseguradora = 1;
    }

    if (valAseguradora != 0) {
//      console.log(params);
      $.post('ajax/poliza_ajax.php', params, function (data) {
        hideProccessingDialog();
        if (data.success) {
          window.location = "polizas_tramite";
        }
        else {
          $('#popUpPoliza').dialog('close');
          showMessage('divPolizaMessage', data.error, 'error', 8000);
        }
      }, 'json');
    } else {
      hideProccessingDialog();
      showMessage('divPolizaMessage', 'Por favor seleccione la aseguradora', 'error', 8000);
    }
  } else {
    $('#popUpPoliza').dialog('close');
    showMessage('divPolizaMessage', checkArray.message, 'error', 8000);
  }
}

function limpiarPopUp() {
  $("input[name=valor_prima]").each(function () {
    $(this).val('');
  });

  $("input[name=gastos_expedicion]").each(function () {
    $(this).val('');
  });

  $("input[name=iva]").each(function () {
    $(this).val('');
  });

  $("input[name=total_pagar]").each(function () {
    $(this).val('');
  });

  $("input[name=check_aseg]").each(function () {
    $(this).prop('checked', false);
  });
  hideMessage('divPolizaMessage');
  $("#observaciones").val('');
}

function estadoPoliza() {
  $("#aseguradoras").attr('style', 'display: none');
  $("#confirmarPago").attr('style', 'display: none');
  limpiarPopUp();
  $("#popUpAseguradora").dialog("open");
}

function ConfirmarPago() {
  $("#aseguradoras").attr('style', 'display: none');
  $("#confirmarPago").attr('style', 'display: inline');
  limpiarPopUp();
  $("#popUpAseguradora").dialog("open");
}

function validarArchivoPDF() {
  var extension = $("#cargar_poliza").val().split('.').pop();
  if (extension == 'pdf') {
    $('#divMessage').css('color', 'green');
    $('#divMessage').html("El archivo es válido para subir");
    $('#submit').prop("disabled", false);
  } else {
    $('#divMessage').css('color', 'red');
    $('#divMessage').html("El archivo no es válido, debe ser un archivo PDF");
    $('#submit').prop("disabled", true);
  }
}

function cargarMunicipios() {
  showProcessingDialog("Cargando los municipios del departamento ...");
//  console.log($("#departamento_id option:selected").index());
  var params = {
    action: "cargarMunicipios",
    departamento_id: $("#departamento_id option:selected").index()
  };
  $.post('ajax/poliza_ajax.php', params, function (data) {
    hideProccessingDialog();
    if (data.success) {
      $("#municipio_id").empty();
      if (data.content != null && data.content.length > 0) {
        for (x in data.content) {
          municipio = data.content[x];
          var html = '<option value="' + municipio.municipio_id + '">' + municipio.municipio_nombre + '</option>';
          $("#municipio_id").append(html);
        }
        $("#divListaMunicipios").css("display", "inline");
      }
      else {
        showMessage('divMessage', "Lo sentimos, este departamento no tiene municipios habilitados", 'warning', 8000);
      }
    }
    else {
      showMessage('divMessage', data.error, 'error', 8000);
    }
  }, 'json');
}

function actualizarInfoPoliza() {
  var checkArray = checkField("valor_contrato_info", "Valor del Contrato", true, "float2");
  if (checkArray.success) {
    var checkArray = checkField("valor_anticipo_info", "Anticipo", true, "float2");
    if (checkArray.success) {
      var checkArray = checkField("ref_contrato", "Referencia del Contrato", true, "string");
      if (checkArray.success) {
        var checkArray = checkField("sector", "Sector", true, "int");
        if (checkArray.success) {
          var checkArray = checkField("motivo_poliza", "Motivo o giro del negocio", true, "int");
          if (checkArray.success) {
            var checkArray = checkField("objeto", "Objeto del Contrato", true, "string");
            if (checkArray.success) {
              var tipo_anticipo = $("input:radio[name=tipo_anticipo]:checked").val();
              var valor_anticipo = $("#valor_anticipo_info").val();
              var valor_contrato = $("#valor_contrato").val();
              if (tipo_anticipo == 'P') {
                if (parseFloat(valor_anticipo) > 100) {
                  showMessage('divEditinfoPolizaMessage', "El porcentaje no puede ser mayor que 100", 'error', 8000);
                  return;
                }
              } else {
                if (parseFloat(valor_anticipo) > parseFloat(valor_contrato)) {
                  showMessage('divEditinfoPolizaMessage', "El valor del anticipo no puede ser mayor que el valor del contrato", 'error', 8000);
                  return;
                }
              }
              showProcessingDialog("Guardando la información, por favor espere un momento ...");
              var params = {
                action: "actualizarInfoPoliza",
                poliza_id: $("#poliza_id").val(),
                valor_contrato: $("#valor_contrato_info").val(),
                valor_anticipo: $("#valor_anticipo_info").val(),
                tipo_anticipo: $("input:radio[name=tipo_anticipo]:checked").val(),
                ref_contrato: $("#ref_contrato").val(),
                motivo_poliza: $("#motivo_poliza").val(),
                objeto: $("#objeto").val(),
                sector: $("#sector").val()
              };
              $.post('ajax/poliza_ajax.php', params, function (data) {
                hideProccessingDialog();
                if (data.success) {
                  location.reload();
                }
                else {
                  hideProccessingDialog();
                  showMessage('divEditinfoPolizaMessage', data.error, 'error', 8000);
                }
              }, 'json');
            }
            else {
              showMessage('divEditinfoPolizaMessage', checkArray.message, 'error', 8000);
            }
          }
          else {
            showMessage('divEditinfoPolizaMessage', checkArray.message, 'error', 8000);
          }
        }
        else {
          showMessage('divEditinfoPolizaMessage', checkArray.message, 'error', 8000);
        }
      }
      else {
        showMessage('divEditinfoPolizaMessage', checkArray.message, 'error', 8000);
      }
    }
    else {
      showMessage('divEditinfoPolizaMessage', checkArray.message, 'error', 8000);
    }
  }
  else {
    showMessage('divEditinfoPolizaMessage', checkArray.message, 'error', 8000);
  }
}

function actualizarAfianzado() {
  var checkArray = checkField("afi_nombre", "Nombres", true, "string");
  if (checkArray.success) {
    var checkArray = checkField("afi_tipo_documento", "Tipo de documento", true, "int");
    if (checkArray.success) {
      var checkArray = checkField("afi_identificacion", "Número de identificación", true, "int");
      if (checkArray.success) {
        var checkArray = checkField("municipio_nombre", "Ciudad de residencia", true, "string");
        if (checkArray.success) {
          var checkArray = checkField("afi_telefono", "Telefono", true, "int");
          if (checkArray.success) {
            var checkArray = checkField("afi_direccion", "Dirección", true, "string");
            if (checkArray.success) {
              var checkArray = checkField("afi_email", "Correo electrónico", true, "email");
              if (checkArray.success) {
                var tipo_documento_id = $("#afi_tipo_documento").val();
                if (parseInt(tipo_documento_id) <= 2) {
                  var checkArray = checkField("afi_digit_ver", "Dígito de verificación", true, "int");
                  if (!checkArray.success) {
                    showMessage('divEditAfianzadosMessage', "El Dígito de verificación es requerido para el tipo de documento " + $("#tipo_documento_id option:selected").text(), 'error', 8000);
                    return;
                  }
                }
                showProcessingDialog("Guardando la información, por favor espere un momento ...");
                var params = {
                  action: 'actualizarAfianzado',
                  poliza_id: $("#poliza_id").val(),
                  documento_id: $("#afi_tipo_documento").val(),
                  identificacion: $("#afi_identificacion").val(),
                  digit_ver: $("#afi_digit_ver").val(),
                  nombres: $("#afi_nombre").val(),
                  email: $("#afi_email").val(),
                  telefono: $("#afi_telefono").val(),
                  direccion: $("#afi_direccion").val(),
                  lug_res_afi: $("#municipio_id").val()
                };
                $.post('ajax/poliza_ajax.php', params, function (data) {
                  if (data.success) {
                    location.reload();
                  }
                  else {
                    hideProccessingDialog();
                    showMessage('divEditAfianzadosMessage', data.error, 'error', 8000);
                  }
                }, 'json');
              }
              else {
                showMessage('divEditAfianzadosMessage', checkArray.message, 'error', 8000);
              }
            }
            else {
              showMessage('divEditAfianzadosMessage', checkArray.message, 'error', 8000);
            }
          }
          else {
            showMessage('divEditAfianzadosMessage', checkArray.message, 'error', 8000);
          }
        }
        else {
          showMessage('divEditAfianzadosMessage', checkArray.message, 'error', 8000);
        }
      }
      else {
        showMessage('divEditAfianzadosMessage', checkArray.message, 'error', 8000);
      }
    }
    else {
      showMessage('divEditAfianzadosMessage', checkArray.message, 'error', 8000);
    }
  }
  else {
    showMessage('divEditAfianzadosMessage', checkArray.message, 'error', 8000);
  }
}

function actualizarDepartamento() {
  var checkArray = checkField("municipio_nombre_poliza", "municipio o ciudad", true, "string");
  if (checkArray.success) {
    showProcessingDialog("Guardando la información, por favor espere un momento ...");
    var params = {
      action: 'actualizarDepartamento',
      poliza_id: $("#poliza_id").val(),
      municipio_id: $("#municipio_id_poliza").val()
    };
    $.post('ajax/poliza_ajax.php', params, function (data) {
      if (data.success) {
        location.reload();
      }
      else {
        hideProccessingDialog();
        showMessage('divEditDepartamentoMessage', data.error, 'error', 8000);
      }
    }, 'json');
  }
  else {
    showMessage('divEditDepartamentoMessage', checkArray.message, 'error', 8000);
  }
}

function eliminarAsegurado(poliza_asegurado_id, texto) {
  $("#texto").html(texto);
  $("#eliminarAsegurado").dialog({
    autoOpen: true,
    modal: true,
    title: "Eliminar Asegurado",
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    },
    buttons: {
      "Aceptar": {
        click: function () {
          showProcessingDialog("Eliminando el asegurado, por favor espere un momento ...");
          var params = {
            action: 'eliminarAsegurado',
            poliza_asegurado_id: poliza_asegurado_id
          };
          $.post('ajax/poliza_ajax.php', params, function (data) {
            if (data.success) {
              location.reload();
            }
            else {
              $(this).dialog("close");
              showMessage('divMessage', data.error, 'error', 8000);
            }
          }, 'json');
        },
        text: 'Aceptar',
        class: 'btn btn-info'
      },
      "Cancelar": {
        click: function () {
          $(this).dialog('close');
        },
        text: 'Cancelar',
        class: 'btn btn-default'
      }
    }
  });
}

function agregarAsegurados() {
  var checkArray = checkField("AsBe_nombre", "Nombres", true, "string");
  if (checkArray.success) {
    var checkArray = checkField("AsBe_tipo_documento", "Tipo de documento", true, "int");
    if (checkArray.success) {
      var checkArray = checkField("AsBe_identificacion", "Número de identificación", true, "int");
      if (checkArray.success) {
        var checkArray = checkField("AsBe_telefono", "Telefono", false, "int");
        if (checkArray.success) {
          var checkArray = checkField("AsBe_email", "Correo electrónico", false, "email");
          if (checkArray.success) {
            var tipo_documento_id = $("#AsBe_tipo_documento").val();
            if (parseInt(tipo_documento_id) == 2) {
              var checkArray = checkField("AsBe_digit_ver", "Dígito de verificación", true, "int");
              if (!checkArray.success) {
                showMessage('divEditAsegBeneMessage', "El Dígito de verificación es requerido para el tipo de documento " + $("#tipo_documento_id option:selected").text(), 'error', 8000);
                return;
              }
            }
            showProcessingDialog("Guardando la información, por favor espere un momento ...");
            var params = {
              action: 'agregarBeneficiario',
              tipo: subAccionAsegurado,
              poliza_id: $("#poliza_id").val(),
              nombres: $("#AsBe_nombre").val(),
              documento_id: $("#AsBe_tipo_documento").val(),
              identificacion: $("#AsBe_identificacion").val(),
              digit_ver: $("#AsBe_digit_ver").val(),
              municipio_id: $("#AsBe_municipio_id").val(),
              direccion: $("#AsBe_direccion").val(),
              telefono: $("#AsBe_telefono").val(),
              email: $("#AsBe_email").val(),
              poliza_asegurado_id: $("#AsBe_poliza_asegurado_id").val()
            };

            var cont = 0;
            $("input[name=tipoPer]").each(function () {
              if ($(this).prop('checked')) {
                params[$(this).prop("id")] = $(this).val();
                cont++;
              }
            });
//            console.log(params);
            if (cont != 0) {
              $.post('ajax/poliza_ajax.php', params, function (data) {
                if (data.success) {
                  location.reload();
                }
                else {
                  hideProccessingDialog();
                  showMessage('divEditAsegBeneMessage', data.error, 'error', 8000);
                }
              }, 'json');
            }
            else {
              hideProccessingDialog();
              showMessage('divEditAsegBeneMessage', 'Debe seleccionar un asegurado y/o beneficiario', 'error', 8000);
            }
          }
          else {
            showMessage('divEditAsegBeneMessage', checkArray.message, 'error', 8000);
          }
        }
        else {
          showMessage('divEditAsegBeneMessage', checkArray.message, 'error', 8000);
        }
      }
      else {
        showMessage('divEditAsegBeneMessage', checkArray.message, 'error', 8000);
      }
    }
    else {
      showMessage('divEditAsegBeneMessage', checkArray.message, 'error', 8000);
    }
  }
  else {
    showMessage('divEditAsegBeneMessage', checkArray.message, 'error', 8000);
  }
}

function cargarAdjunto(clasif_docum) {
  var checkArray = checkField("archivo", "Archivo", true, "string");
  if (checkArray.success) {
    var checkArray = checkField("descripcion", "Descripción", true, "string");
    if (checkArray.success) {
      showProcessingDialog("Guardando la información, Por favor espere un momento ...");
      var data = new FormData();
      data.append("archivo", document.getElementById("archivo").files[0]);
      data.append("descripcion", $("#descripcion").val());
      data.append("action", "cargarAdjunto");
      data.append("clasif_docum", clasif_docum);
      data.append("poliza_id", $('#poliza_id').val());
//      console.log(data);
      $.ajax({
        url: 'ajax/poliza_ajax.php',
        type: 'POST',
        data: data,
        cache: false,
        processData: false, // Don't process the files
        contentType: false, // Set content type to false as jQuery will tell the server its a query string request
        dataType: 'json',
        success: function (data, textStatus, jqXHR)
        {
          hideProccessingDialog();
          if (data.success)
          {
            listarAdjuntos(null, clasif_docum);
          }
          else
          {
            showMessage('divEditMessage', data.error, 'error', 8000);
          }
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
          hideProccessingDialog();
          showMessage('divEditMessage', textStatus, 'error', 8000);
        }
      });
    }
    else {
      showMessage('divEditMessage', checkArray.message, 'error', 8000);
    }
  }
  else {
    showMessage('divEditMessage', checkArray.message, 'error', 8000);
  }
}

function listarAdjuntos(tbody, clasif_docum) {
  if (tbody == null) {
    tbody = "tbodyAdjuntos";
  }
  $("#" + tbody).html("");
  documentos = 0;
  var params = {
    action: 'listarAdjuntos',
    clasif_docum: clasif_docum,
    poliza_id: $('#poliza_id').val()
  };
  showProcessingDialog("Listando los archivos adjuntos ...");
  $.post('ajax/poliza_ajax.php', params, function (data) {
    hideProccessingDialog();
    if (data.success) {
      var html = "";
      if (data.content.length > 0) {
        for (i in data.content) {
          row = data.content[i];
          html += '<tr><td><a href="documento.php?key=' + row.key + '">';
          if (row.poliza_docum_activo == 'N') {
            html += '<del>'
          }
          html += row.desc_documento;
          if (row.poliza_docum_activo == 'N') {
            html += '</del>'
          }
          html += '</a></td>';
          if (row.poliza_docum_activo == 'S') {
            html += '<td><span class="glyphicon glyphicon-ban-circle" style="cursor:pointer;" onclick="javascript:cambiarEstadoDocumentos(' + row.poliza_docum_id + ',\'N\', \'' + tbody + '\');" title="Inactivar Documento"></span></td></tr>';
          } else {
            html += '<td><span class="glyphicon glyphicon-ok-circle" style="cursor:pointer;" onclick="javascript:cambiarEstadoDocumentos(' + row.poliza_docum_id + ',\'S\', \'' + tbody + '\');" title="Activar Documento"></span></td></tr>';
          }
          html += '</tr>';
          documentos++;
        }
      }
      else {
        html = "<tr><td>No hay archivos adjuntos<td></tr>";
      }
      $("#" + tbody).html(html);
    }
    else {
      showMessage('divEditMessage', data.error, 'error', 8000);
    }
  }, 'json');
}

function eliminarAmparo(poliza_amparo_id) {
  $("#eliminarAmparo").dialog({
    autoOpen: true,
    modal: true,
    title: "Eliminar Amparo",
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    },
    buttons: {
      "Aceptar": {
        click: function () {
          showProcessingDialog("Eliminando el amparo, por favor espere un momento ...");
          var params = {
            action: 'eliminarAmparo',
            poliza_amparo_id: poliza_amparo_id
          };
          $.post('ajax/poliza_ajax.php', params, function (data) {
            if (data.success) {
              location.reload();
            }
            else {
              $(this).dialog("close");
              showMessage('divMessage', data.error, 'error', 8000);
            }
          }, 'json');
        },
        text: 'Aceptar',
        class: 'btn btn-info'
      },
      "Cancelar": {
        click: function () {
          $(this).dialog('close');
        },
        text: 'Cancelar',
        class: 'btn btn-default'
      }
    }
  });
}

function cargarAmparos(fec_inicio, fec_final, tipo) {
  showProcessingDialog("Cargando los amparos de la garantia ...");
  subAccionAmparos = tipo;
  var params = {
    action: "cargarAmparos"
//    garantia_id: garantia_id
  };
  $.post('ajax/poliza_ajax.php', params, function (data) {
    hideProccessingDialog();
    if (data.success) {
      $("#divAmparos").text("");
      if (data.amparos != null && data.amparos.length > 0) {
        var tablaAmparos = '<table class="table">\n\
                              <thead>\n\
                                <tr>\n\
                                  <th>Amparo</th>\n\
                                  <th>Valor o Porcentaje</th>\n\
                                  <th>Liquidación</th>\n\
                                </tr>\n\
                              <tbody>';
        var textPeriodo = '<input type="text" id="duracion" value="" style="width:30px; text-align: right;" onchange="javascript:calcularFechaFinVigencia(\'periodo\', \'duracion\', \'' + fec_final + '\', false);"/>';
        var hiddenFecFinal = '<input type="hidden" id="fec_final"/>';
        var vig_no_def = '<br/><input type="checkbox" id="vig_no_def" onclick="javascript:verificarVigNoDef();"/>Vigencia no definida';
        var selectAmparos = '<select id="amparos" style="background-color: transparent;" onchange="javascript:mostrarFechaInicio(\'' + fec_final + '\',\'' + fec_inicio + '\');">';
        for (x in data.amparos) {
          amparo = data.amparos[x];
          selectAmparos += '<option value="' + amparo.amparo_id + '">' + amparo.amparo_nombre + '</option>';
        }
        var valor = '<input type="text" id="valor_amparo"  style="text-align: right;" onkeyup="calcularValorAsegurado();"/>';
        var selectPeriodo = '<select id="periodo" style="background-color: transparent;" onchange="javascript:calcularFechaFinVigencia(\'periodo\', \'duracion\', \'' + fec_final + '\', false);">';
        for (z in data.periodo_tiempos) {
          periodo_tiempo = data.periodo_tiempos[z];
          selectPeriodo += '<option value="' + periodo_tiempo.param_sql + '">' + periodo_tiempo.nombre_periodo + '</option>';
        }

        var liquidacion = '';
        for (y in data.tipo_liqui) {
          tipo_liqui = data.tipo_liqui[y];
          liquidacion += '<input type="radio" name="tipo_liqui" id="tipo_liqui" value="' + tipo_liqui.tipo_liqui_id + '" onclick="calcularValorAsegurado();" checked="true"/>  ' + tipo_liqui.amparo_liqui_nombre + '<br>';
        }
        selectPeriodo += '</select>';
        tablaAmparos += '<tr><td>' + selectAmparos + '</td>';
        tablaAmparos += '<td>' + valor + '</td>';
        tablaAmparos += '<td>' + liquidacion + '</td></tr>';
        tablaAmparos += '</tbody>\n\
                         <thead>\n\
                          <tr>\n\
                            <th colspan="3" style="text-align: center;">Fecha de finalización o Vigencia adicional</th>\n\
                         </th>\n\
                        <tbody>';
        tablaAmparos += '<tr>\n\
                          <td colspan="3">\n\
                            <div style="display: inline-block">\n\
                              <label>Días: </label><br>\n\
                              <input type="text" id="dias" placeholder="Duración en días" style="text-align: right;"/>\n\
                            </div>\n\
                            <div style="display: inline-block">\n\
                              <label>Meses: </label><br>\n\
                              <input type="text" id="meses" placeholder="Duración en meses" style="text-align: right;"/><br>\n\
                            </div>\n\
                            <div style="display: inline-block">\n\
                              <label>Años: </label><br>\n\
                              <input type="text" id="anios" placeholder="Duración en años" style="text-align: right;"/>\n\
                            </div>\n\
                            <div style="display: inline-block">\n\
                              <span id="spanFecFinal">&nbsp;</span>\n\
                            </div>\n\
                          </td>\n\
                        </tr>';
        tablaAmparos += '</tbody>\n\
                         <thead>\n\
                          <tr>\n\
                            <th>Vigencia Inicial</th>\n\
                            <th>Fecha de finalización o Vigencia adicional</th>\n\
                            <th>Valor Asegurado\n\
                         </th>\n\
                        <tbody>';
        tablaAmparos += '<tr><td><span id="fechaInicial"></span><input type="hidden" id="fec_inicio"/></td>';
        tablaAmparos += '<td>' + textPeriodo + hiddenFecFinal + '&nbsp;&nbsp;' + selectPeriodo + vig_no_def + '<br/><span id="spanFecFinal">&nbsp;</span></td>';
        tablaAmparos += '<td><span id="spanValAseg"></span><input type="hidden" id="hiddenValAseg"/><input type="hidden" id="poliza_amparo_id"/></td></tr>';
      }

      tablaAmparos += '</tbody></table>';
      tablaAmparos += '<br/><div id="divEditAmparosMessage" style="text-align: center;"></div>';
      tablaAmparos += ' <center>\n\
                          <hr> \n\
                          <button class="btn btn-info" id="btnGuardarAmparo" onclick="javascript:guardarAmparos();">Guardar</button>\n\
                          <button class="btn btn-default" id="btnCancelarAmparo" onclick="javascript:cerrarPopUpAmparos();">Cancelar</button> \n\
                        </center>';

      $("#divAmparos").html(tablaAmparos);
      $('#divAmparos').dialog({
        autoOpen: true,
        modal: true,
        height: "auto",
        width: "auto",
        title: 'Agregar Amparos',
        open: function (event, ui) {
          $(this).parent().find(".ui-dialog-titlebar-close").remove();
        }
      });
    }
    else {
      showMessage('divMessage', data.error, 'error', 8000);
    }
  }, 'json');
}

function cerrarPopUpAmparos() {
  $("#divAmparos").dialog("close");
  limpiarFormularioAmparos();
}

function calcularValorAsegurado() {
  var valorAsegurado = 0;
  var valor_amparo = $("#valor_amparo").val();
  var tipo_liqui_id = "";
  $("input:radio[name=tipo_liqui]").each(function () {
    if ($(this).prop('checked')) {
      tipo_liqui_id = $(this).val();
    }
  });
  if (valor_amparo > 0 && tipo_liqui_id > 0) {
    var fuente_valor = 0;
    switch (parseInt(tipo_liqui_id)) {
      case 1:
        fuente_valor = parseInt($("#valor_contrato").val()) / 100;
        break;

      case 2:
        tipo_anticipo = $("#tipo_anticipo").val();
        if (tipo_anticipo == 'P') {
          fuente_valor = ((parseInt($("#valor_contrato").val()) / 100) * parseInt($("#valor_anticipo").val())) / 100;
        }
        else if (tipo_anticipo == 'F') {
          fuente_valor = parseInt($("#valor_anticipo").val()) / 100;
        }
        break;

      case 3:
        fuente_valor = 1;
        break;

      case 4:
        fuente_valor = $("#smmlv").val();
        break;

    }
    valorAsegurado = fuente_valor * valor_amparo;
  }
  $("#spanValAseg").html(valorAsegurado);
  $("#hiddenValAseg").val(valorAsegurado);
}

function calcularFechaFinVigencia(periodo_tiempo, duracion_periodo, fecha_inicio, calendario) {
  var periodoTiempo = $('#' + periodo_tiempo).val();
  if (periodoTiempo != 'DETERMINADA') {
    if (calendario) {
      $("#divCalendarFecFin").datepicker('disable');
    }
    var checkArray = checkField(duracion_periodo, "Duración", true, "int");
    if (checkArray.success) {
      var checkArray = checkField(periodo_tiempo, "Periodo de tiempo", true, "string");
      if (checkArray.success) {
        var params = {
          action: "calcularFechaFinVigencias",
          duracion: $('#' + duracion_periodo).val(),
          periodo_tiempo: $('#' + periodo_tiempo).val(),
          fecha_inicio: fecha_inicio
        };
        $.post('ajax/poliza_ajax.php', params, function (data) {
          hideProccessingDialog();
          if (data.success) {
            if (calendario) {
              $("#divCalendarFecFin").datepicker("setDate", data.fec_final);
              $("#fec_final").val(data.fec_final);
            } else {
              $("#spanFecFinal").html('Hasta el ' + data.fec_final);
              $("#fec_final").val(data.fec_final);
            }

          }
          else {
            showMessage('divEditAmparosMessage', data.error, 'error', 8000);
          }
        }, 'json');
      } else {
        showMessage('divEditAmparosMessage', checkArray.message, 'error', 8000);
      }
    } else {
      showMessage('divEditAmparosMessage', checkArray.message, 'error', 8000);
    }
  } else {
    $("#divCalendarFecFin").datepicker('enable');
    fechaInicio = $.datepicker.formatDate('yy-mm-dd', new Date($.datepicker.parseDate('yy-mm-dd', fecha_inicio).getTime() + (120 * 1000 * 60 * 60 * 24)));
    $("#" + duracion_periodo).val('');
    $("#spanFecFinal").html('Hasta el ' + fechaInicio);
    $("#fec_final").val(fechaInicio);
  }
}

function mostrarFechaInicio(fec_final, fec_inicio) {
  var params = {
    action: "buscarAmparosGarantia",
    amparo_id: $('#amparos').val()
  };
  $.post('ajax/poliza_ajax.php', params, function (data) {
    hideProccessingDialog();
//    console.log(data);
    if (data.success) {
      var textVigenciaInicio = "";
      var fechaInicio = "";
      if (data.tipo_amparo_id == 1) {
        fechaInicio = $.datepicker.formatDate('yy-mm-dd', new Date());
        textVigenciaInicio = "Desde hoy: " + fechaInicio;
      }
      else if (data.tipo_amparo_id == 2) {
        fechaInicio = fec_inicio;
        textVigenciaInicio = "Desde el " + fec_inicio + " hasta el " + fec_final;
      }
      else {
        fechaInicio = $.datepicker.formatDate('yy-mm-dd', new Date($.datepicker.parseDate('yy-mm-dd', fec_final).getTime() + (1000 * 60 * 60 * 24)));
        textVigenciaInicio = "Desde el " + fechaInicio;
      }

      $("#fechaInicial").html(textVigenciaInicio);
      $("#fec_inicio").val(fechaInicio);
    }
    else {
      showMessage('divEditAmparosMessage', data.error, 'error', 8000);
    }
  }, 'json');
}

function guardarAmparos() {
  var checkArray = checkField("amparos", "Amparo", true, "int");
  if (checkArray.success) {
    var checkArray = checkField("valor_amparo", "Valor o Porcentaje", true, "float2");
    if (checkArray.success) {
      showProcessingDialog("Guardando la información, por favor espere un momento ...");
      var params = {
        action: 'guardarAmparos',
        tipo: subAccionAmparos,
        poliza_id: $("#poliza_id").val(),
//          garantia_id: $("#garantia_id").val(),
        poliza_amparo_id: $("#poliza_amparo_id").val(),
        amparos: $("#amparos").val(),
        valor_amparo: $("#valor_amparo").val(),
        fec_inicio: $("#fec_inicio").val(),
        fec_final: $("#fec_final_amparo").val(),
        hiddenValAseg: $("#hiddenValAseg").val(),
        tipo_liqui: $('input:radio[name=tipo_liqui]:checked').val(),
        dias: $("#dias").val(),
        meses: $("#meses").val(),
        anios: $("#anios").val()
      };

//      console.log(params);
      $.post('ajax/poliza_ajax.php', params, function (data) {
        if (data.success) {
          location.reload();
        }
        else {
          hideProccessingDialog();
          showMessage('divEditAmparosMessage', data.error, 'error', 8000);
        }
      }, 'json');
    }
    else {
      showMessage('divEditAmparosMessage', checkArray.message, 'error', 8000);
    }
  }
  else {
    showMessage('divEditAmparosMessage', checkArray.message, 'error', 8000);
  }
}


function cambiarEstadoDocumentos(poliza_docum_id, estado, tbody) {
  if (tbody == null) {
    tbody = "tbodyAdjuntos";
  }
  var texto = "";
  var accion = "";
  switch (estado) {
    case 'N':
      texto = "Desactivar";
      accion = "Desactivando";
      break;

    case 'S':
      texto = "Activar";
      accion = "Activando";
      break;
  }
  $("#texto2").html(texto);
  $("#inactivarDocumento").dialog({
    autoOpen: true,
    modal: true,
    title: "Inactivar Documento",
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    },
    buttons: {
      "Aceptar": {
        click: function () {
          showProcessingDialog(accion + " el Documento, por favor espere un momento ...");
          var params = {
            action: 'cambiarEstadoDocumentos',
            poliza_docum_id: poliza_docum_id,
            estado: estado
          };
          $.post('ajax/poliza_ajax.php', params, function (data) {
            if (data.success) {
              $("#inactivarDocumento").dialog('close');
              listarAdjuntos(tbody, 'S');
            }
            else {
              $(this).dialog("close");
              showMessage('divMessage', data.error, 'error', 8000);
            }
          }, 'json');
        },
        text: 'Aceptar',
        class: 'btn btn-info'
      },
      "Cancelar": {
        click: function () {
          $(this).dialog('close');
        },
        text: 'Cancelar',
        class: 'btn btn-default'
      }
    }
  });
}

function editarAsegurado(tipo, poliza_asegurado_id) {
  subAccionAsegurado = tipo;
  if (tipo == 'nuevo') {
    $("#AsBe_nombre").val("");
    $("#AsBe_tipo_documento").val("");
    $("#AsBe_identificacion").val("");
    $("#AsBe_digit_ver").val("");
    $("#AsBe_municipio_nombre").val("");
    $("#AsBe_direccion").val("");
    $("#AsBe_telefono").val("");
    $("#AsBe_email").val("");
    $("input[name=tipoPer]").each(function () {
      $(this).prop("checked", false);
    });
    $("#popUpAsegurado").dialog("open");
  }
  else {
    showMessage('divMessage', "Cargando datos del usuario . . .", 'message', 0);
    var params = {
      action: 'buscarAsegurado',
      poliza_asegurado_id: poliza_asegurado_id
    };
    $.post('ajax/poliza_ajax.php', params, function (data) {
      if (data.success) {
        hideMessage('divMessage');
        $("input[name=tipoPer]").each(function () {
          $(this).prop("checked", false);
        });
        $("#AsBe_nombre").val(data.nombres);
        $("#AsBe_tipo_documento").val(data.tipo_documento_id);
        $("#AsBe_identificacion").val(data.identificacion);
        $("#AsBe_digit_ver").val(data.digit_ver);
        $("#AsBe_municipio_nombre").val(data.municipio_nombre);
        $("#AsBe_municipio_id").val(data.municipio_id);
        $("#AsBe_direccion").val(data.direccion);
        $("#AsBe_telefono").val(data.telefono);
        $("#AsBe_email").val(data.email);
        $("#AsBe_poliza_asegurado_id").val(data.poliza_asegurado_id);
        if (data.es_asegur == 1) {
          $("#asegurado").prop("checked", true);
        }
        if (data.es_benef == 1) {
          $("#beneficiario").prop("checked", true);
        }
        $("#popUpAsegurado").dialog("open");
      }
      else {
        showMessage('divMessage', data.error, 'error', 8000);
      }
    }, 'json');
  }
}

function editarAmparo(poliza_amparo_id) {
//  cargarAmparos(garantia_id, fec_inicio, fec_final, 'editar');
  showProcessingDialog("Cargando datos del amparo . . .");
  var params = {
    action: 'buscarAmparo',
    poliza_amparo_id: poliza_amparo_id
  };
  $.post('ajax/poliza_ajax.php', params, function (data) {
    hideProccessingDialog();
    if (data.success) {
      subAccionAmparos = "editar";
      hideMessage('divMessage');
      $("input[name=tipo_liqui]").each(function () {
        $(this).prop("checked", false);
      });
      $("#amparos").val(data.amparo_id);
      $("#valor_amparo").val(data.valor_liqui);
      $("#fechaInicial").html('Desde el ' + data.fec_inicio);
      $("#fec_inicio").val(data.fec_inicio);
      $("#dias").val(data.dias);
      $("#meses").val(data.meses);
      $("#spanFecFinal").html('Hasta el ' + data.fec_final);
      $("#fec_final_amparo").val(data.fec_final);
      $("#spanValAseg").html(data.valor_asegurado);
      $("#hiddenValAseg").val(data.valor_asegurado);
      $("#poliza_amparo_id").val(data.poliza_amparo_id);
      $("input[name=tipo_liqui]").each(function () {
        if ($(this).val() == data.tipo_liqui_id) {
          $(this).prop("checked", true);
        }
      });
      mostrarFechaInicio($("#fec_inicio_poliza").val(), $("#fec_final_poliza").val());
      calcularValorAsegurado();
      if (data.dias != null || data.meses != null || data.anios) {
        calcularFinVigencia('fec_inicio', 'dias', 'meses', 'anios', 'fec_final_amparo');
      }
      $("#divAmparos").dialog("open");
    }
    else {
      showMessage('divMessage', data.error, 'error', 8000);
    }
  }, 'json');
}

function eliminarGarantia(garantia_id, poliza_id) {
  $("#eliminarGarantia").dialog({
    autoOpen: true,
    modal: true,
    title: "Eliminar Garantia",
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    },
    buttons: {
      "Aceptar": {
        click: function () {
          showProcessingDialog("Eliminando la garantia, por favor espere un momento ...");
          var params = {
            action: 'eliminarGarantia',
            garantia_id: garantia_id,
            poliza_id: poliza_id
          };
          $.post('ajax/poliza_ajax.php', params, function (data) {
            if (data.success) {
              location.reload();
            }
            else {
              showMessage('divMessage', data.error, 'error', 8000);
            }
          }, 'json');
        },
        text: 'Aceptar',
        class: 'btn btn-info'
      },
      "Cancelar": {
        click: function () {
          $(this).dialog('close');
        },
        text: 'Cancelar',
        class: 'btn btn-default'
      }
    }
  });
}

function calcularFinVigencia(fecha_inicio, dias, meses, anios, fec_final) {
  var params = {
    action: "calcularFinVigencia",
    fecha_inicio: $('#' + fecha_inicio).val(),
    dias: $('#' + dias).val(),
    meses: $('#' + meses).val(),
    anios: $('#' + anios).val()
  };
  $.post('ajax/poliza_ajax.php', params, function (data) {
    if (data.success) {
//      $("#" + fec_final).html(data.fec_final);
      $("#" + fec_final).val(data.fec_final);
    }
    else {
      showMessage('divEditAmparosMessage', data.error, 'error', 8000);
    }
  }, 'json');
}

function recalcularFinVigencia() {
  calcularFinVigencia('periodo_tiempo_id', 'duracion_periodo', 'fec_inicio', 'fec_final');
}

function actualizarFechas() {
  hideMessage('divMensaje');
  var checkArray = checkField('fec_contrato', "Fecha de la firma del contrato", true, "date");
  if (checkArray.success) {
    var checkArray = checkField('fec_inicio', "Inicio de Ejecución", true, "date");
    if (checkArray.success) {
      var checkArray = checkField('dias', "Días", false, "int");
      if (checkArray.success) {
        var checkArray = checkField('meses', "Meses", false, "int");
        if (checkArray.success) {
          var checkArray = checkField('anios', "Anos", false, "int");
          if (checkArray.success) {
            var checkArray = checkField('fec_final', "Fin de Ejecución", true, "date");
            if (checkArray.success) {
              showProcessingDialog("Actualizando las fechas de la Póliza ...");
              var params = {
                action: "actualizarFechas",
                fec_contrato: $('#fec_contrato').val(),
                fec_inicio: $('#fec_inicio').val(),
                dias: $('#dias').val(),
                meses: $('#meses').val(),
                anios: $('#anios').val(),
                fec_final: $('#fec_final').val()
              };
              $.post('ajax/poliza_ajax.php', params, function (data) {
                hideProccessingDialog();
                if (data.success) {
                  location.reload();
                }
                else {
                  showMessage('divMessage', data.error, 'error', 8000);
                }
              }, 'json');
            } else {
              showMessage('divMensaje', checkArray.message, 'error', 8000);
            }
          } else {
            showMessage('divMensaje', checkArray.message, 'error', 8000);
          }
        } else {
          showMessage('divMensaje', checkArray.message, 'error', 8000);
        }

      } else {
        showMessage('divMensaje', checkArray.message, 'error', 8000);
      }

    } else {
      showMessage('divMensaje', checkArray.message, 'error', 8000);
    }
  } else {
    showMessage('divMensaje', checkArray.message, 'error', 8000);
  }
}

function calcularTotalAsegurado() {
  var total_asegurado = 0;
  $("input[name=total_garantia]").each(function () {
    total_asegurado = parseFloat(total_asegurado) + parseFloat($(this).val());
  });
  $("#total_asegurado").html(number_format(total_asegurado, 2, '.', ','));
  $("#valor_asegurado_total").val(total_asegurado);
}

function calcularIVA(aseguradora_id, garantia_id) {
  var iva = '';
  var valor_prima = $("#valor_prima_" + aseguradora_id + "_" + garantia_id).val();
  var gastos_expedicion = $("#gastos_expedicion_" + aseguradora_id + "_" + garantia_id).val();

  if (valor_prima != '' && gastos_expedicion != '') {
    iva = (parseInt(valor_prima) + parseInt(gastos_expedicion)) * 0.16;
  }

  $("#iva_" + aseguradora_id + "_" + garantia_id).val(iva);

}

function validarPoliza(poliza_id) {
  showProcessingDialog("Validando la información de la póliza ...");

  var params = {
    action: "validarPoliza",
    poliza_id: poliza_id
  };

  $.post('ajax/poliza_ajax.php', params, function (data) {
    hideProccessingDialog();
    if (data.success) {
      $("#aseguradoras").attr('style', 'display: inline');
      $("#confirmarPago").attr('style', 'display: none');
      $("#estado").val('aprobada');
      limpiarPopUp();
      $("#popUpAseguradora").dialog("open");
    }
    else {
      var html = '';
      var cont = 1;
      var val_error = false;
      if (data.errors != null && data.errors.length > 0) {
        val_error = true;
        for (i in data.errors) {
          error = data.errors[i];
          html += cont + '. ' + error + '<br/><br/>';
          cont++;
        }
      }

      var val_warnings = false;
      if (data.warnings != null && data.warnings.length > 0) {
        val_warnings = true;
        for (x in data.warnings) {
          warning = data.warnings[x];
          html += cont + '. ' + warning + '<br/><br/>';
        }
      }

      if ((val_error == false && val_warnings == true) || (val_error == false && val_warnings == false)) {
        alertaBeneficiarios();
      } else {
        $("#errores").html(html);
        $("#validacionPoliza").dialog("open");
      }
    }
  }, 'json');
}

function alertaBeneficiarios() {
  $("#alertaBeneficiarios").dialog({
    autoOpen: true,
    modal: true,
    title: "Desea continuar",
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    },
    buttons: {
      "Aceptar": {
        click: function () {
          $("#aseguradoras").attr('style', 'display: inline');
          $("#confirmarPago").attr('style', 'display: none');
          $("#estado").val('aprobada');
          limpiarPopUp();
          $("#popUpAseguradora").dialog("open");
          $(this).dialog('close');
        },
        text: 'Aceptar',
        class: 'btn btn-info'
      },
      "Cancelar": {
        click: function () {
          $(this).dialog('close');
        },
        text: 'Cancelar',
        class: 'btn btn-default'
      }
    }
  });
}

function cargarTotalGarantia(aseguradora_id, garantia_id) {
  var total_garantia = $("#total_garantia_" + garantia_id).val();
  $("#asegurado_total_" + aseguradora_id + "_" + garantia_id).val(total_garantia);
  $("#txt_asegurado_total_" + aseguradora_id + "_" + garantia_id).html(total_garantia);
}

function cargarEmitidos(clasif_docum) {
  var checkArray = checkField("archivoEmitido", "Archivo", true, "string");
  if (checkArray.success) {
    var checkArray = checkField("descripcionEmitido", "Descripción", true, "string");
    if (checkArray.success) {
      showProcessingDialog("Guardando la información, Por favor espere un momento ...");
      var data = new FormData();
      data.append("archivo", document.getElementById("archivoEmitido").files[0]);
      data.append("descripcion", $("#descripcionEmitido").val());
      data.append("action", "cargarAdjunto");
      data.append("clasif_docum", clasif_docum);
      data.append("poliza_id", $("#poliza_id").val());
//      console.log(data);
      $.ajax({
        url: 'ajax/poliza_ajax.php',
        type: 'POST',
        data: data,
        cache: false,
        processData: false, // Don't process the files
        contentType: false, // Set content type to false as jQuery will tell the server its a query string request
        dataType: 'json',
        success: function (data, textStatus, jqXHR)
        {
          hideProccessingDialog();
          if (data.success)
          {
            $("#descripcionEmitido").val("");
            $('#archivoEmitido').val("");
            listarAdjuntos('tbodyAdjuntos2', clasif_docum);
          }
          else
          {
            showMessage('divEditMessageEmitido', data.error, 'error', 8000);
          }
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
          hideProccessingDialog();
          showMessage('divEditMessageEmitido', textStatus, 'error', 8000);
        }
      });
    }
    else {
      showMessage('divEditMessageEmitido', checkArray.message, 'error', 8000);
    }
  }
  else {
    showMessage('divEditMessageEmitido', checkArray.message, 'error', 8000);
  }
}

function enviarCorreoEmitida() {
  showProcessingDialog("Validando la información de la póliza ...");

  var params = {
    action: "actializarPolizaEmitida",
    poliza_id: $('#poliza_id').val(),
    observacionesEmitida: $('#observacionesEmitida').val()
  };

  $.post('ajax/poliza_ajax.php', params, function (data) {
    hideProccessingDialog();
    if (data.success) {
      window.location = "polizas_tramite";
    }
    else {
      showMessage('divDocumentosMessage', data.error, 'error', 8000);
    }
  }, 'json');
}

function actualizarAseguradora() {
  showProcessingDialog("Guardando la información, por favor espere un momento...");
  $("input[name=poliza_aseguradora]").each(function () {
    poliza_aseguradora = $(this).val();
    garantia_nombre = $('#garantia_nombre_' + poliza_aseguradora).val();
    if ($('#cod_poliza_' + poliza_aseguradora).val() == '') {
      hideProccessingDialog();
      showMessage('divEditMessageCodPol', 'El Código de la póliza para la garantia ' + garantia_nombre + ' es requerido', 'error', 8000);
      $.end();
    }

    if ($('#fec_poliza_' + poliza_aseguradora).val() == '') {
      hideProccessingDialog();
      showMessage('divEditMessageCodPol', 'La Fecha de emisión para la garantia ' + garantia_nombre + ' es requerida', 'error', 8000);
      $.end();
    }
  });

  var params = {
    action: "actualizarAseguradora",
    poliza_id: $('#poliza_id').val(),
    poliza_aseguradora: $("input[name=poliza_aseguradora]").serializeArray()
  };

  $("input[name=poliza_aseguradora]").each(function () {
    poliza_aseguradora = $(this).val();
    params[$("#cod_poliza_" + poliza_aseguradora).prop("id")] = $("#cod_poliza_" + poliza_aseguradora).val();

    params[$("#fec_poliza_" + poliza_aseguradora).prop("id")] = $("#fec_poliza_" + poliza_aseguradora).val();
  });


  $.post('ajax/poliza_ajax.php', params, function (data) {
    hideProccessingDialog();
    if (data.success) {
      showMessage('divEditMessageCodPol', 'La información sé a actualizado exitosamente!', 'message', 8000);
    }
    else {
      showMessage('divEditMessageCodPol', data.error, 'error', 8000);
    }
  }, 'json');
}

function alertaSarlaft() {
  $("#alertaSarlaft").dialog({
    autoOpen: true,
    modal: true,
    title: "Desea continuar",
    open: function (event, ui) {
      $(this).parent().find(".ui-dialog-titlebar-close").remove();
    },
    buttons: {
      "Aceptar": {
        click: function () {
          abrirPopUpCargarArchivos();
          $(this).dialog('close');
        },
        text: 'Aceptar',
        class: 'btn btn-info'
      },
      "Cancelar": {
        click: function () {
          $(this).dialog('close');
        },
        text: 'Cancelar',
        class: 'btn btn-default'
      }
    }
  });
}

function abrirPopUpCargarArchivos() {
  listarAdjuntos('tbodyAdjuntos2', 'S');
  $("#cargarDocs").css("display", "block");
  $("#cargarCod").css("display", "none");
  $("#btnSiguiente1").css("display", "inline-block");
  $("#btnSiguiente2").css("display", "none");
  $("#divObserv").css("display", "none");
  $("#btnCancelarArchivo").css("display", "none");
  $("#popUpCargarArchivos").dialog("open");
}

function limpiarFormularioAmparos() {
  $("#amparos").val('');
  $("#valor_amparo").val('');
  $("#dias").val('');
  $("#meses").val('');
  $("#anios").val('');
  $("#fechaInicial").html('');
  $("#fec_inicio").val('');
  $("#spanFecFinal").html('');
  $("#fec_final_amparo").val('');
  $("#spanValAseg").html('');
  $("#hiddenValAseg").val('');
  $("#poliza_amparo_id").val('');
}
