$(document).ready(function () {
    $('#Filtrar').button().click(function (event) {
        event.preventDefault();
        filtrarPolizas();
    });
});

function filtrarPolizas() {
    var params = {
        accion: 'listarPolizas',
        identificacion: $('#identificacion').val(),
        ref_contrato: $('#ref_contrato').val(),
        estado_id: $('#estado_id').val(),
        email: $('#email').val()
    };
    
    $.post('ajax/polizas_finalizadas_ajax.php', params, function (data) {
        hideMessage('divMessage');
        $('#divListaPolizas').html(data);
        $("#tablaPolizas").tablesorter({
            sortList: [[0, 0]],
            widthFixed: true,
            widgets: ['zebra']
        });
    }, 'html');

}