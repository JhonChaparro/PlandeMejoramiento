var title = "Póliza en trámite";
var timerAlerta;
var timerListado;
var tiempoRecarga = 1000 * 60 * 3;
$(document).ready(function () {
  setTitle(title);
  listarPolizasTramite();
  setInterval(mensajeTiempo, 1000);
});

function listarPolizasTramite() {
  tiempoRecarga = 1000 * 60 * 3;
  $("#divPolizasTramite").html("");
  $("#divPolizasNoDoc").html("");
  showMessage('divMessage', "Listando pólizas en trámite . . .", 'message', 0);
  var params = {
    action: 'listarPolizasTramite'
  };
  $.post('ajax/poliza_ajax.php', params, function (data) {
    hideMessage('divMessage');
    if (data.success) {
      if (data.records > 0) {
        iniciarAlerta();
        $("#divPolizasTramite").html(data.tramite);
        $("#divPolizasNoDoc").html(data.noDoc);
      }
      else {
        showMessage('divPendientes', 'En este momento no hay productos pendientes para orden', 'message', 0);
        pararAlerta();
      }
    }
    else {
      showMessage('divMessage', data.error, 'error', 0);
    }
  }, 'json');
  timerListado = setTimeout(listarPolizasTramite, 1000 * 60 * 5);
}


function iniciarAlerta() {
  document.getElementById("audio").play();
  timerAlerta = setTimeout(iniciarAlerta, 10000);
}

function pararAlerta() {
  clearTimeout(timerAlerta);
}

function mensajeTiempo() {
  tiempoRecarga -= 1000;
  if (tiempoRecarga > 0) {
    $('#spTimer').text(tiempoToString(tiempoRecarga));
  } else {
    listarPolizasTramite();
  }
}

function tiempoToString(tiempo) {
  date = new Date(tiempo);
  var minutos = date.getMinutes();
  var segundos = date.getSeconds();
  if (segundos < 10) {
    segundos = "0" + segundos;
  }
  return "Faltan " + minutos + ":" + segundos + " para recargar la lista.";
}