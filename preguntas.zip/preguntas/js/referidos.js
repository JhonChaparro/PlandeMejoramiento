$(document).ready(function () {
  var ONE_DAY = 1000 * 60 * 60 * 24;

  $("#fec_inicio").datepicker({
    dateFormat: 'yy-mm-dd',
    maxDate: 0
  });

  $("#fec_final").datepicker({
    dateFormat: 'yy-mm-dd',
    maxDate: 0
  });

  $("#usuario_nombre").bind("keydown", function (event) {
    if (event.keyCode === $.ui.keyCode.TAB &&
            $(this).data("ui-autocomplete").menu.active) {
      event.preventDefault();
    }
  }).autocomplete({
    source: "ajax/referidos_ajax.php?accion=buscarReferidores",
    minLength: 1,
    select: function (event, ui) {
      $("#usuario_id").val(ui.item.id);
    },
    search: function () {
      $("#usuario_id").val("");
    },
    open: function (event, ui) {
      $(".ui-autocomplete").css("z-index", 1000);
    }
  });
  $('#all').change(function () {
    $('input:checkbox').not(this).prop('checked', this.checked);

    var x = 0;
    $('input[id="td[]"]').each(function () {

      if ($(this).is(':checked')) {
        x++;
      }
      if (x >= 1) {
        $("#cambiarEstado").prop("disabled", false);
      }
      else {
        $("#cambiarEstado").prop("disabled", true);
      }
    });
  });
  $('input[id="td[]"]').click(function () {
    $('#all').prop('checked', false);
    var x = 0;
    $('input[id="td[]"]').each(function () {
      if ($(this).is(':checked')) {
        x++;
      }
    });
    if (x >= 1) {
      $("#cambiarEstado").prop("disabled", false);
    }
    else {
      $("#cambiarEstado").prop("disabled", true);
    }
  });
});

function cambiarEstadoReferidos() {

  var cots = [];
  var x = 0;
  $('input[id="td[]"]').each(function () {
    if ($(this).is(':checked')) {
      cots[x] = ($(this).attr('name'));
      x++;
    }
  });
  if (x >= 1) {
    
    showProcessingDialog("Actualizando información...");
    var params = {
      accion: 'cambiarEstadoReferidos',
      refe_pagos: cots
    };
    $.post('ajax/referidos_ajax.php', params, function (data) {
//      hideProccessingDialog();
      if (data.success) {
        location.reload();
      }
      else {
        hideProccessingDialog();
         $("#divProcessing").dialog(close());
        showMessage('errordatoscuenta', data.error, 'error', 8000);
      }
    }, 'json');
  } else {
    showMessage('errordatoscuenta', ' Debe de seleccionar por lo menos \n\ una solicitud', 'error', 8000);
  }
}
function filtrarPagosRealizados() {
  // showProcessingDialog("Consultando pagos...");
  var params = {
    accion: 'filtrarPagosRealizados',
    fechainicial: $("#fec_inicio").val(),
    fechafinal: $("#fec_final").val(),
    banco_nombre: $("#banco_nombre").val(),
    usuario_id: $("#usuario_id").val()
  };
  showProcessingDialog("Consultando pagos...");
  $.post('ajax/referidos_ajax.php', params, function (data) {

    if (data.success) {
      hideProccessingDialog();
      $("#pagos_realizados").html(data.content);
      //  window.location='referidosencurso';
    }
  }, 'json');

}

