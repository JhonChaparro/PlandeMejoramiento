var title = "Reportes de emisión";
var subAccion = "nuevo";
$(document).ready(function () {
  setTitle(title);
  $("#btnBuscar").button().click(function (event) {
    event.preventDefault();
    listarPolizasEmitidas();
  });
  
  $("#fec_inicio_crea, #fec_final_crea, #fec_inicio_exp, #fec_final_exp").datepicker({
    dateFormat: 'yy-mm-dd'
  });
});

function listarPolizasEmitidas() {
  showMessage('divMessage', "Listando las campañas . . .", 'message', 0);
  var params = {
    accion: 'listarPolizasEmitidas',
    fec_inicio_crea: $("#fec_inicio_crea").val(),
    fec_final_crea: $("#fec_final_crea").val(),
    fec_inicio_exp: $("#fec_inicio_exp").val(),
    fec_final_exp: $("#fec_final_exp").val(),
    aseguradora_id: $("#aseguradora_id").val()
  };
  $.post('ajax/reporte_emicion_ajax.php', params, function (data) {
    hideMessage('divMessage');
    $("#divReportEmitidas").html(data);
    $("#tablaEmitidas").tablesorter({
      sortList: [[0, 0]],
      widthFixed: true,
      widgets: ['zebra']
    });
  }, 'html');
}