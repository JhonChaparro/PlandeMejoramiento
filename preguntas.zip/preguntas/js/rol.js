var title = "Control de Roles";
var subAccion = "";
$(document).ready(function () {
    setTitle(title);
    $("#btnBusqueda").button().click(function (event) {
        event.preventDefault();
        listarRoles();
    });
    $("#textBusqueda").keyup(function (event) {
        event.preventDefault();
        if (event.keyCode == 13) {
            listarRoles();
        }
    });
    $("#btnGuardar").button().click(function (event) {
        event.preventDefault();
        guardarRol();
    });
    $("#btnCancelar").button().click(function (event) {
        event.preventDefault();
        $("#divEditRol").dialog("close");
    });
    listarRoles();
});

function listarRoles() {
    showMessage('divMessage', "Listando roles . . .", 'message', 0);
    var params = {
        accion: 'listarRoles',
        filtro: $("#textBusqueda").val()
    };
    $.post('ajax/rol_ajax.php', params, function (data) {
        hideMessage('divMessage');
        $("#divListaRol").html(data);
        $("#tablaRoles").tablesorter({
            sortList: [[0, 0]],
            widthFixed: true,
            widgets: ['zebra']
        });
    }, 'html');

}

function editarRol(tipo, rol_id) {
    subAccion = tipo;
    hideMessage('divEditRolMessage');
    $("input:checkbox[name=opcion_id]").prop('checked', false);
    if (tipo == 'nuevo') {
        $("#rol_id").val("");
        $("#rol_nombre").val("");
        $("#divEditRol").dialog({
            modal: true,
            width: 700,
            height: "auto",
            title: title
        });
    }
    else {
        showMessage('divMessage', "Cargando datos del rol . . .", 'message', 0);
        var params = {
            accion: 'buscarRol',
            rol_id: rol_id
        };
        $.post('ajax/rol_ajax.php', params, function (data) {
            if (data.success) {
                hideMessage('divMessage');
                $("#rol_id").val(data.rol_id);
                $("#rol_nombre").val(data.rol_nombre);
                
                if (data.opciones != null) {
                    for (i = 0; i < data.opciones.length; i++) {
                        $("#opcion_id_" + data.opciones[i]).prop('checked', true);
                    }
                }
                $("#divEditRol").dialog({
                    modal: true,
                    width: 700,
                    height: "auto",
                    title: title
                });
            }
            else {
                showMessage('divMessage', data.error, 'error', 8000);
            }
        }, 'json');
    }
}

function guardarRol() {
    var selectedItems = new Array();
    $("input:checkbox[name=opcion_id]:checked").each(function () {
        selectedItems.push($(this).val());
    });
    var checkArray = checkField('rol_nombre', 'Nombre', true, "string");
    if (checkArray.success) {
        var esNuevo = (subAccion == "nuevo");
        var texto = ((esNuevo) ? "Ingresando" : "Actualizando");
        showMessage('divEditRolMessage', texto + " rol . . .", 'message', 0);
        var params = {
            accion: 'guardarRol',
            tipo: subAccion,
            rol_id: $('#rol_id').val(),
            rol_nombre: $('#rol_nombre').val(),
            opciones: selectedItems
        };
        $.post('ajax/rol_ajax.php', params, function (data) {
            if (data.success) {
                hideMessage('divEditRolMessage');
                $("#divEditRol").dialog('close');
                listarRoles();
            }
            else {
                showMessage('divEditRolMessage', data.error, 'error', 8000);
            }
        }, 'json');

    }
    else {
        showMessage('divEditRolMessage', checkArray.message, 'error', 8000);
        return false;
    }
}