var title = "Control de Sectores";
var subAccion = "";
$(document).ready(function () {

  setTitle(title);
  $("#btnBusqueda").button().click(function (event) {
    event.preventDefault();
    listarSectores();
  });
  $("#textBusqueda").keyup(function (event) {
    event.preventDefault();
    if (event.keyCode == 13) {
      listarSectores();
    }
  });
  $("#btnGuardar").button().click(function (event) {
    event.preventDefault();
    guardarSector();
  });
  $("#btnCancelar").button().click(function (event) {
    event.preventDefault();
    $("#divEditSectores").dialog("close");
  });

  $("#divEditSectores").dialog({
    autoOpen: false,
    modal: true,
    width: 700,
    height: "auto",
    title: title
  });

  listarSectores();
});

function listarSectores() {
  showMessage('divMessage', "Listando sectores . . .", 'message', 0);

  var params = {
    accion: 'listarSectores',
    filtro: $("#textBusqueda").val()
  };
  $.post('ajax/sector_ajax.php', params, function (data) {
    hideMessage('divMessage');
    $("#divListaSectores").html(data);
    $("#tablaSectores").tablesorter({
      sortList: [[0, 0]],
      widthFixed: true,
      widgets: ['zebra']
    });
  }, 'html');

}

function editarSector(tipo, sector_id) {
  subAccion = tipo;
  hideMessage('divEditSectoresMessage');

  if (tipo == 'nuevo') {
    $("#sector_nombre").val("");
    $("#sector_desc").val("");
    $("#divEditSectores").dialog('open');
  }
  else {
    showMessage('divMessage', "Cargando datos del sector . . .", 'message', 0);
    var params = {
      accion: 'buscarSector',
      sector_id: sector_id
    };
    $.post('ajax/sector_ajax.php', params, function (data) {
      if (data.success) {
        hideMessage('divMessage');
        $("#sector_id").val(data.sector_id);
        $("#sector_nombre").val(data.sector_nombre);
        $("#sector_desc").val(data.sector_desc);
        $("#divEditSectores").dialog('open');
      }
      else {
        showMessage('divMessage', data.error, 'error', 8000);
      }
    }, 'json');
  }
}

function guardarSector() {
  var checkArray = checkField('sector_nombre', 'Nombre', true, "string");
  if (checkArray.success) {
    checkArray = checkField('sector_desc', 'Descripción', true, "string");
    if (checkArray.success) {
      var esNuevo = (subAccion == "nuevo");
      var texto = ((esNuevo) ? "Ingresando" : "Actualizando");
      showMessage('divEditSectoresMessage', texto + " sector . . .", 'message', 0);
      var params = {
        accion: 'guardarSector',
        tipo: subAccion,
        sector_id: $('#sector_id').val(),
        sector_nombre: $('#sector_nombre').val(),
        sector_desc: $('#sector_desc').val()
      };
      $.post('ajax/sector_ajax.php', params, function (data) {
        if (data.success) {
          hideMessage('divEditSectoresMessage');
          $("#divEditSectores").dialog('close');
          listarSectores();
        }
        else {
          showMessage('divEditSectoresMessage', data.error, 'error', 8000);
        }
      }, 'json');

    }
    else {
      showMessage('divEditSectoresMessage', checkArray.message, 'error', 8000);
      return false;
    }
  }
  else {
    showMessage('divEditSectoresMessage', checkArray.message, 'error', 8000);
    return false;
  }
}


function cambiarActivoSector(sector_id, valor) {
  var texto = "";
  var accion = "";
  switch (valor) {
    case 'N':
      texto = "Desactivar";
      accion = "Desactivando";
      break;
    case 'S':
      texto = "Activar";
      accion = "Activando";
      break;
  }
  texto = "¿Esta seguro que desea " + texto + " este sector?";
  $("#divDialog").html(texto);
  $("#divDialog").dialog({
    modal: true,
    width: "600px",
    height: "auto",
    resize: true,
    title: title,
    buttons: {
      "Si": function () {
        $("#divDialog").dialog("close");
        showMessage('divMessage', accion + " sector . . .", 'message', 0);
        var params = {
          accion: 'cambiarActivo',
          sector_id: sector_id,
          valor: valor
        };
        $.post('ajax/sector_ajax.php', params, function (data) {
          if (data.success) {
            listarSectores();
          }
          else {
            showMessage('divMessage', data.error, 'error', 0);
          }
        }, 'json');
      },
      "No": function () {
        $("#divDialog").dialog("close");
      }
    }
  });
}
