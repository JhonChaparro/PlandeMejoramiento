function borrarRegistros() {
  $("#divRegistros").html("");
}

function listarTasas() {
  checkArray = checkField('aseguradora_id', 'Aseguradora', true, "int");
  if (checkArray.success) {
    checkArray = checkField('garantia_id', 'Garantia', true, "int");
    if (checkArray.success) {
      var params = {
      accion: 'listarTasas',
      aseguradora_id: $('#aseguradora_id').val(),
      garantia_id: $('#garantia_id').val()
    };
    showMessage('divMessage', "Cargando Amparos y Tasas ...", 'message', 0);
    $.post('ajax/tasa_ajax.php', params, function (data) {
        hideMessage('divMessage');
        $("#divRegistros").html(data);
    }, 'html');
    }
    else {
      showMessage('divMessage', checkArray.message, 'error', 8000);
      return false;
    }
  }
  else {
    showMessage('divMessage', checkArray.message, 'error', 8000);
    return false;
  }
}

