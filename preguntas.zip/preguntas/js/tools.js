//     DESCRIPTION:	Javascript functions for whole site
//         VERSION:	1.0
//           AUTOR:	NETStudio
//           FECHA:	2013-11-26
//
//  MODIFICATIONS:
//
//

function checkField(fieldName, fieldLabel, required, validType) {
  var returnArray = new function () {
  };
  returnArray.success = true;
  var field = $("#" + fieldName).val();
  if (required) {
    if (field == null || field == "") {
      returnArray.message = (msg['error.required']).replace('P_1', fieldLabel);
      returnArray.success = false;
      return returnArray;
    }
  }
  else {
    if (field == null || field == "") {
      return returnArray;
    }
  }
  switch (validType) {
    case "int":
      if (!(/^\d+$/.test(field))) {
        returnArray.message = (msg['error.integer']).replace('P_1', fieldLabel);
        returnArray.success = false;
      }
      break;

    case "float2":

      if (!(/^\d+$/.test(field)) && !(/^\d+\.\d{0,2}$/.test(field))) {
        returnArray.message = (msg['error.float']).replace('P_1', fieldLabel);
        returnArray.success = false;
      }
      break;

    case "date":
      returnArray = checkFieldDate(fieldName, fieldLabel);
      break;

    case "email":
      if (!(/^(\w+[\-\.])*\w+@(\w+\.)+[A-Za-z]+$/.test(field))) {
        returnArray.message = (msg['error.email']).replace('P_1', fieldLabel);
        returnArray.success = false;
      }
      break;

    case "password":
      var errorMsg = "";
      var space = " ";
      fieldlength = field.length;
      //It must not contain a space
      if (field.indexOf(space) > -1) {
        errorMsg += msg['error.pwd_space'];
      }
      //It must be at least 7 characters long.
      if (!(fieldlength >= 6)) {
        errorMsg += msg['error.pwd_min'];
      }

      //It must contain at least one number character
      if (!(field.match(/\d/))) {
        errorMsg += msg['error.pwd_int'];
      }
      //It must start with at least one letter
      if (!(field.match(/[a-zA-Z]/))) {
        errorMsg += msg['error.pwd_let'];
      }
      //If there is aproblem with the form then display an error
      if (errorMsg != "") {
        returnArray.message = errorMsg;
        returnArray.success = false;
      }
      break;
  }
  if (!returnArray.success) {
    $("#" + fieldName).focus();
  }
  return returnArray;
}

function checkFieldDate(fieldName, fieldLabel) {
  var returnArray = new function () {
  };
  var field = $("#" + fieldName).val();
  if (/^\d{4}\-\d{2}\-\d{2}$/.test(field)) {
    var date = field.split("-");
    var year = parseInt(date[0], 10);
    var month = parseInt(date[1], 10);
    var day = parseInt(date[2], 10);
    if (month < 1 || month > 12) {
      returnArray.message = (msg['error.date_month']).replace('P_1', fieldLabel);
      returnArray.success = false;
      return returnArray;
    }
    var maxDay = 0;
    if (year % 4 == 0 && month == 2) {
      maxDay = 29;
    }
    else {
      switch (month) {
        case 2:
          maxDay = 28;
          break;

        case 4:
        case 6:
        case 9:
        case 11:
          maxDay = 30;
          break;

        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
          maxDay = 31;
          break;
      }
    }
    if (day < 1 || day > maxDay) {
      returnArray.message = (msg['error.date_day']).replace('P_1', fieldLabel);
      returnArray.success = false;
      return returnArray;
    }
  }
  else {
    returnArray.message = (msg['error.date_wrong']).replace('P_1', fieldLabel);
    returnArray.success = false;
    return returnArray;
  }
  returnArray.message = (msg['error.date_success']).replace('P_1', fieldLabel);
  returnArray.success = true;
  return returnArray;
}

function showMessage(container, message, type, autoHide) {
  var color = "";
  switch (type) {
    case 'message':
      color = "GREEN";
      break;

    case 'warning':
      color = "ORANGE";
      break;

    case 'error':
      color = "RED";
      break;
  }
  $("#" + container).css("color", color);
  $("#" + container).css("display", "block");
  $("#" + container).html(message);
  if (autoHide > 0) {
    setTimeout("hideMessage('" + container + "')", autoHide);
  }
}

function hideMessage(container) {
  $("#" + container).css("display", "none");
  $("#" + container).html("");
}

function requestGetResponseHTML(container, url, params) {
  $.get(url, params, function (data) {
    $("#" + container).html(data);
  }, 'html');
}

function requestPostResponseHTML(container, url, params) {
  $.post(url, params, function (data) {
    $("#" + container).html(data);
  }, 'html');
}

function setTitle(title) {
  $(document).prop("title", title);
}


function validarImagen(archivo, campo, label, ancho, alto) {
  var errors = new Array();
  errors[campo] = null;
  var reader = new FileReader();
  var image = new Image();

  var allowExt = ["image/png","image/jpeg"];
  var t = archivo.files[0].type;
  var s = archivo.files[0].size;
  var limitKb = 400000;
  
  if (!$.inArray(t, allowExt) > -1) {
    if (s <= limitKb) {
      reader.readAsDataURL(archivo.files[0]);
      reader.onload = function (_file) {
        image.src = _file.target.result;
        image.onload = function () {
          var w = this.width;
          var h = this.height;

          if (!(ancho >= w && alto >= h)) {
            if (errors[campo] == null) {
              errors[campo] = [];
            }
            errors[campo].push("Las dimensiones no son válidas (" + w + "x" + h + ").  Las dimensiones adecuadas son igual o menores a " + ancho + "x" + alto);
          }

        };
        image.onerror = function () {
          $('#divMessage').html("El archivo '" + archivo.files[0].name + "' no es una imagen, por favor seleccione un archivo con extensión png o jpg");
          $('#divMessage').css('color', 'red');
          $("#" + campo + "Selected").val('N');
          $("#submit").prop("disabled", true);
        };
      };
    } else {
      if (errors[campo] == null) {
        errors[campo] = [];
      }
      errors[campo].push("El tamaño de la imagen es superior a 400 Kb");
    }
  } else {
    if (errors[campo] == null) {
      errors[campo] = [];
    }
    errors[campo].push("La imagen no es válida, debe ser en formato PNG y JPG");
  }
  $('#divMessage').html("");
  if (errors[campo] != null && errors[campo].length > 0) {
    $("#" + campo + "Selected").val('N');
    $('#divMessage').css('color', 'red');
    $("#submit").prop("disabled", true);
    for (i in errors[campo]) {
      $('#divMessage').append(errors[campo][i] + "<br/>");
    }
  }
  else {
    $('#divMessage').css('color', 'green');
    $('#divMessage').html("La imagen es válida para ser utilizada como logo de los documentos");
    $("#" + campo + "Selected").val('Y');
    $('#submit').prop("disabled", false);
  }
}

function showProcessingDialog(text) {
  if(text == null || text == ""){
    text = "Procesando, por favor espere . . .";
  }
  $("#divProcessMessage").text(text);
  $("#divProcessing").dialog({
    modal: true,
    width: 500,
    height: 200,
    title: document.title,
    closeOnEscape: false,
    open: function (event, ui) {
      $(".ui-dialog-titlebar-close", ui.dialog | ui).hide();
    }
  });
}

function hideProccessingDialog() {
  $("#divProcessing").dialog('close');
}

function number_format(number, decimals, decPoint, thousandsSep){
	decimals = decimals || 0;
	number = parseFloat(number);

	if(!decPoint || !thousandsSep){
		decPoint = '.';
		thousandsSep = ',';
	}

	var roundedNumber = Math.round( Math.abs( number ) * ('1e' + decimals) ) + '';
	var numbersString = decimals ? roundedNumber.slice(0, decimals * -1) : roundedNumber;
	var decimalsString = decimals ? roundedNumber.slice(decimals * -1) : '';
	var formattedNumber = "";

	while(numbersString.length > 3){
		formattedNumber += thousandsSep + numbersString.slice(-3)
		numbersString = numbersString.slice(0,-3);
	}

	return (number < 0 ? '-' : '') + numbersString + formattedNumber + (decimalsString ? (decPoint + decimalsString) : '');
}