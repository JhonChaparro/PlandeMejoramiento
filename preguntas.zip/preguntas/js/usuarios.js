var title = "Control de usuarios";
var subAccion = "";
$(document).ready(function () {

  setTitle(title);

  $("#btnBusqueda").button().click(function (event) {
    event.preventDefault();
    listarUsuarios();
  });
  $("#textBusqueda").keyup(function (event) {
    event.preventDefault();
    if (event.keyCode == 13) {
      listarUsuarios();
    }
  });
  $("#btnGuardar").button().click(function (event) {
    event.preventDefault();
    guardarUsuario();
  });
  $("#btnCancelar").button().click(function (event) {
    event.preventDefault();
    $("#divEditUsuarios").dialog("close");
  });

  $("#divEditUsuarios").dialog({
    autoOpen: false,
    modal: true,
    width: 700,
    height: "auto",
    title: title
  });

  listarUsuarios();
});

function listarUsuarios() {
  showMessage('divMessage', "Listando usuarios . . .", 'message', 0);

  var params = {
    accion: 'listarUsuarios',
    filtro: $("#textBusqueda").val()
  };
  $.post('ajax/usuarios_ajax.php', params, function (data) {
    hideMessage('divMessage');
    $("#divListaUsuarios").html(data);
    $("#tablaUsuarios").tablesorter({
      sortList: [[0, 0]],
      widthFixed: true,
      widgets: ['zebra']
    });
  }, 'html');

}

function editarUsuario(tipo, usuario_id) {
  subAccion = tipo;
  $("#clave_usuario").val("");
  $("#clave2_usuario").val("");
  hideMessage('divEditUsuariosMessage');

  if (tipo == 'nuevo') {
    $("#nombres").val("");
    $("#apellidos").val("");
    $("#identificacion").val("");
    $("#email").val("");
    $("#clave").val("");
    $("#clave2").val("");
    $("#rol_id").val("");
    $("#area_id").val("");
    $("#msgPassword").css("display", "none");
    $("#divEditUsuarios").dialog('open');
  }
  else {
    showMessage('divMessage', "Cargando datos del usuario . . .", 'message', 0);
    var params = {
      accion: 'buscarUsuario',
      usuario_id: usuario_id
    };
    $.post('ajax/usuarios_ajax.php', params, function (data) {
      if (data.success) {
        hideMessage('divMessage');
        $("#usuario_id").val(data.usuario_id);
        $("#nombres").val(data.nombres);
        $("#apellidos").val(data.apellidos);
        $("#identificacion").val(data.identificacion);
        $("#email").val(data.email);
        $("#rol_id").val(data.rol_id);
        $("#area_id").val(data.area_id);
        $("#divEditUsuarios").dialog('open');
        $("#msgPassword").css("display", "inline");
      }
      else {
        showMessage('divMessage', data.error, 'error', 8000);
      }
    }, 'json');
  }
}

function guardarUsuario() {

  var checkArray = checkField("nombres", "Nombres", true, "string");
  if (checkArray.success) {
    checkArray = checkField("apellidos", "Número de identificación", true, "string");
    if (checkArray.success) {
      checkArray = checkField("identificacion", "Dígito de verificación", true, "int");
      if (checkArray.success) {
        checkArray = checkField("email", "Ciudad de residencia", true, "email");
        if (checkArray.success) {
          checkArray = checkField("rol_id", "Teléfono", true, "int");
          if (checkArray.success) {
            checkArray = checkField("area_id", "Cargo", true, "int");
            if (checkArray.success) {
              checkArray = checkField('clave', 'Contraseña', false, "password");
              if (checkArray.success) {
                var usuario_passwd = $("#clave").val();
                var usuario_passwd2 = $("#clave2").val();
                if (usuario_passwd == usuario_passwd2) {
                  showProcessingDialog("Guardando la información, Por favor espere un momento ...");
                  var params = {
                    accion: 'guardarUsuario',
                    tipo: subAccion,
                    usuario_id: $('#usuario_id').val(),
                    nombres: $('#nombres').val(),
                    apellidos: $('#apellidos').val(),
                    identificacion: $('#identificacion').val(),
                    email: $('#email').val(),
                    rol_id: $('#rol_id').val(),
                    area_id: $('#area_id').val(),
                    clave: $('#clave').val()
                  };
                  $.post('ajax/usuarios_ajax.php', params, function (data) {
                    if (data.success) {
                      hideMessage('divEditUsuariosMessage');
                      $("#divEditUsuarios").dialog('close');
                      hideProccessingDialog();
                      listarUsuarios();
                    }
                    else {
                      hideProccessingDialog();
                      showMessage('divEditUsuariosMessage', data.error, 'error', 8000);
                    }
                  }, 'json');
                } else {
                  showMessage('divEditUsuariosMessage', 'Las contraseñas no coinciden', 'error', 8000);
                }
              } else {
                showMessage('divEditUsuariosMessage', checkArray.message, 'error', 8000);
              }
            } else {
              showMessage('divEditUsuariosMessage', checkArray.message, 'error', 8000);
            }
          } else {
            showMessage('divEditUsuariosMessage', checkArray.message, 'error', 8000);
          }
        } else {
          showMessage('divEditUsuariosMessage', checkArray.message, 'error', 8000);
        }
      } else {
        showMessage('divEditUsuariosMessage', checkArray.message, 'error', 8000);
      }
    } else {
      showMessage('divEditUsuariosMessage', checkArray.message, 'error', 8000);
    }
  } else {
    showMessage('divEditUsuariosMessage', checkArray.message, 'error', 8000);
  }
}

function cambiarActivoUsuario(usuario_id, valor) {
  var texto = "";
  var accion = "";
  switch (valor) {
    case 'I':
      texto = "Inactivar";
      accion = "Desactivando";
      break;

    case 'A':
      texto = "Activar";
      accion = "Activando";
      break;
  }
  texto = "¿Esta seguro que desea " + texto + " este usuario?";
  $("#divDialog").html(texto);
  $("#divDialog").dialog({
    modal: true,
    width: "600px",
    height: "auto",
    resize: true,
    title: title,
    buttons: {
      "Si": function () {
        $("#divDialog").dialog("close");
        showMessage('divMessage', accion + " usuario . . .", 'message', 0);
        var params = {
          accion: 'cambiarActivo',
          usuario_id: usuario_id,
          valor: valor
        };
        $.post('ajax/usuarios_ajax.php', params, function (data) {
          if (data.success) {
            listarUsuarios();
          }
          else {
            showMessage('divMessage', data.error, 'error', 0);
          }
        }, 'json');
      },
      "No": function () {
        $("#divDialog").dialog("close");
      }
    }
  });
}
