<?php

//     DESCRIPCION:	Permite iniciar sesión a un usuario
//         VERSION:	1.0
//           AUTOR:	NETStudio
//           FECHA:	2012-12-26
//
//  MODIFICACIONES:
//
//
// No cache [Development purposes]
include_once '../general/sec_header.php';
$response = '';
unset($_SESSION["idusuario"]);
unset($_SESSION['usuario_sei']);
unset($_SESSION['menu_sei']);

$usuario_login = $_POST["usuario_login"];
$usuario_passwd = $_POST["usuario_passwd"];
if (isset($usuario_login) && !empty($usuario_login) && isset($usuario_passwd) && !empty($usuario_passwd)) {
  if (strpos($usuario_login, "'") === false && strpos($usuario_passwd, "'") === false) {
    $usuario_passwd = sha1($usuario_passwd);
    $sql = "SELECT * FROM profesi WHERE pcedu='$usuario_login' and clave = '$usuario_passwd'";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {

        $fila = $mySQL->fetch_assoc($query['result']);
        if ($fila["activ"] == "SI") {
          $_SESSION["idusuario"] = $usuario_login;
          $_SESSION['usuario_sei'] = $fila;
          $sql = "SELECT DISTINCT opcion.*, menu.menu_nombre, menu.menu_orden FROM opcion JOIN opcion_rol USING(opcion_id) JOIN menu USING(menu_id) WHERE rol_id = " . $fila['rol_id'] . " AND opcion_rol_activo = 'S' ORDER BY menu_orden, opcion_orden";
          $query = $mySQL->query($sql);
          if ($query['success']) {
            $menu_array = array();
            while ($row = mysql_fetch_assoc($query['result'])) {
              if (!array_key_exists($row['menu_orden'], $menu_array)) {
                $menu_array[$row['menu_orden']] = array();
                $menu_array[$row['menu_orden']]['menu_nombre'] = $row['menu_nombre'];
                $menu_array[$row['menu_orden']]['menu_id'] = $row['menu_id'];
                $menu_array[$row['menu_orden']]['opciones'] = array();
              }
              $menu_array[$row['menu_orden']]['opciones'][] = $row;
            }
            $menuHTML = '';
            foreach ($menu_array as $menu_orden => $menu) {
              $menuHTML .= '<li class="dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">' . $menu['menu_nombre'] . '<b class="caret"></b></a>
    <ul class="dropdown-menu">
    ';
              foreach ($menu['opciones'] as $opcion_orden => $opcion) {
                $menuHTML .= "<li><a href='" . $opcion['opcion_url'] . "'>" . $opcion['opcion_nombre'] . "</a></li>";
              }
              $menuHTML .= '  </ul>
                    </li>';
            }
            $menuHTML .= '<li><a href="logout.php">Cerrar sesión (' . $fila['nprof'] . ')</a></li>';
            $_SESSION['menu_sei'] = $menuHTML;
          } else {
            $response = $query['error'];
          }
        } else {
          $response = 'Este usuario se encuentra deshabilitado';
        }
      } else {
        $response = 'El usuario o contraseña no coinciden';
      }
    } else {
      $response = $query['error'];
    }
  } else {
    $response = 'El usuario o contraseña no puede contener comilla';
  }
} else {
  $response = 'El usuario y la contraseña son requeridos';
}
$return = '';
$page = "default_login";
if (isset($_SESSION['next_page'])) {
  $page = $_SESSION['next_page'];
  unset($_SESSION['next_page']);
}
if (isset($_SESSION['usuario_sei'])) {
  $return = 'window.location = "' . $page . '"';
} else {
  $return = $response;
}
echo $return;
include_once '../../general/sec_footer.php';
?>