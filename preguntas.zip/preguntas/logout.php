<?php

require_once 'general/sec_header.php';
unset($_SESSION['preguntas_admin_user']);
unset($_SESSION['preguntas_admin_menu']);
session_write_close();
header('Location: index.php');
?>
