<?php

require_once dirname(__FILE__) . '/../general/Tools.php';

class Poliza {

  public function crearPoliza() {
    global $mySQL;
    global $prefixSession;
    $return = array();
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    $identificacion = $_POST['identificacion'];
    $digit_ver = $_POST['digit_ver'];
    $tipo_documento_id = $_POST['tipo_documento_id'];
    $municipio_id = $_POST['municipio_id'];
    $direccion = $_POST['direccion'];
    $telefono = $_POST['telefono'];
    $email = $_POST['email'];
    $ref_contrato = $_POST['ref_contrato'];
    $cod_referidor = $_POST['cod_referidor'];
    $campania_id = $_POST['campania_id'];
    $tipo_usuario = $_POST["tipo_usuario"];

    if (empty($campania_id)) {
      $campania_id = "NULL";
    }

    $politicas = null;
    $origen = null;
    if ($tipo_usuario == 'I') {
      $politicas = "N";
      $origen = "Sistema";
    } else {
      $politicas = "S";
      $origen = "Cliente";
    }
    //Primero se debe validar si el afianzado tiene usuario, si no se crea un usuario
    if (empty($cod_referidor)) {

      $sql = "SELECT usuario_id FROM usuario WHERE usuario_email = '$email' AND tipo_usuario = 'C'";
      $cliente_id = NULL;
      $creacion_id = $_SESSION['preguntas_admin_user']['usuario_id'];
      $query = $mySQL->query($sql);
      if ($query['success']) {
        if ($mySQL->num_rows($query['result']) > 0) {
          $row = $mySQL->fetch_assoc($query['result']);
          $cliente_id = $row['usuario_id'];
        } else {
          $tools = new Tools();
          $password = $tools->getRandowPassword(10);
          $sql = "INSERT INTO usuario (rol_id, usuario_log, usuario_nombre, usuario_cargo, usuario_email, usuario_passwd, usuario_activo, tipo_usuario, req_cc, usuario_apel, tipo_documento_id, identificacion, dig_ver, lug_res_id, usuario_tel, acep_polit)
                    VALUES (3, 1, '$nombres', '', '$email', MD5('$password'), 'S', 'C', 'S', '$apellidos', $tipo_documento_id, '$identificacion', $digit_ver, $municipio_id, '$telefono', '$politicas');";
          $query = $mySQL->query($sql);
          if ($query['success']) {
            $cliente_id = $mySQL->insert_id();
            $creacion_id = $cliente_id;
            $_SESSION[$prefixSession . 'password'] = $password;
            $this->enviarCorreoUsuario($email, $nombres, $password);
          } else {
            $return['success'] = false;
            $return['error'] = "Error tratando de crear el usuario del afianzado, por favor inténtelo nuevamente. Si el error persiste por favor contáctenos para darle una solución lo antes posible.";
            return $return;
          }
        }
        $sql = "INSERT INTO poliza (nombres, identificacion, digit_ver, tipo_documento_id, lug_res_afi, direccion, telefono, email, poliza_estado_id, fec_registro, fec_estado, cliente_id, ref_contrato, campania_id, creacion_id) "
                . "VALUES ('$nombres', '$identificacion', $digit_ver, $tipo_documento_id, $municipio_id, '$direccion', '$telefono', '$email', 10, NOW(), NOW(), $cliente_id, '$ref_contrato', $campania_id, $creacion_id)";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          $poliza_id = $mySQL->insert_id();
          $sql = "INSERT INTO poliza_bitac (poliza_id, poliza_estado_id, comentarios, fec_registro, origen)"
                  . "VALUES ($poliza_id, 10, 'La póliza esta siendo ingresada por el usuario', NOW(), '$origen')";
          $query = $mySQL->query($sql);
          if ($query['success']) {
            $_SESSION[$prefixSession . 'poliza_id'] = $poliza_id;
            //Agrgar correo a Yeisson
            $return = $this->enviarCorreoPolizaCreada($nombres, $identificacion, $digit_ver, $municipio_id, $direccion, $telefono, $email, $ref_contrato);
          } else {
            $return['success'] = false;
            $return['error'] = "Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste por favor contáctenos para darle una solución lo antes posible.";
          }
        } else {
          $return['success'] = false;
          $return['error'] = "Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste por favor contáctenos para darle una solución lo antes posible.";
        }
      } else {
        $return['success'] = false;
        $return['error'] = "Error tratando de crear el usuario del afianzado, por favor intente nuevamente.";
      }
    } else {
      $sql = "SELECT * FROM usuario WHERE cod_referidor = '$cod_referidor'";
      $resulta = $mySQL->query($sql);
      if ($resulta['success']) {
        if ($mySQL->num_rows($resulta['result']) > 0) {
          $referidor = $mySQL->fetch_assoc($resulta['result']);
          $sql = "SELECT usuario_id FROM usuario WHERE usuario_email = '$email' AND tipo_usuario = 'C'";
          $cliente_id = NULL;
          $creacion_id = $_SESSION['preguntas_admin_user']['usuario_id'];
          $query = $mySQL->query($sql);
          if ($query['success']) {
            if ($mySQL->num_rows($query['result']) > 0) {
              $row = $mySQL->fetch_assoc($query['result']);
              $cliente_id = $row['usuario_id'];
            } else {
              $tools = new Tools();
              $password = $tools->getRandowPassword(10);
              $sql = "INSERT INTO usuario (rol_id, usuario_log, usuario_nombre, usuario_cargo, usuario_email, usuario_passwd, usuario_activo, tipo_usuario, req_cc, usuario_apel, tipo_documento_id, identificacion, dig_ver, lug_res_id, usuario_tel)
                    VALUES (3, 1, '$nombres', '', '$email', MD5('$password'), 'S', 'C', 'S', '$apellidos', $tipo_documento_id, '$identificacion', $digit_ver, $municipio_id, '$telefono');";
              $query = $mySQL->query($sql);
              if ($query['success']) {
                $cliente_id = $mySQL->insert_id();
                $creacion_id = $cliente_id;
                $_SESSION[$prefixSession . 'password'] = $password;
                $this->enviarCorreoUsuario($email, $nombres, $password);
              } else {
                $return['success'] = false;
                $return['error'] = "Error tratando de crear el usuario del afianzado, por favor inténtelo nuevamente. Si el error persiste por favor contáctenos para darle una solución lo antes posible.";
                return $return;
              }
            }
            $sql = "INSERT INTO poliza (nombres, identificacion, digit_ver, tipo_documento_id, lug_res_afi, direccion, telefono, email, poliza_estado_id, fec_registro, fec_estado, cliente_id, ref_contrato, referidor_id, referido_estado_id, campania_id, creacion_id) "
                    . "VALUES ('$nombres', '$identificacion', $digit_ver, $tipo_documento_id, $municipio_id, '$direccion', '$telefono', '$email', 1, NOW(), NOW(), $cliente_id, '$ref_contrato', '" . $referidor['usuario_id'] . "', 1, $campania_id, $creacion_id)";
            $query = $mySQL->query($sql);
            if ($query['success']) {
              $poliza_id = $mySQL->insert_id();
              $sql = "INSERT INTO poliza_bitac (poliza_id, poliza_estado_id, comentarios, fec_registro, origen)"
                      . "VALUES ($poliza_id, 10, 'La póliza esta siendo ingresada por el usuario', NOW(), '$origen')";
              $query = $mySQL->query($sql);
              if ($query['success']) {
                $_SESSION[$prefixSession . 'poliza_id'] = $poliza_id;
                //Agrgar correo a Yeisson
                $return = $this->enviarCorreoPolizaCreada($nombres, $identificacion, $digit_ver, $municipio_id, $direccion, $telefono, $email, $ref_contrato);
              } else {
                $return['success'] = false;
                $return['error'] = "Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste por favor contáctenos para darle una solución lo antes posible.";
              }
              $return['success'] = true;
            } else {
              $return['success'] = false;
              $return['error'] = "Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste por favor contáctenos para darle una solución lo antes posible.";
            }
          } else {
            $return['success'] = false;
            $return['error'] = "Error tratando de crear el usuario del afianzado, por favor intente nuevamente.";
          }
        }
      }
    }

    return $return;
  }

  public function cargarAdjunto($clasif_docum = NULL) {
    global $mySQL;
    global $prefixSession;
    $return = array();

    if (empty($clasif_docum)) {
      $clasif_docum = 'E';
    }

    $poliza_id = $this->getPolizaId();
    if (!empty($_FILES['archivo'])) {
      $descripcion = $_POST['descripcion'];
      $nombre = $_FILES['archivo']['name'];
      $tools = new Tools();
      $tools->createLog(json_encode($_FILES['archivo']));
      //la funcion explode para detectar algo dentro de una cadena de texto
      $extension = explode(".", $nombre);
      $extension = $extension[count($extension) - 1];
      $date = date('Y-m-d');
      $folder = $this->getPathDocumentos() . $date;
      if (!file_exists($folder)) {
        if (!mkdir($folder)) {
          $return['success'] = false;
          $return['error'] = "Error al crear la carpeta para los archivos";
          return $return;
        }
      }

      $path_documento = $date . '/' . sprintf("%08d", $poliza_id) . "_" . time() . "." . $extension;
      $ruta_completa = $this->getPathDocumentos() . $path_documento;
      if (move_uploaded_file($_FILES ['archivo']['tmp_name'], $ruta_completa)) {
        $sql = "INSERT INTO poliza_docum (poliza_id, desc_documento, path_documento, clasif_docum) VALUES ($poliza_id, '$descripcion', '$path_documento', '$clasif_docum')";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          $return['success'] = true;
        } else {
          $return['success'] = false;
          $return['error'] = "El archivo no pudo ser guardado correctamante, por favor intente nuevamante";
        }
      } else {
        $return['success'] = false;
        $return['error'] = "El archivo no pudo ser almacenado correctamante, por favor intente nuevamante";
      }
    } else {
      $return['success'] = false;
      $return['error'] = "El archivo no ha sido cargado, por favor intente nuevamente";
    }
    return $return;
  }

  public function getPathDocumentos() {
    return dirname(__FILE__) . '/../documents/';
  }

  public function listarAdjuntos($clasif_docum = NULL) {
    global $mySQL;
    $return = array();
    $poliza_id = $this->getPolizaId();

    if (empty($clasif_docum)) {
      $clasif_docum = 'E';
    }

    $sql = "SELECT * FROM poliza_docum WHERE poliza_id = $poliza_id AND clasif_docum = '$clasif_docum'";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $content = array();
      if ($mySQL->num_rows($query['result']) > 0) {
        $tools = new Tools();
        while ($row = $mySQL->fetch_assoc($query['result'])) {
          $key = $this->codificarArreglo($row, array("poliza_docum_id", "path_documento"));
          $row['key'] = $key;
          $content[] = $row;
        }
      }
      $return['success'] = true;
      $return['content'] = $content;
    } else {
      $return['success'] = false;
      $return['error'] = "Error al tratar de buscar los documentos adjuntos, por favor intente nuevamente";
    }
    return $return;
  }

  public function descargarDocumento() {
    global $mySQL;
    $tools = new Tools();
    $documento = $tools->decodeRestString($_REQUEST['key']);
    if (!empty($documento->poliza_docum_id)) {
      $path_documento = $this->getPathDocumentos() . $documento->path_documento;
      if (file_exists($path_documento)) {
        $mime = mime_content_type($path_documento);
        $nom_documento = substr($documento->path_documento, strrpos($documento->path_documento, "/") + 1);
        ob_start();
        header($_SERVER['SERVER_PROTOCOL'] . ' 200 OK');
        header('Content-Type: ' . $mime);
        header("Content-Transfer-Encoding: Binary");
        header("Content-Length: " . filesize($path_documento));
        header('Pragma: no-cache');
        header('Content-disposition: attachment; filename=' . $nom_documento);
        ob_flush();
        ob_clean();
        readfile($path_documento);
        exit;
      }
    }
  }

  public function cargarMunicipios() {
    global $mySQL;
    $return = array();
    $departamento_id = $_POST['departamento_id'];
    $sql = "SELECT * FROM municipio WHERE departamento_id = $departamento_id AND municipio_activo = 'S'";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $return['success'] = true;
      $municipios = array();
      if ($mySQL->num_rows($query['result']) > 0) {
        while ($row = $mySQL->fetch_assoc($query['result'])) {
          $municipios[] = $row;
        }
      }
      $return['content'] = $municipios;
    } else {
      $return['success'] = false;
      $return['error'] = "No se han podido cargar los municipios para este departamento, por favor inicie el proceso nuevamente";
    }
    return $return;
  }

  public function actualizarMunicipio() {
    global $mySQL;
    $return = array();
    $poliza_id = $this->getPolizaId();
    $municipio_id = $_POST["municipio_id"];
    $sql = "UPDATE poliza SET municipio_id = $municipio_id WHERE poliza_id = $poliza_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $return['success'] = true;
    } else {
      $return['success'] = false;
      $return['error'] = "Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente.";
    }
    return $return;
  }

  public function getPolizaId() {
    global $prefixSession;
    $poliza_id = $_POST['poliza_id'];
    if (empty($poliza_id)) {
      $poliza_id = $_SESSION[$prefixSession . 'poliza_id'];
    }
    return $poliza_id;
  }

  public function cargarAmparosCotizacion() {
    global $mySQL;
    $return = array();
    $sector_id = $_POST['sector_id'];
    $sql = "SELECT * FROM amparo JOIN garantia USING (garantia_id) WHERE sector_id = $sector_id AND garantia_activo = 'S' ANd amparo_activo = 'S'";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $return['success'] = true;
      $amparos = array();
      if ($mySQL->num_rows($query['result']) > 0) {
        while ($row = $mySQL->fetch_assoc($query['result'])) {
          $amparos[] = $row;
        }
      }
      $return['content'] = $amparos;
    } else {
      $return['success'] = false;
      $return['error'] = "No se han podido cargar los amparos en este momento, por favor refresque la página para intentarlo nuevamente";
    }
    return $return;
  }

  public function actualizarAmparos() {
    global $mySQL;
    $return = array();
    $poliza_id = $this->getPolizaId();
    $amparos = $_POST['amparos'];
    $sector_id = $_POST['sector_id'];
    $in = '';
    foreach ($amparos as $key => $value) {
      $in .= $value;
      if ($key < count($amparos) - 1) {
        $in .= ", ";
      }
    }
    $sql = "INSERT INTO poliza_amparo (poliza_id, amparo_id, poliza_amparo_activo) SELECT $poliza_id, amparo_id, 'S' FROM amparo WHERE amparo_id IN($in)"
            . " AND NOT EXISTS (SELECT 1 FROM poliza_amparo b WHERE poliza_id = $poliza_id AND b.amparo_id = amparo.amparo_id)";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $sql = "UPDATE poliza_amparo SET poliza_amparo_activo = 'S' WHERE poliza_id = $poliza_id AND poliza_amparo_activo = 'N' and amparo_id IN($in)";
      $query = $mySQL->query($sql);
      if ($query['success']) {
        $sql = "UPDATE poliza_amparo SET poliza_amparo_activo = 'N' WHERE poliza_id = $poliza_id ANd poliza_amparo_activo = 'S' and amparo_id NOT IN($in)";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          $sql = "UPDATE poliza SET sector_id = $sector_id WHERE poliza_id = $poliza_id";
          $query = $mySQL->query($sql);
          if ($query['success']) {
            $return['success'] = true;
          } else {
            $return['success'] = false;
            $return['error'] = "No se ha podido actualizar el sector a la póliza, por favor inténtelo nuevamente";
          }
        } else {
          $return['success'] = false;
          $return['error'] = "No se han podido desactivar los amparos, por favor inténtelo nuevamente";
        }
      } else {
        $return['success'] = false;
        $return['error'] = "No se han podido activar los amparos, por favor inténtelo nuevamente";
      }
    } else {
      $return['success'] = false;
      $return['error'] = "No se han podido ingresar los amparos, por favor inténtelo nuevamente";
    }
    return $return;
  }

  public function actualizarDatosContrato() {
    global $mySQL;
    $return = array();
    $poliza_id = $this->getPolizaId();
    $valor_contrato = $_POST["valor_contrato"];
    $valor_anticipo = $_POST["valor_anticipo"];
    $tipo_anticipo = $_POST["tipo_anticipo"];
    $giro_negocio_id = $_POST["giro_negocio_id"];
    $sector_id = $_POST["sector_id"];
    $objeto = $_POST["objeto"];
    $sql = "UPDATE poliza SET valor_contrato = $valor_contrato, valor_anticipo = $valor_anticipo, giro_negocio_id = $giro_negocio_id, objeto = '$objeto',
          tipo_anticipo = '$tipo_anticipo', sector_id = $sector_id WHERE poliza_id = $poliza_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $return['success'] = true;
    } else {
      $return['success'] = false;
      $return['error'] = "Ocurrió un error al momento de actualizar los datos del contrato, por favor inténtelo nuevamente.";
    }
    return $return;
  }

  public function listarAsegurados() {
    global $mySQL;
    $return = array();
    $poliza_id = $this->getPolizaId();
    $sql = "SELECT poliza_asegurado.*, sigla, municipio_nombre, departamento_nombre FROM poliza_asegurado JOIN tipo_documento USING (tipo_documento_id) LEFT JOIN municipio USING (municipio_id) LEFT JOIN departamento USING (departamento_id) WHERE poliza_id = $poliza_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $content = array();
      if ($mySQL->num_rows($query['result']) > 0) {
        while ($row = $mySQL->fetch_assoc($query['result'])) {
          $content[] = $row;
        }
      }
      $return['success'] = true;
      $return['content'] = $content;
    } else {
      $return['success'] = false;
      $return['error'] = "Error tratando de listar los asegurados y beneficiarios, por favor intente nuevamente refrescando la pantalla";
    }
    return $return;
  }

  public function agregarAsegurado() {
    global $mySQL;
    $return = array();
    $poliza_id = $this->getPolizaId();
    $nombres = $_POST['nombres'];
    $identificacion = $_POST['identificacion'];
    $digit_ver = $_POST['digit_ver'];
    $tipo_documento_id = $_POST['tipo_documento_id'];
    $municipio_id = $_POST['municipio_id'];
    $direccion = $_POST['direccion'];
    $telefono = $_POST['telefono'];
    $email = $_POST['email'];
//    $es_asegur = $_POST['es_asegur'];
//    $es_benef = $_POST['es_benef'];
    if (empty($municipio_id)) {
      $municipio_id = "NULL";
    }
    if (empty($digit_ver)) {
      $digit_ver = "NULL";
    }

    $sql = "SELECT * FROM poliza_asegurado WHERE poliza_id = $poliza_id AND tipo_documento_id = $tipo_documento_id AND identificacion = '$identificacion'";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) == 0) {
        $sql = "SELECT * FROM poliza WHERE poliza_id = $poliza_id AND tipo_documento_id = $tipo_documento_id AND identificacion = '$identificacion'";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          if ($mySQL->num_rows($query['result']) == 0) {
            $sql = "INSERT INTO poliza_asegurado (poliza_id, municipio_id, tipo_documento_id, identificacion, digit_ver, nombres, email, telefono, direccion, es_asegur, es_benef) "
                    . "VALUES ($poliza_id, $municipio_id, $tipo_documento_id, '$identificacion', $digit_ver, '$nombres', '$email', '$telefono', '$direccion', true, true)";
            $query = $mySQL->query($sql);
            if ($query['success']) {
              $return['success'] = true;
            } else {
              $return['success'] = false;
              $return['error'] = "Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste por favor contáctenos para darle una solución lo antes posible.";
            }
          } else {
            $return['success'] = false;
            $return['error'] = "El Asegurado o Beneficiario no puede ser el mismo Afianzado, por favor revise el Tipo de Documento y la Identificación.";
          }
        } else {
          $return['success'] = false;
          $return['error'] = "Ocurrió un error al momento de validar la información, por favor inténtelo nuevamente. Si el error persiste por favor contáctenos para darle una solución lo antes posible.";
        }
      } else {
        $return['success'] = false;
        $return['error'] = "La persona que esta intentando ingresar ya ha sido registrada, por favor revise el Tipo de Documento y la Identificación.";
      }
    } else {
      $return['success'] = false;
      $return['error'] = "Ocurrió un error al momento de validar la información, por favor inténtelo nuevamente. Si el error persiste por favor contáctenos para darle una solución lo antes posible.";
    }

    return $return;
  }

  public function eliminarAsegurado() {
    global $mySQL;
    $return = array();
    $poliza_asegurado_id = $_POST['poliza_asegurado_id'];
    $sql = "DELETE FROM poliza_asegurado WHERE poliza_asegurado_id = $poliza_asegurado_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $return['success'] = true;
    } else {
      $return['success'] = false;
      $return['error'] = "Ocurrió un error al momento de eliminar el asegurado, por favor inténtelo nuevamente. Si el error persiste por favor contáctenos para darle una solución lo antes posible.";
    }
    return $return;
  }

  public function calcularFinVigencia() {
    global $mySQL;
    $return = array();
    $dias = $_POST["dias"];
    $meses = $_POST["meses"];
    $anios = $_POST["anios"];
    $fecha_inicio = $_POST['fecha_inicio'];
    $con_cambio = false;
    if (!empty($dias)) {
      $sql = "SELECT DATE_ADD('$fecha_inicio', INTERVAL $dias DAY) AS fec_final";
      $query = $mySQL->result($sql);
      if ($query['success']) {
        $fecha_inicio = $query['result'];
        $con_cambio = true;
      } else {
        $return['success'] = false;
        $return['error'] = "Ocurrió un error al momento de calcular los días, por favor inténtelo nuevamente.";
        return $return;
      }
    }
    if (!empty($meses)) {
      $sql = "SELECT DATE_ADD('$fecha_inicio', INTERVAL $meses MONTH) AS fec_final";
      $query = $mySQL->result($sql);
      if ($query['success']) {
        $fecha_inicio = $query['result'];
        $con_cambio = true;
      } else {
        $return['success'] = false;
        $return['error'] = "Ocurrió un error al momento de calcular los meses, por favor inténtelo nuevamente.";
        return $return;
      }
    }
    if (!empty($anios)) {
      $sql = "SELECT DATE_ADD('$fecha_inicio', INTERVAL $anios YEAR) AS fec_final";
      $query = $mySQL->result($sql);
      if ($query['success']) {
        $fecha_inicio = $query['result'];
        $con_cambio = true;
      } else {
        $return['success'] = false;
        $return['error'] = "Ocurrió un error al momento de calcular los años, por favor inténtelo nuevamente.";
        return $return;
      }
    }

    $return['success'] = true;
    if ($con_cambio) {
      $return['fec_final'] = $fecha_inicio;
    } else {
      $return['fec_final'] = '';
    }
    return $return;
  }

  public function actualizarFechas() {
    global $mySQL;
    $return = array();

    $poliza_id = $this->getPolizaId();
    $fec_contrato = $_POST["fec_contrato"];
    $fec_inicio = $_POST["fec_inicio"];
    $dias = $_POST["dias"];
    $meses = $_POST["meses"];
    $anios = $_POST["anios"];
    $fec_final = $_POST["fec_final"];
    if (empty($dias)) {
      $dias = "NULL";
    }
    if (empty($meses)) {
      $meses = "NULL";
    }
    if (empty($anios)) {
      $anios = "NULL";
    }
    $sql = "UPDATE poliza SET fec_contrato = '$fec_contrato', fec_inicio = '$fec_inicio', dias = $dias, meses = $meses, anios = $anios, 
            fec_final = '$fec_final' WHERE poliza_id = $poliza_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $return['success'] = true;
    } else {
      $return['success'] = false;
      $return['error'] = "Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste por favor contáctenos para darle una solución lo antes posible.";
    }
    return $return;
  }

  public function buscarMunicipios() {
    global $mySQL;
    $return = array();
    $term = $_REQUEST['term'];
    $sql = "SELECT municipio_id AS id, CONCAT(municipio_nombre, ' - ', departamento_nombre) AS value, CONCAT(municipio_nombre, ' - ', departamento_nombre) AS label FROM municipio JOIN departamento USING (departamento_id) WHERE municipio_nombre LIKE '$term%' AND municipio_activo = 'S' ORDER BY municipio_nombre LIMIT 10";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        while ($row = $mySQL->fetch_assoc($query['result'])) {
          $return[] = $row;
        }
      }
    }
    return $return;
  }

  public function crearComprimido() {
    global $mySQL;
    $return = array();
    $poliza_id = $this->getPolizaId();
    $descripcion = "Archivos comprimidos para la poliza " . $poliza_id;
    $insertar = true;
    $return['success'] = true;

    $folder = $this->getPathDocumentos() . "comprimidos";
    $path_documento = "comprimidos/" . sprintf("%08d", $poliza_id) . "_expedidos.zip";
    $ruta_completa = $this->getPathDocumentos() . $path_documento;
    if (!file_exists($folder)) {
      if (!mkdir($folder)) {
        $return['success'] = false;
        $return['error'] = "Error al crear la carpeta para los archivos";
        return $return;
      }
    }
    if (file_exists($ruta_completa)) {
      unlink($ruta_completa);
      $insertar = false;
    }
    $sql = "SELECT * FROM poliza_docum WHERE poliza_id = $poliza_id AND clasif_docum = 'S' AND poliza_docum_activo = 'S'";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $content = array();
      if ($mySQL->num_rows($query['result']) > 0) {
        $tools = new Tools();
        $zip = new ZipArchive();
        $res = $zip->open($ruta_completa, ZipArchive::CREATE);
        if ($res === TRUE) {
          while ($row = $mySQL->fetch_assoc($query['result'])) {
            $nom_documento = $this->getPathDocumentos() . $row['path_documento'];
            if (file_exists($nom_documento)) {
              $res = $zip->addFile($nom_documento, basename($nom_documento));
              if (!$res) {
                $return['success'] = false;
                $return['error'] = "Los archivos no pudieron ser cargados correctamente, por favor recargue la página he intente nuevamente";
                return $return;
              }
            }
          }
        } else {
          $return['success'] = false;
          $return['error'] = "Los archivos no pudieron ser cargados correctamente, por favor recargue la página he intente nuevamente";
        }
        $res = $zip->close();
      } else {
        $return['success'] = false;
        $return['error'] = "La poliza no tiene documentos adjuntos.";
      }
    } else {
      $return['success'] = false;
      $return['error'] = "Error al tratar de buscar los documentos adjuntos, por favor intente nuevamente";
    }

    $x = array(
        'poliza_docum_id' => time(),
        'path_documento' => "$path_documento"
    );
    $key = $this->codificarArreglo($x, array("poliza_docum_id", "path_documento"));
    $return['content'] = $key;
    return $return;
  }

  public function cargarAmparos() {
    global $mySQL;
    $return = array();
    $garantia_id = $_POST['garantia_id'];

    $sql = "SELECT * FROM amparo 
            INNER JOIN tipo_amparo USING (tipo_amparo_id) 
            WHERE amparo_activo = 'S' AND EXISTS 
            (SELECT 1 FROM garantia WHERE garantia.garantia_id = amparo.garantia_id AND garantia_activo = 'S')";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $amparos = array();
        while ($row = $mySQL->fetch_assoc($query['result'])) {
          $amparos[] = $row;
        }

        $sql = "SELECT * FROM tipo_liqui";
        $query_liqui = $mySQL->query($sql);
        if ($query_liqui['success']) {
          if ($mySQL->num_rows($query_liqui['result']) > 0) {
            $tipo_liqui = array();
            while ($row_liqui = $mySQL->fetch_assoc($query_liqui['result'])) {
              $tipo_liqui[] = $row_liqui;
            }
            $return['tipo_liqui'] = $tipo_liqui;
          }
        } else {
          $return['success'] = false;
          $return['error'] = "Error cargando las liquidaciones de los amparos, por favor intente nuevamente";
          return $return;
        }

        $return['success'] = true;
        $return['amparos'] = $amparos;
        $sql = "SELECT * FROM periodo_tiempo";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          if ($mySQL->num_rows($query['result']) > 0) {
            $periodo_tiempos = array();
            while ($row = $mySQL->fetch_assoc($query['result'])) {
              $periodo_tiempos[] = $row;
            }
            $return['periodo_tiempos'] = $periodo_tiempos;
          }
        } else {
          $return['success'] = false;
          $return['error'] = "";
        }
      }
    } else {
      $return['success'] = false;
      $return['error'] = "Error tratando de cargar los amparos de la garantia, por favor intente nuevamente";
    }
    return $return;
  }

  public function buscarAmparosGarantia() {
    global $mySQL;
    $return = array();
    $amparo_id = $_POST['amparo_id'];
    $sql = "SELECT * FROM amparo WHERE amparo_id = $amparo_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $return = $mySQL->fetch_assoc($query['result']);
        $sql = "SELECT tipo_liqui_id FROM amparo_liqui WHERE amparo_id = $amparo_id";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          $tipo_liqui_ids = array();
          if ($mySQL->num_rows($query['result']) > 0) {
            while ($row = $mySQL->fetch_assoc($query['result'])) {
              $tipo_liqui_ids[] = $row['tipo_liqui_id'];
            }
          }
          $return['success'] = true;
          $return['garantia_ids'] = $garantia_ids;
          $return['tipo_liqui_ids'] = $tipo_liqui_ids;
        } else {
          $return['success'] = false;
          $return['error'] = "Error tratando de buscar los tipos de liquidación, por favor intente nuevamente";
        }
      } else {
        $return['success'] = false;
        $return['error'] = "Amparo no encontrado";
      }
    } else {
      $return['success'] = false;
      $return['error'] = 'Ocurrió un error al momento de consultar la información del amparo, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
    }
    return $return;
  }

  public function calcularFechaFinVigencias() {
    global $mySQL;
    $return = array();
    $duracion = $_POST['duracion'];
    $periodo_tiempo = $_POST['periodo_tiempo'];
    $fecha_inicio = $_POST['fecha_inicio'];
    $sql = "SELECT DATE_ADD('$fecha_inicio', INTERVAL $duracion $periodo_tiempo) AS fec_final";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result'])) {
        $return = $mySQL->fetch_assoc($query['result']);
        $return['success'] = true;
      }
    } else {
      $return['success'] = false;
      $return['error'] = "Ocurrió un error al momento de calcular la fecha de fin de ejecución, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.";
    }
    return $return;
  }

  public function guardarAmparos() {
    global $mySQL;
    $return = array();
    $tipo = $_POST['tipo'];
    $poliza_id = $this->getPolizaId();
    $garantia_id = $_POST["garantia_id"];
    $poliza_amparo_id = $_POST["poliza_amparo_id"];
    $amparos = $_POST["amparos"];
    $valor_amparo = $_POST["valor_amparo"];
    $fec_inicio = $_POST["fec_inicio"];
    $fec_final = (!empty($_POST["fec_final"]) ? $_POST["fec_final"] : 'null');
    $valor_asegurado = $_POST["hiddenValAseg"];
    $tipo_liqui = $_POST["tipo_liqui"];
    $dias = (!empty($_POST["dias"]) ? $_POST["dias"] : 'null');
    $meses = (!empty($_POST["meses"]) ? $_POST["meses"] : 'null');
    $anios = (!empty($_POST["anios"]) ? $_POST["anios"] : 'null');
//    die();

    if ($tipo == "nuevo") {
      $sql = "SELECT * FROM poliza_amparo WHERE amparo_id = $amparos AND poliza_id = $poliza_id AND poliza_amparo_activo = 'N'";
      $query = $mySQL->query($sql);
      if ($query['success']) {
        if ($mySQL->num_rows($query['result']) > 0) {
          $sql = "UPDATE poliza_amparo SET amparo_id = $amparos, tipo_liqui_id = $tipo_liqui, valor_liqui = $valor_amparo, fec_inicio = '$fec_inicio', "
                  . "fec_final = '$fec_final', valor_asegurado = $valor_asegurado, poliza_amparo_activo = 'S',  dias = $dias, meses = $meses, anios = $anios  "
                  . "WHERE amparo_id = $amparos AND poliza_id = $poliza_id";
          $query = $mySQL->query($sql);
          if ($query['success']) {
            $return['success'] = true;
          } else {
            $return['success'] = false;
            $return['error'] = 'Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
            //$return['error'] = $query['error'];
          }
        } else {
          $sql = "INSERT INTO poliza_amparo (amparo_id, tipo_liqui_id, valor_liqui, fec_inicio, fec_final, valor_asegurado, poliza_amparo_activo, dias, meses, anios, poliza_id)
                VALUES ($amparos, $tipo_liqui, $valor_amparo, '$fec_inicio', '$fec_final', '$valor_asegurado', 'S', $dias, $meses, $anios, $poliza_id)";
          $query = $mySQL->query($sql);
          if ($query['success']) {
            $return['success'] = true;
          } else {
            $return['success'] = false;
            $return['error'] = 'Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
            //$return['error'] = $query['error'];
          }
        }
      } else {
        $return['success'] = false;
        $return['error'] = 'Ocurrió un error al momento de consultar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
        //$return['error'] = $query['error'];
      }
    } else {
      $sql = "UPDATE poliza_amparo SET amparo_id = $amparos, tipo_liqui_id = $tipo_liqui, valor_liqui = $valor_amparo, fec_inicio = '$fec_inicio', "
              . "fec_final = '$fec_final', valor_asegurado = $valor_asegurado, poliza_amparo_activo = 'S',  dias = $dias, meses = $meses, anios = $anios  "
              . "WHERE poliza_amparo_id = $poliza_amparo_id";
      $query = $mySQL->query($sql);
      if ($query['success']) {
        $return['success'] = true;
      } else {
        $return['success'] = false;
        $return['error'] = 'Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
        //$return['error'] = $query['error'];
      }
    }
    return $return;
  }

  public function buscarAmparo() {
    global $mySQL;
    $return = array();
    $poliza_amparo_id = $_POST['poliza_amparo_id'];
    $sql = "SELECT * FROM poliza_amparo WHERE poliza_amparo_id = $poliza_amparo_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $return = $mySQL->fetch_assoc($query['result']);
        $return['success'] = true;
      } else {
        $return['success'] = false;
        $return['error'] = "Amparo no encontrado";
      }
    } else {
      $return['success'] = false;
      $return['error'] = 'Ocurrió un error al momento de consultar la información del amparo, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
    }
    return $return;
  }

  public function eliminarAmparo() {
    global $mySQL;
    $return = array();
    $poliza_amparo_id = $_POST["poliza_amparo_id"];
    $sql = "UPDATE poliza_amparo SET poliza_amparo_activo = 'N' WHERE poliza_amparo_id = $poliza_amparo_id";
//  die;
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $return['success'] = true;
    } else {
      $return['success'] = false;
      $return['error'] = "Ocurrió un error al momento de eliminar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.";
    }
    return $return;
  }

  public function getInfoPoliza() {
    global $mySQL;
    $return = array();
    $poliza_id = $this->getPolizaId();

    $sql = "SELECT * FROM poliza WHERE poliza_id = $poliza_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $info_poliza = $mySQL->fetch_assoc($query['result']);
      }
    }
    return $info_poliza;
  }

  public function enviarCorreoInicial() {
    global $mySQL;
    $config_vars = $mySQL->getConfigVars();
    $return = array();
    $info_poliza = $this->getInfoPoliza();

    $tools = new Tools();
    $key = $this->crearKeyPoliza($info_poliza);

    $params['P_AFIANZADO'] = $this->getNombreAfianzado($info_poliza['nombres'], $info_poliza['tipo_documento_id']);
    $params['P_REFERENCIA'] = $info_poliza['ref_contrato'];
    $params['P_LOGO'] = $config_vars['mail.logo'];
    $params['P_CORREO'] = $info_poliza['email'];
    $params['P_ENLACE'] = $config_vars['server.url'] . "track_poliza?key=" . $key;

    $template = $tools->loadTemplate("pendiente_revision.php", $params);
    if ($template['success']) {
      $message = $template['content'];
      $footer = $tools->loadTemplate("footer.html", $params);
      $message .= $footer['content'];
      $subject = "Solicitud recibida exitosamente para el contrato con referencia No " . $info_poliza['ref_contrato'];
      $return = $tools->sendEmail($subject, $message, NULL, NULL, NULL, $info_poliza['email'], NULL, NULL, NULL);
      $return['content'] = $key;
    } else {
      $return['success'] = false;
      $return['error'] = "No se ha podido cargar la información del correo";
    }

    return $return;
  }

  public function guardarAseguradora() {
    global $mySQL;
    $return = array();
    $poliza_id = $this->getPolizaId();
    $poliza_row = $this->getInfoPoliza();
    $observaciones = $_POST['observaciones'];
    $estado = $_POST['estado'];
    $metodo_pago_id = $_POST['metodo_pago_id'];
    $aseguradora_id = $_POST['aseguradora_id'];
    $correo_afianzado = $_POST['correo_afianzado'];

    switch ($estado) {
      case 'aprobada':
        $poliza_estado_id = 2;
        $plantilla = 'aprobada.php';
        $subject = "El contrato " . $poliza_row['ref_contrato'] . " ha sido Apropado";
        break;

      case 'rechazada':
        $poliza_estado_id = 3;
        $plantilla = 'rechazada.php';
        $subject = "El contrato " . $poliza_row['ref_contrato'] . " ha sido Rechazado";
        break;

      case 'requiereInfo':
        $poliza_estado_id = 4;
        $plantilla = 'requiere_informacion.php';
        $estado = 'Requiere más información';
        $subject = "El contrato " . $poliza_row['ref_contrato'] . " requiere más información";
        break;

      case 'aprobarPago':
        $poliza_estado_id = 6;
        $plantilla = 'pagada.php';
        $subject = "Se ha registrado el pago para el contrato " . $poliza_row['ref_contrato'];
        break;
    }

    if ($poliza_estado_id == 2) {
      $sql = "SELECT * FROM aseguradora WHERE aseguradora_activo = 'S'";
      $query = $mySQL->query($sql);
      if ($query['success']) {
        if ($mySQL->num_rows($query['result']) > 0) {
          while ($row = $mySQL->fetch_assoc($query['result'])) {
            $valAseguradora = $_POST['ck_aseg_' . $row['aseguradora_id']];
            $req_sarlaft = $_POST['req_sarlaft_' . $row['aseguradora_id']];
            if (empty($req_sarlaft)) {
              $req_sarlaft = 'N';
            }
            if (!empty($valAseguradora)) {
              $sql = "SELECT garantia.garantia_id 
                    FROM garantia
                    INNER JOIN amparo USING (garantia_id)
                    LEFT JOIN poliza_amparo ON (amparo.amparo_id = poliza_amparo.amparo_id)
                    WHERE poliza_amparo.poliza_id = $poliza_id AND poliza_amparo.poliza_amparo_activo = 'S' GROUP BY garantia_id";
              $query2 = $mySQL->query($sql);
              if ($query2['success']) {
                if ($mySQL->num_rows($query2['result']) > 0) {
                  while ($row2 = $mySQL->fetch_assoc($query2['result'])) {
                    $prima = $_POST['valor_prima_' . $row['aseguradora_id'] . '_' . $row2['garantia_id']];
                    $gastos_expedicion = $_POST['gastos_expedicion_' . $row['aseguradora_id'] . '_' . $row2['garantia_id']];
                    $iva = $_POST['iva_' . $row['aseguradora_id'] . '_' . $row2['garantia_id']];
                    $dia = $_POST['dia_' . $row['aseguradora_id']];
                    $hora = $_POST['hora_' . $row['aseguradora_id']];
                    $min = $_POST['min_' . $row['aseguradora_id']];
                    $obser_aseg = $_POST['obser_aseg_' . $row['aseguradora_id']];
                    if (empty($dia)) {
                      $dia = "NULL";
                    }
                    if (empty($hora)) {
                      $hora = "NULL";
                    }
                    if (empty($min)) {
                      $min = "NULL";
                    }
                    $total = $prima + $gastos_expedicion + $iva;

                    $arrIns[] = "INSERT INTO poliza_aseguradora (poliza_id, aseguradora_id, garantia_id, prima, expedicion, impuesto, total, req_sarlaft, es_seleccionada, prom_dia_entrega, prom_hor_entrega, prom_min_entrega, observaciones)
                            VALUES ($poliza_id, $valAseguradora, " . $row2['garantia_id'] . ", $prima, $gastos_expedicion, $iva, $total, '$req_sarlaft' , 'N', $dia, $hora, $min, '$obser_aseg')";
                  }
                }
              }
            }
          }
        }
      } else {
        $return['success'] = false;
        $return['error'] = 'Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
        return $return;
      }
    }

    if ($poliza_estado_id == 6) {
      $sql = "UPDATE poliza SET metodo_pago_id = $metodo_pago_id WHERE poliza_id = $poliza_id";
      $query = $mySQL->query($sql);
      if ($query['success']) {
        $sql = "UPDATE poliza_aseguradora SET es_seleccionada = 'N' WHERE poliza_id = $poliza_id AND aseguradora_id <> $aseguradora_id";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          $sql = "UPDATE poliza_aseguradora SET es_seleccionada = 'S' WHERE poliza_id = $poliza_id AND aseguradora_id = $aseguradora_id";
          $query = $mySQL->query($sql);
          if (!$query['success']) {
            $return['success'] = false;
            $return['error'] = 'Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
            //$return['error'] = $query['error'];
            return $return;
          }
        } else {
          $return['success'] = false;
          $return['error'] = 'Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
          //$return['error'] = $query['error'];
        }
      } else {
        $return['success'] = false;
        $return['error'] = 'Ocurrió un error al momento de guardar las información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
        //$return['error'] = $query['error'];
      }
    }
//  die;
    $return = $this->actualizarEstadosPoliza($poliza_id, $observaciones, $poliza_estado_id, 'NULL', 'Sistema');
    if ($return['success']) {
      if (!empty($arrIns)) {
        $sql = "DELETE FROM poliza_aseguradora WHERE poliza_id = $poliza_id";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          foreach ($arrIns as $i => $sql) {
            $query = $mySQL->query($sql);
            if ($query['success']) {
              $return['success'] = true;
            } else {
              $return['success'] = false;
              $return['error'] = 'Ocurrió un error al momento de guardar el metodo de pago, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
              //$return['error'] = $query['error'];
              break;
            }
          }
        } else {
          $return['success'] = false;
          $return['error'] = 'Ocurrió un error al momento de eliminar las garantias antiguas, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
        }
      }
    }

    if ($return['success']) {
      $return = $this->enviarCorreoEstados($plantilla, $subject);
    }

    return $return;
  }

  public function actualizarInfoPoliza() {
    global $mySQL;
    $return = array();
    $poliza_id = $this->getPolizaId();
    $valor_contrato = $_POST["valor_contrato"];
    $valor_anticipo = $_POST["valor_anticipo"];
    $tipo_anticipo = $_POST["tipo_anticipo"];
    $ref_contrato = $_POST["ref_contrato"];
    $motivo_poliza = $_POST["motivo_poliza"];
    $objeto = $_POST["objeto"];
    $sector = $_POST["sector"];
    $sql = "UPDATE poliza SET valor_contrato = $valor_contrato, valor_anticipo = $valor_anticipo, giro_negocio_id = $motivo_poliza, objeto = '$objeto',
          tipo_anticipo = '$tipo_anticipo', ref_contrato = '$ref_contrato', sector_id = $sector WHERE poliza_id = $poliza_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $return['success'] = true;
    } else {
      $return['success'] = false;
      $return['error'] = "Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.";
    }
    return $return;
  }

  public function actualizarAfianzado() {
    global $mySQL;
    $return = array();
    $poliza_id = $this->getPolizaId();
    $documento_id = $_POST["documento_id"];
    $identificacion = $_POST["identificacion"];
    $digit_ver = $_POST["digit_ver"];
    $nombres = $_POST["nombres"];
    $email = $_POST["email"];
    $telefono = $_POST["telefono"];
    $direccion = $_POST["direccion"];
    $lug_res_afi = $_POST["lug_res_afi"];
    $sql = "UPDATE poliza SET tipo_documento_id = $documento_id, identificacion = $identificacion, digit_ver = $digit_ver, nombres = '$nombres', 
          email = '$email', telefono = $telefono, direccion = '$direccion', lug_res_afi = $lug_res_afi WHERE poliza_id = $poliza_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $return['success'] = true;
    } else {
      $return['success'] = false;
      $return['error'] = "Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.";
    }
    return $return;
  }

  public function actualizarDepartamento() {
    global $mySQL;
    $return = array();
    $poliza_id = $this->getPolizaId();
    $municipio_id = $_POST["municipio_id"];
    $sql = "UPDATE poliza SET municipio_id = $municipio_id WHERE poliza_id = $poliza_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $return['success'] = true;
    } else {
      $return['success'] = false;
      $return['error'] = "Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.";
    }
    return $return;
  }

  public function agregarBeneficiario() {
    global $mySQL;
    $return = array();
    $tipo = $_POST['tipo'];
    $poliza_id = $this->getPolizaId();
    $nombres = $_POST["nombres"];
    $documento_id = $_POST["documento_id"];
    $identificacion = $_POST["identificacion"];
    $digit_ver = (!empty($_POST["digit_ver"]) ? $_POST["digit_ver"] : 0);
    $municipio_id = $_POST["municipio_id"];
    $direccion = $_POST["direccion"];
    $telefono = (!empty($_POST["telefono"]) ? $_POST["telefono"] : '"null"');
    $email = $_POST["email"];
    $asegurado = (!empty($_POST["asegurado"]) ? $_POST["asegurado"] : 0);
    $beneficiario = (!empty($_POST["beneficiario"]) ? $_POST["beneficiario"] : 0);
    $poliza_asegurado_id = $_POST["poliza_asegurado_id"];
//  die();
    if ($tipo == "nuevo") {
      $sql = "INSERT INTO poliza_asegurado (poliza_id, municipio_id, tipo_documento_id, identificacion, digit_ver, nombres, email, telefono, direccion, es_asegur, es_benef)
          VALUES($poliza_id, $municipio_id, $documento_id, $identificacion, $digit_ver, '$nombres', '$email', $telefono, '$direccion', $asegurado, $beneficiario)";
      $query = $mySQL->query($sql);
      if ($query['success']) {
        $return['success'] = true;
      } else {
        $return['success'] = false;
        $return['error'] = "Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.";
      }
    } else {
      $sql = "UPDATE poliza_asegurado SET municipio_id = $municipio_id, tipo_documento_id = $documento_id, identificacion = $identificacion, digit_ver = $digit_ver, 
            nombres = '$nombres', email = '$email', telefono = $telefono, direccion = '$direccion', es_asegur = $asegurado, es_benef = $beneficiario
            WHERE poliza_asegurado_id = $poliza_asegurado_id";
      $query = $mySQL->query($sql);
      if ($query['success']) {
        $return['success'] = true;
      } else {
        $return['success'] = false;
        $return['error'] = "Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.";
      }
    }
    return $return;
  }

  public function cambiarEstadoDocumentos() {
    global $mySQL;
    $return = array();
    $poliza_docum_id = $_POST["poliza_docum_id"];
    $estado = $_POST["estado"];
    $sql = "UPDATE poliza_docum SET poliza_docum_activo = '$estado' WHERE poliza_docum_id = $poliza_docum_id";
//  die;
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $return['success'] = true;
    } else {
      $return['success'] = false;
      $return['error'] = "Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.";
    }
    return $return;
  }

  function buscarAsegurado() {
    global $mySQL;
    $return = array();
    $poliza_asegurado_id = $_POST['poliza_asegurado_id'];
    $sql = "SELECT CONCAT(municipio.municipio_nombre, ', ', departamento.departamento_nombre) municipio_nombre, poliza_asegurado.*
          FROM poliza_asegurado
          LEFT JOIN municipio ON (municipio.municipio_id = poliza_asegurado.municipio_id)
          LEFT JOIN departamento ON (departamento.departamento_id = municipio.departamento_id)
          WHERE poliza_asegurado_id = $poliza_asegurado_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result'])) {
        $return = $mySQL->fetch_assoc($query['result']);
        $return['success'] = true;
      } else {
        $return['success'] = false;
        $return['error'] = "producto no encontrado";
      }
    } else {
      $return['success'] = false;
      $return['error'] = 'Ocurrió un error al momento de consultar la información del asegurado, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
    }
    return $return;
  }

  public function validarPoliza() {
    global $mySQL;
    $return = array();
    $poliza_id = $this->getPolizaId();

    $sql = "SELECT * FROM poliza WHERE poliza_id = $poliza_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $poliza = $mySQL->fetch_assoc($query['result']);
        if ($poliza['fec_final'] < $poliza['fec_inicio']) {
          $return['errors'][] = "La fecha de finalización del contrato debe ser mayor a la fecha de inicio del contrato.";
        }

        $sql = "SELECT * FROM poliza_amparo WHERE poliza_id = $poliza_id AND poliza_amparo_activo = 'S'";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          if ($mySQL->num_rows($query['result']) <= 0) {
            $return['errors'][] = 'La póliza debe tener por lo mínimo un amparo.';
          }

          $sql = "SELECT SUM(es_asegur) asegurado, SUM(es_benef) beneficiario
                    FROM poliza_asegurado
                    INNER JOIN poliza USING (poliza_id)
                    WHERE poliza_id = $poliza_id";
          $query = $mySQL->query($sql);
          if ($query['success']) {
            $poliza_aseg = $mySQL->fetch_assoc($query['result']);
            if ($poliza_aseg['asegurado'] <= 0) {
              $return['errors'][] = 'La póliza debe tener por lo menos 1 asegurado.';
            }
            if ($poliza_aseg['beneficiario'] <= 0) {
              $return['warnings'][] = "Esta póliza no cuenta con beneficiarios.";
            }
          } else {
            $return['errors'][] = "Ocurrió un error al momento de consultar la información de los asegurados y beneficiarios asociados a la póliza, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.";
          }
        } else {
          $return['errors'][] = 'Ocurrió un error al momento de consultar la información de las garantias asociadas a la póliza, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
          //$return['error'] = $query['error'];
        }
      } else {
        $return['errors'][] = 'Póliza no encontrada.';
      }
    } else {
      $return['errors'][] = 'Ocurrió un error al momento de consultar la información de la póliza, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
    }
    if (!empty($return['errors']) || !empty($return['warnings'])) {
      $return['success'] = false;
    } else {
      $return['success'] = true;
    }
    return $return;
  }

  public function enviarCorreoEstados($plantilla, $subject) {
    global $mySQL;
    $config_vars = $mySQL->getConfigVars();
    $return = array();
    $info_poliza = $this->getInfoPoliza();
    //$plantilla = 'aprobada.php';

    $tools = new Tools();
    $key = $this->crearKeyPoliza($info_poliza);

    $params['P_AFIANZADO'] = $this->getNombreAfianzado($info_poliza['nombres'], $info_poliza['tipo_documento_id']);
    $params['P_REFERENCIA'] = $info_poliza['ref_contrato'];
    $params['P_LOGO'] = $config_vars['mail.logo'];
    $params['P_MARCAS'] = $config_vars['mail.marcas'];
    $params['P_ENLACE'] = $config_vars['server.url'] . "track_poliza?key=" . $key;

    $template = $tools->loadTemplate($plantilla, $params);
    if ($template['success']) {
      $message = $template['content'];
      $footer = $tools->loadTemplate("footer.html", $params);
      $message .= $footer['content'];
      $return = $tools->sendEmail($subject, $message, NULL, NULL, NULL, $info_poliza['email'], NULL, NULL, NULL);
    } else {
      $return['success'] = false;
      $return['error'] = "No se ha podido cargar la información del correo";
    }

    return $return;
  }

  public function actializarPolizaEmitida() {
    global $mySQL;
    $return = array();
    $observaciones = $_POST['observacionesEmitida'];
    $poliza_estado_id = 7;
    $referido_estado_id = 2;
    $poliza_id = $this->getPolizaId();
    $origen = 'Sistema';

    $return = $this->actualizarEstadosPoliza($poliza_id, $observaciones, $poliza_estado_id, $referido_estado_id, $origen);

    if ($return['success']) {
      $return = $this->enviarCorreoEmitida();
    }

    return $return;
  }

  public function actualizarEstadosPoliza($poliza_id, $observaciones, $poliza_estado_id, $referido_estado_id, $origen) {
    global $mySQL;
    $sql = "UPDATE poliza SET poliza_estado_id = $poliza_estado_id, referido_estado_id = $referido_estado_id, comentarios_estado = '$observaciones' WHERE poliza_id = $poliza_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $sql = "INSERT INTO poliza_bitac (poliza_id, poliza_estado_id, comentarios, fec_registro, origen) VALUES ($poliza_id, $poliza_estado_id, '$observaciones', NOW(), '$origen')";
      $query = $mySQL->query($sql);
      if ($query['success']) {
        $return['success'] = true;
      } else {
        $return['success'] = false;
        $return['error'] = 'Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste por favor contáctenos para darle una solución lo antes posible.';
        //$return['error'] = $query['error'];
      }
    } else {
      $return['success'] = false;
      $return['error'] = 'Ocurrió un error al momento de actualizar la información de la poliza, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
    }

    return $return;
  }

  public function enviarCorreoEmitida() {
    global $mySQL;
    $config_vars = $mySQL->getConfigVars();
    $return = array();
    $info_poliza = $this->getInfoPoliza();

    $tools = new Tools();
    $key = $this->crearKeyPoliza($info_poliza);

    $params['P_AFIANZADO'] = $this->getNombreAfianzado($info_poliza['nombres'], $info_poliza['tipo_documento_id']);
    $params['P_REFERENCIA'] = $info_poliza['ref_contrato'];
    $params['P_LOGO'] = $config_vars['mail.logo'];
    $params['P_ENLACE'] = $config_vars['server.url'] . "track_poliza?key=" . $key;

    $template = $tools->loadTemplate("emitida.php", $params);
    if ($template['success']) {
      $message = $template['content'];
      $footer = $tools->loadTemplate("footer.html", $params);
      $message .= $footer['content'];
      $subject = "La solicitud del contrato con referencia No " . $info_poliza['ref_contrato'] . " se encuentra en estado emitida";
      $return = $tools->sendEmail($subject, $message, NULL, NULL, NULL, $info_poliza['email'], $config_vars['mail.reply'], NULL, NULL);
      $return['content'] = $key;
    } else {
      $return['success'] = false;
      $return['error'] = "No se ha podido cargar la información del correo";
    }

    return $return;
  }

  public function eliminarAdjunto() {

    global $mySQL;
    $tools = new Tools();
    $documento = $tools->decodeRestString($_POST['key']);
    if (!empty($documento->poliza_docum_id)) {
      $path_documento = $this->getPathDocumentos() . $documento->path_documento;
      if (file_exists($path_documento)) {

        $sql = "DELETE FROM poliza_docum WHERE poliza_id = $documento->poliza_id AND path_documento = '$documento->path_documento' AND poliza_docum_id =$documento->poliza_docum_id";
        $query = $mySQL->query($sql);
        if ($query['success']) {
          $content = array();
          if ($mySQL->num_rows($query['result']) > 0) {
            $tools = new Tools();
            while ($row = $mySQL->fetch_assoc($query['result'])) {
              $key = $tools->encodeRestArray($row);
              $row['key'] = $key;
              $content[] = $row;
            }
          }
          $return['success'] = true;
          unlink($path_documento);
          $return['content'] = $content;
        } else {
          $return['success'] = false;
          $return['error'] = "Error al tratar de buscar los documentos adjuntos, por favor intente nuevamente";
        }
        return $return;
      }
    }
  }

  public function actualizarAseguradora() {
    global $mySQL;
    $return = array();
    $poliza_id = $this->getPolizaId();
    $poliza_aseguradora = $_POST['poliza_aseguradora'];

    foreach ($poliza_aseguradora as $key => $value) {
      $cod_poliza = $_POST['cod_poliza_' . $value['value']];
      $fec_poliza = $_POST['fec_poliza_' . $value['value']];
      $arrIns[] = "UPDATE poliza_aseguradora SET cod_poliza = '$cod_poliza', fec_poliza = '$fec_poliza' WHERE poliza_aseguradora_id = " . $value['value'];
    }

    foreach ($arrIns as $i => $sql) {
      $query = $mySQL->query($sql);
      if ($query['success']) {
        $return['success'] = true;
      } else {
        $return['success'] = false;
        $return['error'] = 'Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
        //$return['error'] = $query['error'];
      }
    }
    return $return;
  }

  public function getNombreAfianzado($nombreAfianzado, $tipo_documento) {
    $return = '';
    if ($tipo_documento != 2) {
      $posiciones = explode(" ", $nombreAfianzado);
      $return = $posiciones[0];
    } else {
      $return = $nombreAfianzado;
    }
    return $return;
  }

  public function listarAmparos() {
    global $mySQL;
    $return = array();
    $poliza_id = $this->getPolizaId();
    $sql = "SELECT amparo.amparo_nombre, poliza_amparo.fec_inicio, poliza_amparo.fec_final, poliza_amparo.valor_asegurado, poliza_amparo.valor_liqui, tipo_amparo.tipo_amparo_nombre, tipo_liqui.amparo_liqui_nombre, amparo.garantia_id, poliza_amparo.poliza_amparo_id
            FROM poliza_amparo
            INNER JOIN amparo USING(amparo_id)
            INNER JOIN tipo_amparo ON (amparo.tipo_amparo_id = tipo_amparo.tipo_amparo_id)
            INNER JOIN poliza ON (poliza_amparo.poliza_id = poliza.poliza_id)
            INNER JOIN tipo_liqui ON (tipo_liqui.tipo_liqui_id = poliza_amparo.tipo_liqui_id)
            WHERE poliza.poliza_id = $poliza_id AND poliza_amparo.poliza_amparo_activo = 'S'
            ORDER BY poliza_amparo_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $content = array();
      if ($mySQL->num_rows($query['result']) > 0) {
        while ($row = $mySQL->fetch_assoc($query['result'])) {
          $content[] = $row;
        }
      }
      $return['success'] = true;
      $return['content'] = $content;
    } else {
      $return['success'] = false;
      $return['error'] = "Error tratando de listar los amparos, por favor intente nuevamente refrescando la pantalla";
    }
    return $return;
  }

  public function codificarArreglo($array, $keys) {
    $return = array();
    foreach ($keys as $value) {
      $return[$value] = $array[$value];
    }
    $tools = new Tools();
    $key = $tools->encodeRestArray($return);
    return $key;
  }

  public function crearKeyPoliza($row) {
    return $this->codificarArreglo($row, array("poliza_id", "ref_contrato", "fec_registro"));
  }

  public function enviarCorreoUsuario($correo, $nombre, $password) {
    global $mySQL;
    $return = array();
    $config_vars = $mySQL->getConfigVars();

    $tools = new Tools();

    $params['P_AFIANZADO'] = $nombre;
    $params['P_USUARIO'] = $correo;
    $params['P_PASSWORD'] = $password;
    $params['P_URL'] = $config_vars['server.url'] . 'login';

    $template = $tools->loadTemplate("nuevo_usuario.php", $params);
    if ($template['success']) {
      $message = $template['content'];
      $footer = $tools->loadTemplate("footer.html", $params);
      $message .= $footer['content'];
      $subject = "SEPOL - Creacion de usuario";
      $return = $tools->sendEmail($subject, $message, NULL, NULL, NULL, $correo, NULL, NULL, NULL);
    } else {
      $return['success'] = false;
      $return['error'] = "No se ha podido cargar la información del correo";
    }

    return $return;
  }

  public function enviarCorreoPolizaCreada($nombres, $identificacion, $digit_ver, $municipio_id, $direccion, $telefono, $email, $ref_contrato) {
    global $mySQL;
    $return = array();
    $config_vars = $mySQL->getConfigVars();
    $tools = new Tools();

    $sql = "SELECT CONCAT(municipio.municipio_nombre,' - ', departamento.departamento_nombre) municipio
            FROM municipio 
            INNER JOIN departamento USING (departamento_id)
            WHERE municipio.municipio_id = $municipio_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $municipio = $mySQL->fetch_assoc($query['result']);
      }
    }

    $params['P_USUARIO'] = $nombres;
    $params['P_NUM_IDEN'] = $identificacion;
    $params['P_DIG_VER'] = $digit_ver;
    $params['P_DIR_RES'] = $direccion;
    $params['P_CIU_RES'] = $municipio['municipio'];
    $params['P_TEL'] = $telefono;
    $params['P_EMAIL'] = $email;
    $params['P_REF_CON'] = $ref_contrato;

    $template = $tools->loadTemplate("nueva_poliza.php", $params);
    if ($template['success']) {
      $message = $template['content'];
      $footer = $tools->loadTemplate("footer.html", $params);
      $message .= $footer['content'];
      $subject = "SEPOL - Nueva póliza en curso";
      $return = $tools->sendEmail($subject, $message, NULL, NULL, NULL, $config_vars['mail.reply'], NULL, NULL, NULL);
    } else {
      $return['success'] = false;
      $return['error'] = "No se ha podido cargar la información del correo";
    }

    return $return;
  }

  public function listarPolizasTramite() {
    global $mySQL;
    $return = array();
    $records = 0;
    $sql = "SELECT poliza.*, poliza_estado.poliza_estado_nombre, DATE_FORMAT(poliza.fec_estado,'%Y-%m-%d %H:%i') fec_estado_f, CONCAT(municipio.municipio_nombre,' - ',departamento.departamento_nombre) municipio
              FROM poliza
              INNER JOIN poliza_estado USING (poliza_estado_id)
              LEFT JOIN municipio USING (municipio_id)
              LEFT JOIN departamento ON (departamento.departamento_id = municipio.departamento_id)
              WHERE poliza.poliza_estado_id IN (1,5,6,2) ORDER BY poliza_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $tramite = '
  <table align= "center" width="80%" class="tablesorter">
    <thead>
      <tr>
        <th>Municipio</th>
        <th>Afianzado</th>
        <th>Ref Contrato</th>
        <th>Email</th>
        <th>Estado</th>
        <th>Ultima Actualización</th>
        <th>&nbsp;</th>
      </tr>
    </thead>
    <tbody>';
        while ($fila = $mySQL->fetch_assoc($query['result'])) {
          $tramite .= '
      <tr>
        <td>' . $fila["municipio"] . '</td>
        <td>' . $fila["nombres"] . '</td>
        <td>' . $fila["ref_contrato"] . '</td>
        <td>' . $fila["email"] . '</td>
        <td>' . $fila["poliza_estado_nombre"] . '</td>
        <td>' . $fila["fec_estado_f"] . '</td>
        <td align= "center"><a href="poliza_form?poliza_id=' . $fila["poliza_id"] . '" target="_self"><img src="images/b_log.png" width="30px"></a></td>
      </tr>';
          $records++;
        }
        $tramite .= '
    </tbody>
  </table>';
        $return['tramite'] = $tramite;
      } else {
        $return['tramite'] = "No existen pólizas en trámite";
      }
      $sql = "SELECT poliza.*, poliza_estado.poliza_estado_nombre, UNIX_TIMESTAMP(now()) - UNIX_TIMESTAMP(poliza.fec_registro) as segundos, DATE_FORMAT(poliza.fec_estado,'%Y-%m-%d %H:%i') fec_estado_f
              FROM poliza
              LEFT JOIN poliza_estado USING (poliza_estado_id)
              WHERE poliza.poliza_estado_id = 10 HAVING segundos > 900";
      $query = $mySQL->query($sql);
      if ($query['success']) {
        if ($mySQL->num_rows($query['result']) > 0) {
          $noDoc = '
  <table align= "center" width="80%" class="tablesorter">
    <thead>
      <tr>
        <th>Afianzado</th>
        <th>Email</th>
        <th>Teléfono</th>
        <th>Ref Contrato</th>
        <th>Estado</th>
        <th>Ultima Actualización</th>
        <th>&nbsp;</th>
      </tr>
    </thead>
    <tbody>';
          while ($fila = $mySQL->fetch_assoc($query['result'])) {
            $noDoc .= '
            <tr>
              <td>' . $fila["nombres"] . '</td>
              <td>' . $fila["email"] . '</td>
              <td>' . $fila["telefono"] . '</td>
              <td>' . $fila["ref_contrato"] . '</td>
              <td>' . $fila["poliza_estado_nombre"] . '</td>
              <td>' . $fila["fec_estado_f"] . '</td>
              <td align= "center"><a href="poliza_form?poliza_id=' . $fila["poliza_id"] . '" target="_self"><img src="images/b_log.png" width="30px"></a></td>
            </tr>';
            $records++;
          }
          $noDoc .= '
    </tbody>
  </table>';
          $return['noDoc'] = $noDoc;
        } else {
          $return['noDoc'] = "No existen pólizas con falta de documentos";
        }
        $return['success'] = true;
        $return['records'] = $records;
      } else {
        $return['success'] = false;
        $return['error'] = "Error al tratar de lsitar los doumentos con falta de documentos,  Por favor intente nuevamente";
      }
    } else {
      $return['success'] = false;
      $return['error'] = "Error al buscar las pólizas en trámite.  Por favor intente nuevamente";
    }
    return $return;
  }

}
