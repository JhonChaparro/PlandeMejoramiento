<?php

include_once dirname(__FILE__) . '/../general/Tools.php';

class Referidos {

  public function validarCodigoReferidor() {
    global $mySQL;
    $return = array();
    $cod_referidor = $_POST['cod_referidor'];

    $sql = "SELECT * FROM usuario WHERE cod_referidor = '$cod_referidor'";
    $resulta = $mySQL->query($sql);
    if ($resulta['success']) {
      if ($mySQL->num_rows($resulta['result']) > 0) {

        $return['success'] = true;
      } else {
        $return['success'] = false;
        $return['error'] = "Este código de referidor no existe";
      }
    } else {
      $return['success'] = false;
      $return['error'] = "Hubo un error al consultar los datos, por favor intente nuevamente";
    }


    return $return;
  }

  public function iniciarSesionReferidor() {
    global $mySQL;
    $return = array();
    $config_vars = $mySQL->getConfigVars();
    $usuario_email = $_POST['usuario_email'];
    $usuario_passwd = $_POST['usuario_passwd'];
    $tools = new Tools();

    $sql = "SELECT * FROM usuario WHERE usuario_email = '$usuario_email' AND usuario_passwd= '" . md5($usuario_passwd) . "' AND rol_id= 2";
    $resulta = $mySQL->query($sql);
    if ($resulta['success']) {
      if ($mySQL->num_rows($resulta['result']) > 0) {
        while ($referidor = $mySQL->fetch_assoc($resulta['result'])) {
          $return['success'] = true;
          $_SESSION['usuario_referidor'] = $referidor;
        }
      } else {
        $return['success'] = false;
        $return['error'] = "Usuario y/o Contraseña Incorrectos";
      }
    }
    return $return;
  }

  public function crearReferidor() {
    global $mySQL;
    $return = array();
    $config_vars = $mySQL->getConfigVars();
    $nombres = $_POST["nombres"];
    $apellidos = $_POST["apellidos"];
    $identificacion = $_POST["identificacion"];
    $digit_ver = $_POST["digit_ver"];
    $tipo_documento_id = $_POST["tipo_documento_id"];
    $municipio_id = $_POST["municipio_id"];
    $telefono = $_POST["telefono"];
    $email = $_POST["email"];
    $clave = $_POST["clave"];
    $tools = new Tools();

    $sql = "SELECT * FROM usuario WHERE usuario_email = '$email' AND tipo_usuario = 'R'";
    $resulta = $mySQL->query($sql);
    if ($resulta['success']) {
      if ($mySQL->num_rows($resulta['result']) > 0) {
        $return['success'] = false;
        $return['error'] = "Ya existe un usuario con correo electrónico $email.  Por favor utilice uno diferente.";
      } else {
        $x = false;
        $codigo_referidor = "";
        while ($x == false) {
          $codigo_referidor = $tools->getRandowCode(6);

          $sql = "SELECT * FROM usuario WHERE cod_referidor = '$codigo_referidor'";
          $resultad = $mySQL->query($sql);
          if ($resultad['success']) {
            if ($mySQL->num_rows($resultad['result']) > 0) {
              $x = false;
            } else {
              $x = true;
            }
          }
        }
        if ($x) {
          $sql = "INSERT INTO usuario (rol_id, usuario_log, usuario_nombre, usuario_cargo, usuario_email, usuario_passwd, usuario_activo, usuario_fec_login, usuario_host_login, cod_referidor, tipo_usuario, req_cc, usuario_apel, tipo_documento_id, identificacion, dig_ver, lug_res_id, usuario_tel)
                  VALUES (2, 1, '$nombres', NULL, '$email', MD5('$clave'), 'S', NULL, NULL, '$codigo_referidor', 'R', 'N', '$apellidos', $tipo_documento_id, '$identificacion', $digit_ver, $municipio_id, '$telefono');";
          $result = $mySQL->query($sql);
          if ($result['success']) {
            $to = $email;
            $FROM = $_POST['FROM'];
            $subject = "Confirmación de Registro";
            $cc = $FROM;
            $tools = new Tools();
            $params['P_REFERIDO'] = $this->getNombreReferido($nombres, $tipo_documento_id);
            $params['P_EMAIL'] = $email;
            $params['COD_REFERIDOR'] = $codigo_referidor;
            $params['P_ENLACE'] = $config_vars["server.www_url"] . $codigo_referidor;
            $params['COMI_REFERIDOS'] = $config_vars["comi.referido"];
            $params['EMAIL_REPLY'] = $config_vars["mail.reply"];

            $referencia['nombres_referidor'] = $this->getNombreReferido($nombres, $tipo_documento_id);
            $referencia['email_referidor'] = $email;
            $referencia['codigo_referidor'] = $codigo_referidor;
            $attachments['Condiciones_referidos.pdf'] = "../public/cond_prov_1.pdf";
            
            $embeddedImages['megafono'] = '/../sepol/images/referidos/megafono.png';
            $embeddedImages['dinero'] = '/../sepol/images/referidos/dinero.png';

            $template = $tools->loadTemplate('nuevo_usu_ref.php', $params);
            if ($template['success']) {
              $message = $template['content'];
              $footer = $tools->loadTemplate("footer.html", $params);
              $message .= $footer['content'];
              $return = $tools->sendEmail($subject, $message, NULL, $config_vars['mail.reply'], NULL, $to, $cc, NULL, $attachments, NULL, $embeddedImages);
              $return['ref'] = $this->crearKeyReferidor($referencia);
            } else {
              $return['success'] = false;
              $return['error'] = "No se ha podido cargar la información del correo";
            }
          } else {
            $return['success'] = false;
            $return['error'] = "Error tratando de crear su usuario, por favor intente nuevamente";
          }
        }
      }

      return $return;
    }
  }

  public function crearKeyReferidor($array) {
    global $mySQL;
    $configVars = $mySQL->getConfigVars();
    $json = json_encode($array, JSON_UNESCAPED_UNICODE);

    return strrev(base64_encode($json));
  }

  public function reversarKeyReferidor($string) {
    global $mySQL;
    $configVars = $mySQL->getConfigVars();
    $string = urldecode($string);

    return json_decode(base64_decode(strrev($string)));
  }

  public function solicitarPago() {
    global $mySQL;
    $return = array();
    $config_vars = $mySQL->getConfigVars();
    $usuario_referidor = $_SESSION['usuario_referidor']['usuario_email'];
    $banco_nombre = $_POST["banco_nombre"];
    $banco_cuenta = $_POST["banco_cuenta"];
    $tipo_cuenta = $_POST["tipo_cuenta"];
    $clave = $_POST["clave"];
    $polizas = $_POST['polizas'];
    $time = time();
    $fecha = date("Y-m-d H:i:s", $time);

    $sql = "SELECT * FROM usuario WHERE usuario_email = '$usuario_referidor' AND usuario_passwd= '" . md5($clave) . "' AND rol_id= 2";
    $resulta = $mySQL->query($sql);
    if ($resulta['success']) {
      if ($mySQL->num_rows($resulta['result']) > 0) {
        while ($referidor = $mySQL->fetch_assoc($resulta['result'])) {
          $sql = "INSERT INTO refe_pago (referidor_id, banco_nombre, tipo_cuenta, banco_cuenta, fec_solicitud) "
                  . "VALUES (" . $_SESSION['usuario_referidor']['usuario_id'] . ", '$banco_nombre', '$tipo_cuenta', '$banco_cuenta', '$fecha')";
          $result = $mySQL->query($sql);
          if ($result['success']) {
            foreach ($polizas as $pol) {
              $sql = "UPDATE poliza SET referido_estado_id=3, refe_pago_id =(SELECT MAX(refe_pago_id) FROM refe_pago WHERE referidor_id=" . $_SESSION['usuario_referidor']['usuario_id'] . ") WHERE poliza_id= $pol";
              $resultad = $mySQL->query($sql);
              if (!$resultad['success']) {
                $return['success'] = false;
                $return['error'] = "Ocurrió un error al momento de actualizar la información de la poliza, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.";
                return $return;
              }
            }

            $to = $config_vars['mail.reply'];
            // $FROM = $config_vars['mail.reply'];
            $subject = "Nueva solicitud de pago";
            // $cc = $FROM;
            $tools = new Tools();

            $sql = "SELECT poliza.*, poliza_estado.poliza_estado_nombre, CONCAT(municipio.municipio_nombre,' - ',departamento.departamento_nombre) municipio
                    FROM poliza
                    INNER JOIN poliza_estado USING (poliza_estado_id)
                    LEFT JOIN municipio USING (municipio_id)
                    LEFT JOIN departamento ON (departamento.departamento_id = municipio.departamento_id)
                    INNER JOIN usuario ON (poliza.referidor_id = usuario.usuario_id)
                    WHERE poliza.referido_estado_id = 3 AND usuario.usuario_id = " . $_SESSION['usuario_referidor']['usuario_id'];
            $res = $mySQL->query($sql);
            if ($res['success']) {
              $contad = 0;
              $contenido = '';
              if ($mySQL->num_rows($res['result']) > 0) {
                while ($poliza = $mySQL->fetch_assoc($res['result'])) {
                  $contenido.="<tr><td>$poliza[ref_contrato]</td>"
                          . "<td>$poliza[nombres]" . " " . $poliza[apellidos] . "</td>"
                          . "<td>$poliza[email]</td>"
                          . "<td>$poliza[municipio]</td>"
                          . "<td>$poliza[poliza_estado_nombre]</td>"
                          . "<td>$poliza[fec_estado]</td>"
                          . "<td>$&nbsp;$poliza[total_prima]</td>"
                          . "<td style='text-align: right;'>$&nbsp;" . $poliza[comi_refer] . "</td>";
                  $contad = $contad + $poliza[comi_refer];
                }
              }

              $params['P_REFERIDO'] = $referidor['usuario_nombre'];
              $params['P_BANCO_NOMBRE'] = $banco_nombre;
              $params['P_TIPO_CUENTA'] = $tipo_cuenta;
              $params['P_BANCO_NUMERO'] = $banco_cuenta;
              $params['P_EMAIL'] = $referidor['usuario_email'];
              $params['P_CONTENIDO'] = $contenido;
              $params['P_CONTAD'] = $contad;

              $template = $tools->loadTemplate("solicitar_pago_ref.php", $params);
              if ($template['success']) {
                $message = $template['content'];
                $footer = $tools->loadTemplate("footer.html", $params);
                $message .= $footer['content'];
                $return = $tools->sendEmail($subject, $message, NULL, $config_vars['mail.reply'], NULL, $to, $cc, NULL, NULL);
              } else {
                $return['success'] = false;
                $return['error'] = "No se ha podido cargar la información del correo";
              }
            } else {
              $return['success'] = false;
              $return['error'] = "Su solicitud fue recibida pero hubo un problema al enviar el correo";
            }
          }
        }
      } else {
        $return['success'] = false;
        $return['error'] = "Contraseña Incorrecta";
      }
    }
    return $return;
  }

  public function cambiarEstadoReferidos() {
    global $mySQL;
    $return = array();
    $config_vars = $mySQL->getConfigVars();
    $refe_pagos = $_POST["refe_pagos"];

    foreach ($refe_pagos as $refe) {
      $sql = "UPDATE poliza SET referido_estado_id=4, fec_pago_refe=CURDATE() WHERE refe_pago_id= $refe ";
      $resultad = $mySQL->query($sql);
      if ($resultad['success']) {
        $sql = "SELECT usuario.* FROM usuario usuario, refe_pago refe_pago WHERE usuario.usuario_id=refe_pago.referidor_id "
                . "AND refe_pago.refe_pago_id=$refe";

        $resulta = $mySQL->query($sql);
        if ($resulta['success']) {
          while ($referidor = $mySQL->fetch_assoc($resulta['result'])) {
            $to = $referidor['usuario_email'];
            // $FROM = $config_vars['mail.reply'];
            $subject = "Sus solicitudes han sido pagadas";
            // $cc = $FROM;
            $tools = new Tools();

            $params['P_REFERIDO'] = $this->getNombreReferido($referidor['usuario_nombre'], $referidor['tipo_documento_id']);
            $params['P_EMAIL'] = $config_vars['mail.reply'];
            
            $template = $tools->loadTemplate("cambiar_estado_ref.php", $params);
            if ($template['success']) {
              $message = $template['content'];
              $footer = $tools->loadTemplate("footer.html", $params);
              $message .= $footer['content'];
              $return = $tools->sendEmail($subject, $message, NULL, $config_vars['mail.reply'], NULL, $to, $cc, NULL, NULL);
            } else {
              $return['success'] = false;
              $return['error'] = "No se ha podido cargar la información del correo";
            }
          }
        } else {
          $return['success'] = false;
          $return['error'] = 'Ocurrió un error al momento de consultar la información del referidor, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
          //$return['error'] = $query['error'];
        }
      } else {
        $return['success'] = false;
        $return['error'] = 'Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
        //$return['error'] = $query['error'];
      }
    }
    return $return;
  }

  public function filtrarCotizacionesReferidor() {
    global $mySQL;
    $return = array();
    $config_vars = $mySQL->getConfigVars();
    $fechainicial = $_POST["fechainicial"];
    $fechafinal = $_POST["fechafinal"];
    $cont = "";
    if (!empty($fechainicial)) {
      $cont = $cont . " AND poliza.fec_pago_refe >='" . $fechainicial . "'";
    }
    if (!empty($fechafinal)) {
      $cont = $cont . " AND poliza.fec_pago_refe <='" . $fechafinal . "'";
    }
    $sql = "SELECT poliza.*, CONCAT(municipio.municipio_nombre,' - ',departamento.departamento_nombre) municipio
            FROM poliza poliza,usuario usuario, municipio municipio, departamento departamento
            WHERE usuario.usuario_id=poliza.referidor_id AND poliza.municipio_id = municipio.municipio_id AND departamento.departamento_id = municipio.departamento_id AND usuario.usuario_id= " . $_SESSION['usuario_referidor']['usuario_id'] . "
            AND poliza.referido_estado_id=4 AND poliza.comi_refer>0" . $cont . " ORDER BY poliza.fec_pago_refe DESC";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $return['content'] = '  
          <table class="table">
            <thead>
              <tr>
                <th>Ref Contrato</th>
                <th>Afianzado</th>
                <th>Email</th>
                <th>Municipio</th>
                <th>Ultima Actualización</th>
                <th>Valor Prima</th>
                <th>Valor Comisión</th>
              </tr>
            </thead>
            <tbody>';
      $conta = 1;
      $contad = 0;
      if ($mySQL->num_rows($query['result']) > 0) {
        while ($poliza = $mySQL->fetch_assoc($query['result'])) {

          $return['content'] .= "<tr>"
                  . "<td>$poliza[ref_contrato]</td>"
                  . "<td>$poliza[nombres]" . " " . $poliza[apellidos] . "</td>"
                  . "<td>$poliza[email]</td>"
                  . "<td>$poliza[municipio]</td>"
                  . "<td>" . date("Y-m-d H:i", $poliza[fec_estado]) . "</td>"
                  . "<td>$&nbsp;$poliza[total_prima]</td>"
                  . "<td style='text-align: right;'>$&nbsp;" . $poliza[comi_refer] . "</td>";
          $contad = $contad + $poliza[comi_refer];
        }
        $return['content'] .='' .
                '</tbody><tfoot><tr><td colspan="6" style="text-align:right;">Total Comisiones pagadas:' .
                '</td><td style="text-align:right;">&nbsp;' . number_format($contad, 2) . '</td></tr></tfoot> </table>';
      } else {
        $return['content'] .='<tr><td colspan="7" style="text-align:center;">No hay comisiones pagadas en estos rangos de fechas</td></tr> ' .
                '</tbody><tfoot><tr><td colspan="6" style="text-align:right;">Total Comisiones pagadas:' .
                '</td><td style="text-align:right;">$&nbsp;' . number_format($contad, 2) . '</td></tr></tfoot> </table>';
      }
    } else {
      $return['content'] = '  
  <table class="table">
            <thead>
              <tr>
                <th>Ref Contrato</th>
                <th>Afianzado</th>
                <th>Email</th>
                <th>Municipio</th>
                <th>Ultima Actualización</th>
                <th>Valor Prima</th>
                <th>Valor Comisión</th>
              </tr>
            </thead>
            <tbody>';
      $return['content'] .='<tr><td colspan="7" style="text-align:center;">Hubo un error en la consulta por favor intenta nuevamente</td></tr> ' .
              '</tbody><tfoot><tr><td colspan="6" style="text-align:right;">Total Comisiones pagadas:' .
              '</td><td style="text-align:right;">$&nbsp;' . number_format($contad, 2) . '</td></tr></tfoot> </table>';
    }
    $return['success'] = true;
    return $return;
  }

  public function filtrarPagosRealizados() {
    global $mySQL;
    $return = array();
    $config_vars = $mySQL->getConfigVars();
    $fechainicial = $_POST["fechainicial"];
    $fechafinal = $_POST["fechafinal"];
    $usuario_id = $_POST["usuario_id"];
    $banco_nombre = $_POST["banco_nombre"];
    $cont = "";
    if (!empty($banco_nombre)) {
      $cont = $cont . " AND refe_pago.banco_nombre LIKE '%$banco_nombre%'";
    }
    if (!empty($usuario_id)) {
      $cont = $cont . " AND usuario.usuario_id ='" . $usuario_id . "'";
    }
    if (!empty($fechainicial) && !empty($fechafinal)) {
      $cont = $cont . " HAVING fecha_pago >='" . $fechainicial . "' AND fecha_pago <='" . $fechafinal . "'";
    } else {
      if (!empty($fechainicial) && empty($fechafinal)) {
        $cont = $cont . " HAVING fecha_pago >='" . $fechainicial . "'";
      }
      if (!empty($fechafinal) && empty($fechainicial)) {
        $cont = $cont . " HAVING fecha_pago <='" . $fechafinal . "'";
      }
    }

    $sql = "SELECT refe_pago.refe_pago_id,refe_pago.fec_solicitud,usuario.usuario_nombre, refe_pago.banco_nombre,refe_pago.banco_cuenta,refe_pago.referidor_id,
            (SELECT SUM(poliza.comi_refer) FROM poliza poliza WHERE poliza.refe_pago_id=refe_pago.refe_pago_id AND poliza.referido_estado_id=4) AS 'total',
            (SELECT MAX(poliza.fec_pago_refe) FROM poliza poliza WHERE poliza.refe_pago_id=refe_pago.refe_pago_id AND poliza.referido_estado_id=4) AS 'fecha_pago' 
            FROM refe_pago refe_pago, usuario usuario 
            WHERE usuario.usuario_id=refe_pago.referidor_id AND (SELECT SUM(poliza.comi_refer) 
            FROM poliza poliza WHERE poliza.refe_pago_id=refe_pago.refe_pago_id AND poliza.referido_estado_id=4)>0 " . $cont . " ORDER BY refe_pago.fec_solicitud";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $return['content'] = '  
<table class="table">
  <thead>
    <tr>
      <th>Fecha&nbsp;de&nbsp;Solicitud</th>
      <th>Fecha&nbsp;de&nbsp;pago</th>
      <th >Solicitante</th>
      <th >&nbsp;Banco&nbsp;</th>
      <th>Número&nbsp;de&nbsp;Cuenta</th>
      <th style="text-align:right;">&nbsp;Total&nbsp;</th>
    </tr>
  </thead>
  <tbody>';
      $conta = 1;
      $contad = 0;
      if ($mySQL->num_rows($query['result']) > 0) {
        while ($refe_pago = $mySQL->fetch_assoc($query['result'])) {

          $return['content'] .= "<tr><td>" . date("Y-m-d H:i", $refe_pago[fec_solicitud]) . "</td>"
                  . "<td>$refe_pago[fecha_pago]</td>"
                  . "<td>$refe_pago[usuario_nombre]</td>"
                  . "<td>$refe_pago[banco_nombre]</td>"
                  . "<td>$refe_pago[banco_cuenta]</td>"
                  . "<td style='text-align:right;'>&nbsp;$refe_pago[total]</td></tr>";
          $contad = $contad + $refe_pago[total];
        }
        $return['content'] .='
  </tbody>
    <tfoot>
      <tr>
        <td colspan="5" style="text-align:right;">Total Comisiones pagadas:</td>
        <td style="text-align:right;">$&nbsp;' . number_format($contad, 2) . '</td>
      </tr>
    </tfoot> 
</table>';
      } else {
        $return['content'] .='
          <tr>
            <td colspan="8" style="text-align:center;">No hay pagos realizados con las características seleccionadas</td>
          </tr> 
        </tbody>
      </table>';
      }
    } else {
      $return['content'] = '  
  <table class="table">
    <thead>
      <tr>
        <th>Fecha&nbsp;de&nbsp;Solicitud</th>
        <th>Fecha&nbsp;de&nbsp;pago</th>
        <th>Solicitante</th>
        <th>&nbsp;Banco&nbsp;</th>
        <th>Número&nbsp;de&nbsp;Cuenta</th>
        <th style="text-align:right;">&nbsp;Total&nbsp;</th>
      </tr>
      <tr>
        <td colspan="8">Hubo un error en la consulta por favor intenta nuevamente</td>
      </tr>
    </tbody> 
  </table>';
    }
    $return['success'] = true;
    return $return;
  }

  function buscarReferidores() {
    global $mySQL;
    $term = $_REQUEST['term'];
    $return = array();
    $sql = "SELECT usuario.* FROM usuario WHERE rol_id=2";

    if (!empty($term)) {
      $sql .= " AND usuario_nombre LIKE '%$term%'";
    }
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        while ($row = $mySQL->fetch_assoc($query['result'])) {
          $a_json_row["id"] = $row['usuario_id'];
          $a_json_row["value"] = $row['usuario_nombre'];
          $a_json_row["label"] = $row['usuario_nombre'];
          array_push($return, $a_json_row);
        }
      }
    }
    return $return;
  }

  public function actualizarDatosReferidor() {
    global $mySQL;
    $return = array();
    $config_vars = $mySQL->getConfigVars();
    $usuario_nombre = $_POST['usuario_nombre'];
    $usuario_email = $_POST['usuario_email'];
    $usuario_passwd = $_POST['usuario_passwd'];
    $nueva_clave = $_POST['nueva_clave'];
    $conf_nueva_clave = $_POST['conf_nueva_clave'];
    $complemento;
    if (!empty($nueva_clave) && !empty($conf_nueva_clave)) {
      $complemento = ", usuario_passwd='" . md5($nueva_clave) . "'";
    }
    $tools = new Tools();
    $sql = "SELECT * FROM usuario WHERE usuario_login = '" . $_SESSION['usuario_referidor']['usuario_login'] . "' AND usuario_passwd= '" . md5($usuario_passwd) . "' AND rol_id= 6";
    $resulta = $mySQL->query($sql);
    if ($resulta['success']) {
      if ($mySQL->num_rows($resulta['result']) > 0) {
        $sql = "UPDATE usuario set usuario_nombre='$usuario_nombre'"
                . ", usuario_email='$usuario_email'" . $complemento .
                " WHERE usuario_login='" . $_SESSION['usuario_referidor']['usuario_login'] . "' AND "
                . " usuario_id=" . $_SESSION['usuario_referidor']['usuario_id'];
        $resultad = $mySQL->query($sql);
        if ($resultad['success']) {
          $return['success'] = true;
        }
      } else {
        $return['success'] = false;
        $return['error'] = "La contraseña ingresada es incorrecta ";
      }
    }
    return $return;
  }

  public function recuperarContraseñaReferidor() {
    global $mySQL;
    $return = array();
    $config_vars = $mySQL->getConfigVars();
    $usuario_login = $_POST['usuario_login'];
    $tools = new Tools();
    $sql = "SELECT * FROM usuario WHERE usuario_login = '$usuario_login' AND rol_id= 6";
    $resulta = $mySQL->query($sql);
    if ($resulta['success']) {
      if ($mySQL->num_rows($resulta['result']) > 0) {
        while ($referidor = $mySQL->fetch_assoc($resulta['result'])) {
          $nueva_contraseña = $tools->getRandowPassword(6);
          $sql = "UPDATE usuario set usuario_passwd = '" . md5($nueva_contraseña) . "' WHERE usuario_login = '$usuario_login' AND rol_id= 6";
          $resultas = $mySQL->query($sql);
          if ($resultas['success']) {
            $to = $referidor['usuario_email'];
            $subject = "Recuperación de Contraseña";


            $message = '<div style="width:100%;font-family: "Open Sans",arial,helvetica,sans-serif;"><br> Hola,'
                    . ' ' . explode(' ', $referidor['usuario_nombre'])[0] . '<br><br>Se ha solicitado una nueva contraseña, por favor inicia sesión '
                    . 'con esta nueva contraseña: <br><br><label style="font-weight:bold;">' . $nueva_contraseña . '</label><br><br>Si no has solicitado el cambio por favor ingresa lo más rápido posible y actualiza tu contraseña ' .
                    '<br><br><label style="font-weight:bold;">¿Tiene alguna pregunta? </label><br><br>
Si tienes algun problema para recuerperar tu contraseña por favor escribenos a este correo: <label style="font-weight:bold;"> ' . $config_vars["mail.reply"] . '</label> ';
            $params['P_LOGO'] = $config_vars['mail.logo'];
            $params['P_SERVER_URL'] = $config_vars['server.www_url'];
            $params['P_DOMAIN_NAME'] = $config_vars['domain.name'];
            $footer = $tools->loadTemplate("footer.html", $params);
            $message .= $footer['content'];
            $return = $tools->sendEmail($subject, $message, NULL, $config_vars['mail.reply'], NULL, $to, $cc, NULL, NULL);
            $return['success'] = true;
          }
        }
      } else {
        $return['success'] = false;
        $return['error'] = "El usuario que ingresaste no esta registrado en nuestro sistema ";
      }
    } else {
      $return['success'] = false;
      $return['error'] = "El usuario que ingresaste no esta registrado en nuestro sistema ";
    }


    return $return;
  }

  public function getNombreReferido($nombreReferido, $tipo_documento) {
    $return = '';
    if ($tipo_documento == 2) {
      $posiciones = explode(" ", $nombreReferido);
      $return = $posiciones[0];
    } else {
      $return = $nombreReferido;
    }
    return $return;
  }

}
