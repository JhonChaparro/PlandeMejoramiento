<?php

require_once dirname(__FILE__) . '/../general/Tools.php';

class Usuarios {

  public function actualizarUsuario() {
    global $mySQL;
    $return = array();
    $usuario_id = $_POST["usuario_id"];
    $nombres = $_POST["nombres"];
    $apellidos = $_POST["apellidos"];
    $identificacion = $_POST["identificacion"];
    $digit_ver = $_POST["digit_ver"];
    $tipo_documento_id = $_POST["tipo_documento_id"];
    $municipio_id = $_POST["municipio_id"];
    $telefono = $_POST["telefono"];
    $email = $_POST["email"];
    $clave = $_POST["clave"];
    $usuario_log = $_SESSION['preguntas_admin_user']['usuario_id'];

    $sql = "UPDATE usuario SET usuario_nombre = '$nombres', usuario_email = '$email', usuario_apel = '$apellidos', tipo_documento_id = $tipo_documento_id, "
            . "identificacion = $identificacion, dig_ver = $digit_ver, lug_res_id = $municipio_id, usuario_tel = $telefono, usuario_log = $usuario_log ";
    if (isset($clave) && !empty($clave)) {
      $sql .= ", usuario_passwd = MD5('$clave')";
    }
    $sql .= " WHERE usuario_id = $usuario_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $return['success'] = true;
    } else {
      $return['success'] = false;
      $return['error'] = "Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente.";
    }
    return $return;
  }

  public function cambiarActivo() {
    global $mySQL;
    $return = array();
    $usuario_id = $_POST['usuario_id'];
    $valor = $_POST['valor'];
    $sql = "UPDATE usuarios SET estado = '$valor'  WHERE identificacion = $usuario_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      $return['success'] = true;
    } else {
      $return['success'] = false;
      $return['error'] = 'Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
    }
    return $return;
  }

  public function buscarUsuario() {
    global $mySQL;
    $return = array();
    $usuario_id = $_POST['usuario_id'];
    $sql = "SELECT *
            FROM usuarios 
            WHERE identificacion = $usuario_id";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $return = $mySQL->fetch_assoc($query['result']);
        $return['password'] = "";
        $return['success'] = true;
      } else {
        $return['success'] = false;
        $return['error'] = "Usuario no encontrado";
      }
    } else {
      $return['success'] = false;
      $return['error'] = 'Ocurrió un error al momento de consultar la información del usuario, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
      //$return['error'] = $query['error'];
    }
    return $return;
  }

  public function listarUsuarios() {
    global $mySQL;
    $filtro = $_POST['filtro'];

    $return = "";
    $sql = "SELECT usuarios.*, rol_nombre,elt(field(usuarios.estado, 'A','I'), 'ACTIVO', 'INACTIVO') AS usuario_activo 
          FROM usuarios 
          INNER JOIN roles USING (rol_id)";
    $query = $mySQL->query($sql);
    if ($query['success']) {
      if ($mySQL->num_rows($query['result']) > 0) {
        $return = '
  <table style="width: 60%" id="tablaUsuarios" class="tablesorter">
    <thead>
      <tr style="text-align:center;">
        <th>
          Nombre
        </th>
        <th>
          Email
        </th>
         <th>
          Rol
        </th>
        <th>
          Activo
        </th>
        <th>
          &nbsp;
        </th>
      </tr>
    </thead>
    <tbody>';
        while ($row = $mySQL->fetch_assoc($query['result'])) {
          $trRow = "
        <tr>
          <td>$row[nombres] $row[apellidos]</td>
          <td>$row[email]</td>
          <td>$row[rol_nombre]</td>
          <td style='text-align:center;'>$row[usuario_activo]</td>
          <td style='text-align:center;'>
            <a href='javascript:editarUsuario(\"editar\", $row[identificacion]);'><img src='images/b_edit.png'/></a>";
          if ($row['usuario_activo'] == 'ACTIVO') {
            $trRow .= "<a href='javascript:cambiarActivoUsuario($row[identificacion], \"I\");'><img src='images/turn_off.png'/></a>";
          } else {
            $trRow .= "<a href='javascript:cambiarActivoUsuario($row[identificacion], \"A\");'><img src='images/turn_on.png'/></a>";
          }
          $trRow .= "
          </td>
        </tr>";
          if (is_null($filtro) || empty($filtro) || strpos(strtolower($trRow), strtolower($filtro)) > 0) {
            $return .= $trRow;
          }
        }
        $return .= '
      </tbody>
  </table>';
      } else {
        $return = 'No existen usuarios en el sistema';
      }
    } else {
      $return = 'Se ha generado el siguiente error: ' . $query['error'];
    }
    return $return;
  }

  public function guardarUsuario() {
    global $mySQL;
    $return = array();
    $tipo = $_POST['tipo'];
    $usuario_id = $_POST['usuario_id'];
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    $identificacion = $_POST['identificacion'];
    $email = $_POST['email'];
    $rol_id = $_POST['rol_id'];
    $area_id = $_POST['area_id'];
    $clave = $_POST['clave'];

//    die;
    if ($tipo == "nuevo") {
      $sql = "SELECT * FROM usuarios WHERE email = '$email'";
      $query = $mySQL->query($sql);
      if ($query['success']) {
        if ($mySQL->num_rows($query['result']) > 0) {
          $return['success'] = false;
          $return['error'] = "Ya existe un usuario con correo electrónico $email.  Por favor utilice uno diferente.";
        } else {
          $sql = "INSERT INTO usuarios (identificacion, nombres, apellidos, email, password, estado, rol_id, area_id)
                  VALUES ($identificacion, '$nombres', '$apellidos', '$email', MD5('$clave'), 'A', $rol_id, $area_id)";
          $query = $mySQL->query($sql);
          $usuario_id = $mySQL->insert_id();
          if ($query['success']) {
            $return['success'] = true;
          } else {
            $return['success'] = false;
            $return['error'] = 'Ocurrió un error al momento de guardar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
            //$return['error'] = $query['error'];
          }
        }
      } else {
        $return['success'] = false;
        $return['error'] = 'Ocurrió un error al momento de consultar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
        //$return['error'] = $query['error'];
      }
    } else {
      $sql = "SELECT * FROM usuario WHERE usuario_email = '$email' AND usuario_id <> $usuario_id";
      $query = $mySQL->query($sql);
      if ($query['success']) {
        if ($mySQL->num_rows($query['result']) > 0) {
          $return['success'] = false;
          $return['error'] = "Ya existe un usuario con correo electrónico $email.  Por favor utilice uno diferente.";
        } else {
          $sql = "UPDATE usuarios SET nombres = '$nombres', apellidos = '$apellidos',
                  email = '$email', rol_id = $rol_id, area_id = $area_id";
          if (isset($clave) && !empty($clave)) {
            $sql .= ", password = MD5('$clave')";
          }
          $sql .= " WHERE identificacion = $usuario_id";
          $query = $mySQL->query($sql);
          if ($query['success']) {
            $return['success'] = true;
          } else {
            $return['success'] = false;
            $return['error'] = 'Ocurrió un error al momento de actualizar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
            //$return['error'] = $query['error'];
          }
        }
      } else {
        $return['success'] = false;
        $return['error'] = 'Ocurrió un error al momento de consultar la información, por favor inténtelo nuevamente. Si el error persiste consulte con el administrador del sistema.';
        //$return['error'] = $query['error'];
      }
    }
    return $return;
  }
}
