DELETE FROM  poliza;
DELETE FROM  poliza_amparo;
DELETE FROM  poliza_asegurado;
DELETE FROM  poliza_aseguradora;
DELETE FROM  poliza_bitac;
DELETE FROM  poliza_docum;
DELETE FROM  refe_pago;
ALTER TABLE poliza AUTO_INCREMENT=10000;
