GRANT ALL PRIVILEGES ON preguntas.* TO 'preguntas'@'localhost' IDENTIFIED BY '%Judkjhf384324u$@' WITH GRANT OPTION;
