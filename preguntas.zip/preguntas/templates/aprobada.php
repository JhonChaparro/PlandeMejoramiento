<span style="font-family: Verdana, Arial, Helvetica, sans-serif;">
  <br/>
  <br/>
  <br/>

  Hola P_AFIANZADO:
  <br/>
  <br/>
  Su solicitud para el contrato con referencia P_REFERENCIA ha sido APROBADA, haciendo clic <a href="P_ENLACE">aquí</a>
  podrá revisar las aseguradoras que ponemos a su disposición con sus valores y puede continuar con el proceso de pago.  Recuerde que puede pagar con débito a su cuenta de ahorros, con cargo a su tarjeta de crédito, en
  efectivo en cualquier punto Efecty a nivel nacional o en los puntos de chance PagaTodo.
  <br/>
  <br/>
  Si tiene algun inconveniente no dude en comunicarse,
  <br/>
  <br/>

</span>