<div style="width:100%;font-family: Open Sans,arial,helvetica,sans-serif;">
  <label>
    <br> Hola, P_REFERIDO sus solicitudes de comisión por referidos han sido pagadas 
  </label>
  <br>
  <br>
  Por favor, revise que la transacción haya sido correcta.
  <br>
  <br>
  En caso de algún error relacionado con esta solicitud, por favor, envíenos
  un correo a P_EMAIL y atenderemos con gusto sus inquietudes.
  <br>
  <br>
  Gracias
  <br>
  <br>
</div>