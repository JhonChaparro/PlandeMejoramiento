<span style="font-family: Verdana, Arial, Helvetica, sans-serif;">
  <br/>
  <br/>
  <br/>
  Hola P_AFIANZADO:
  <br/>
  <br/>
  Adjunto encontrará la póliza derivada del contrato con referencia No P_REFERENCIA. Si requiere descargar de nuevo los documentos o 
  revisar el seguimiento de esta póliza, por favor haga clic <a href="P_ENLACE">aquí</a>.
  <br/>
  <br/>
  Agradecemos la confianza depositada,
  <br/>
  <br/>
</span>