<span style="font-family: Verdana, Arial, Helvetica, sans-serif;">
  <br/>
  <br/>
  <br/>
  Buenos dias.
  <br/>
  <br/>
  En estos momentos se esta ingresando una nueva poliza, con la siguiente informacion.
  <br/>
  <br/>
  Nombre Completo o Razón Social: P_USUARIO
  <br/>
  <br/>
  Número de identificación: P_NUM_IDEN
  <br/>
  <br/>
  Dígito de verificación: P_DIG_VER
  <br/>
  <br/>
  Dirección de residencia: P_DIR_RES
  <br/>
  <br/>
  Ciudad de residencia: P_CIU_RES
  <br/>
  <br/>
  Teléfono: P_TEL
  <br/>
  <br/>
  Correo electrónico: P_EMAIL
  <br/>
  <br/>
  Referencia o Código del Contrato: P_REF_CON
  <br/>
  <br/>
</span>