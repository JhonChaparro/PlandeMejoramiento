<div style="width: 100%; font-family: Open Sans,arial,helvetica,sans-serif;">
  <br> Hola, P_REFERIDO
  <br>Su correo electrónico para ingresar al sistema es: P_EMAIL 
  <p style="text-align:center;font-size:22px;">
    Su código refereridor es: 
    <br> COD_REFERIDOR 
  </p>
  Gracias por unirse al Programa de Referidos de SEPOL. Comencemos:
  <br>
  <br>
  <div style="display:inline-block; background:#E6E6E6; padding:10px;width:100%;" >
    <br>
    <span style=" background: #EF0BD8; border-radius: 0.8em; -moz-border-radius: 0.8em; -webkit-border-radius: 0.8em; color: #ffffff; display: inline-block; font-weight: bold; line-height: 1.6em; margin-right: 15px; text-align: center; width: 1.6em;">
      1
    </span> 
    <label style="color: #000;font-size: 18px;">
      Difunde: SEPOL y comparta su código referidor: &nbsp;
    </label>
    <a href="P_ENLACE" style="color: #2178f0;font-size: 18px;">
      P_ENLACE
    </a>
    <div style="text-align: center;">
      <img src="cid:megafono" alt="" width="100"/>
    </div>
    <br>
  </div>
  <div style="display:inline-block;background:#CEE3F6;padding:10px;width:100%;" >
    <br>
    <span style=" background: #EF0BD8; border-radius: 0.8em; -moz-border-radius: 0.8em; -webkit-border-radius: 0.8em; color: #ffffff; display: inline-block; font-weight: bold; line-height: 1.6em; margin-right: 15px; text-align: center; width: 1.6em;">
      2
    </span>
    <label style="color: #000;font-size: 18px;">
      Gane el COMI_REFERIDOS% por venta: Gane el COMI_REFERIDOS% por venta concretada sobre cualquier tipo de póliza de cumplimiento y/o de responsabilidad civil.
    </label>
    <div style="text-align: center;">
      <img src="cid:dinero" alt="" width="100"/>
    </div>
    <br>
  </div>
  <br>
  <br>
  <label style="font-weight:bold;">¿Tiene alguna pregunta? </label>
  <br>
  Envíe un correo electrónico. Si tiene alguna duda por favor escribanos a este correo: <label style="font-weight:bold;">EMAIL_REPLY</label>
  <br/>
  <br/>
</div>