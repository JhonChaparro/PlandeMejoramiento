<span style="font-family: Verdana, Arial, Helvetica, sans-serif;">
  <br/>
  <br/>
  <br/>
  Hola P_AFIANZADO:
  <br/>
  <br/>
  Bienvenido a nuestro sistema SEPOL - Sistema de emisión en línea.
  <br/>
  <br/>
  A continuación podrá encontrar la información necesaria para poder ingresar a nuestro sistema.
  <br/>
  <br/>
  Direccion web:  P_URL
  <br/>
  Usuario:        P_USUARIO
  <br/>
  Contraseña:     P_PASSWORD
  <br/>
  <br/>

  Una vez inicie sesión con estos datos usted podrá:

  <ul>
    <li>Ver el seguimiento de la póliza</li>
    <li>Ver el histórico de las pólizas emitidas</li>
    <li>Pre-cargar los datos del afianzado para las siguientes emisiones</li>
  </ul>
  Si tiene algun inconveniente no dude en comunicarse con nosotros.
  <br/>
  <br/>
</span>