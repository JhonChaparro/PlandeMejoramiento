<span style="font-family: Verdana, Arial, Helvetica, sans-serif;">
  <br/>
  <br/>
  <br/>
  Hola P_AFIANZADO:
  <br/>
  <br/>
  Hemos recibido el pago para la póliza del contrato No P_REFERENCIA, una vez esten emitidos los documentos los recibirá por este medio.
  En cualquier momento podrá ingresar a revisar el estado de su póliza haciendo clic <a href="P_ENLACE">aquí</a>.
  <br/>
  <br/>
  Agradecemos la confianza depositada,
  <br/>
  <br/>
</span>