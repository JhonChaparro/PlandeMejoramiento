<span style="font-family: Verdana, Arial, Helvetica, sans-serif;">
  <br/>
  <br/>
  <br/>
  Hola P_AFIANZADO:
  <br/>
  <br/>
  Su solicitud ha sido recibida exitosamente para el contrato con referencia No P_REFERENCIA y se encuentra en estado <b>PENDIENTE
    PARA REVISIÓN</b>, en un lapso no mayor a 30 minutos recibirá instrucciones para continuar con su tramite por este medio. 
  En cualquier momento podrá ingresar a revisar el avance de su póliza haciendo clic <a href="P_ENLACE">aquí</a>.
  <br/>
  <br/>
  Agradecemos la confianza depositada,
  <br/>
  <br/>
</span>