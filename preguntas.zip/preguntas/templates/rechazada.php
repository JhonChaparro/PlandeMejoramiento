<span style="font-family: Verdana, Arial, Helvetica, sans-serif;">
  <br/>
  <br/>
  <br/>
  Hola P_AFIANZADO:
  <br/>
  <br/>
  Su solicitud para el contrato con referencia P_REFERENCIA ha sido <b>RECHAZADA</b> debido a que se encuentra fuera de
  las políticas de suscripción de riesgo de las aseguradoras, si cree que tiene alguna información que modifique las características del riesgo,
  lo invitamos a comunicarse con nuestra gerencia de suscripción al 3103102858 y así de manera conjunta encontrar la forma de otorgar su póliza. 
  En cualquier momento podrá ingresar a revisar el estado de su póliza haciendo clic <a href="P_ENLACE">aquí</a>.
  <br/>
  <br/>
  Agradecemos la confianza depositada,
  <br/>
  <br/>
</span>