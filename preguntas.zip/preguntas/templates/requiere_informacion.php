<span style="font-family: Verdana, Arial, Helvetica, sans-serif;">
  <br/>
  <br/>
  <br/>
  Hola P_AFIANZADO:
  <br/>
  <br/>
  Su solicitud para el contrato con referencia No P_REFERENCIA <b>REQUIERE MÁS INFORMACIÓN</b>, lo invitamos a
  ingresar a nuestra plataforma haciendo clic <a href="P_ENLACE">aquí</a> y aportar la información pendiente para continuar con el trámite, 
  una vez la misma sea recibida por nuestro equipo, usted recibirá respuesta en un lapso no mayor a 15 minutos.
  <br/>
  <br/>
  Agradecemos la confianza depositada,
  <br/>
  <br/>
</span>