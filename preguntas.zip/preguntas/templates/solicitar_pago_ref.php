<div style="width:100%;font-family: Open Sans,arial,helvetica,sans-serif;">
  <label>
    <br> Hola tienes una nueva solicitud de pago 
  </label>
  <br>
  <br>
  <label>Los datos del usuario se muestran a continuación:</label>
  <br>
  <br>
  <label>Nombre: P_REFERIDO</label>
  <br>
  <br>
  <label>Banco: P_BANCO_NOMBRE</label>
  <br>
  <br>
  <label>Tipo de Cuenta: P_TIPO_CUENTA</label>
  <br>
  <br>
  <label>Numero de Cuenta: P_BANCO_NUMERO</label>
  <br>
  <br>
  <label>Email: P_EMAIL</label>
  <br>
  <br>
  <label>Los productos por los que puede reclamar el usuario se listan a continuación:</label>
  <br>
  <br>
  <table style="border-collapse: collapse;">
    <thead>
      <tr>
        <th style="text-align:left;">Ref Contrato</th>
        <th style="text-align:left;">Afianzado</th>
        <th style="text-align:left;">Email</th>
        <th style="min-width: 90px;text-align:left;">Municipio</th>
        <th style="min-width: 90px;text-align:left;">Estado</th>
        <th style="text-align:left;">Ultima Actualización</th>
        <th style="text-align:left;">Valor Prima</th>
        <th style="text-align:left;">Valor Comisión</th>
      </tr>
    </thead>
    <tbody>
      P_CONTENIDO
    </tbody>
    <tfoot>
      <tr>
        <td colspan='6' style='text-align:right;'>
          Total valor a pagar:
        </td>
        <td style='text-align:right;'>
          P_CONTAD
        </td>
      </tr>
    </tfoot>
  </table>
</div>
<br>
<label>Después de realizar el pago, por favor, acceda al sistema y actualice las cotizaciones por las cuales ya se hizo el pago</label>
<br>
<br>
