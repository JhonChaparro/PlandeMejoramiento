<?php
//     DESCRIPCION:	Programa para ingresar, editar y deshabilitar los amparo
//         VERSION:	1.0
//           AUTOR:	NETStudio
//           FECHA:	2016-03-22
//
//  MODIFICACIONES:
//
//
?>
<script type="text/javascript" src="js/amparo.js?time=<?php echo time(); ?>"></script>
<div class="title">Control de Amparos</div>
<br/>
<br/>
<input type="text" id="textBusqueda"/><button class="btn btn-default" id="btnBusqueda">Buscar <img src="images/b_search.png"/></button><button class="btn btn-default" id="btnBusqueda" onclick="javascript:editarAmparo('nuevo');">Nuevo Amparo <img src="images/b_add.png"/></button> 
<div id="divListaAmparos"></div>
<div id="divEditAmparos" align="center">
  <form enctype='MULTIPART/form-data' method= "post">
    <table>
      <tr>
        <td style="text-align: right;">* Nombre:</td>
        <td><input type="text" id="amparo_nombre"/></td>
      </tr>	
      <tr>
        <td style="text-align: right; vertical-align: top;">* Garantia:</td>
        <td>
          <select id="garantia_id">
          <?php echo $mySQL->get_options_from_query('garantia', 'garantia_id', "garantia_nombre", "garantia_activo = 'S'");?>
          </select>
        </td>
      </tr>
      <tr>
        <td style="text-align: right;">* Tipo de amparo:</td>
        <td>
          <select id="tipo_amparo_id">
            <?php echo $mySQL->get_options_from_query('tipo_amparo', 'tipo_amparo_id', 'tipo_amparo_nombre');?>
          </select>
        </td>
      </tr>	
      <tr>
        <td style="text-align: right;">* La vigencia puede ser no definida?:</td>
        <td>
          <select id="vig_no_def">
            <option value="S">SI</option>
            <option value="N">NO</option>
          </select>
        </td>
      </tr>	
      <tr>
        <td style="text-align: right; vertical-align: top;">* Tipos de liquidación:</td>
        <td>
          <?php echo $mySQL->set_checkbox_from_query('tipo_liqui', 'tipo_liqui_id', "amparo_liqui_nombre", "", "tipo_liqui_id", NULL, true);?>
        </td>
      </tr>
      <input type="hidden" id="amparo_id" name="amparo_id"/>
    </table>
    <hr/>
    <div id="divEditAmparosMessage"></div>
    <br/>
    <br/>
    <button class="btn btn-info" id="btnGuardar">Guardar</button>
    <button class="btn btn-default" id="btnCancelar">Cancelar</button>
  </form>
  <div id="divEditAmparosMessage"></div>
</div>