<?php
//     DESCRIPCION:	Programa para ingresar, editar y deshabilitar las campañas
//         VERSION:	1.0
//           AUTOR:	NETStudio
//           FECHA:	2016-03-22
//
//  MODIFICACIONES:
//
//
?>
<script type="text/javascript" src="js/campanias.js?time=<?php echo time(); ?>"></script>
<div class="title">Control de Campañas</div>
<br/>
<br/>
<input type="text" id="textBusqueda"/>
<button class="btn btn-default" id="btnBusqueda">Buscar <img src="images/b_search.png"/></button>
<button class="btn btn-default" id="btnBusqueda" onclick="javascript:editarCampania('nuevo');">Nueva Campaña <img src="images/b_add.png"/></button> 
<div id="divListaCampanias"></div>
<div id="divEditCampanias" align="center">
  <form enctype='MULTIPART/form-data' method= "post">
    <table>
      <tr>
        <td style="text-align: right;">* Nombre:</td>
        <td><input type="text" id="campania_nombre"/></td>
      </tr>	
      <tr>
        <td style="text-align: right;">* Llave:</td>
        <td><input type="text" id="llave"/></td>
      </tr>
      <input type="hidden" id="campania_id" name="campania_id"/>
    </table>
    <hr/>
    <div id="divEditCampaniasMessage"></div>
    <br/>
    <br/>
    <button class="btn btn-info" id="btnGuardar">Guardar</button>
    <button class="btn btn-default" id="btnCancelar">Cancelar</button>
  </form>
</div>