<script type="text/javascript" src="js/polizas_tramite.js?time=<?php echo time(); ?>"></script>
<div class="title">Cargar Póliza</div>
<table align="center">
  <br/> 
  <br/> 
  <tr>
    <td>Para Agregar el PDF de la poliza, por favor carguelo con el siguiente campo:</td>
  </tr>
  <tr>
    <td>
      <form enctype="multipart/form-data" action="ajax/cargar_poliza_ajax.php" method="POST">
        <input id="cargar_poliza" name="cargar_poliza" type="file" onchange="javascript:validarArchivoPDF();"/>
        <br/>
        <br/>
        <input type="hidden" id="poliza_id" name="poliza_id" value="<?php echo $_REQUEST['poliza_id']; ?>">
        <input type="hidden" id="ref_contrato" name="ref_contrato" value="<?php echo $_REQUEST['ref_contrato']; ?>">
        <input type="submit" class="btn btn-info" id="submit" value="Subir logo" disabled="true"/>
      </form>
    </td>
  </tr>
</table>