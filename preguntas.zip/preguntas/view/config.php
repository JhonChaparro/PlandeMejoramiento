
<script type="text/javascript" src="js/config.js?time=<?php echo time();?>"></script>
<div class="title">Configuración del sistema</div>
<br/>
<br/>
<table class="tablesorter" id="tablaLista" style="width: 80%">
  <thead>
  <th>Parametro</th>
  <th>Valor</th>
  </thead>
  <tbody>
<?php
$sql = "SELECT * FROM config WHERE config_visible = 'S'";
$query = $mySQL->query($sql);
if($query['success']){
  while ($row = $mySQL->fetch_assoc($query['result'])) {
    echo '<tr>
            <td id="config_nombre_' . $row['config_id'] . '">' . $row['config_desc'] . '</td>
            <td>
              <input type="hidden" name="config_id" value="' . $row['config_id'] . '"/>';
      if($row['config_tipo'] == 'select'){
        echo '<select name="config_valor" id="config_id_' . $row['config_id'] . '">';
        echo $mySQL->get_options_from_query('config_opcion', 'config_llave', 'config_etiqueta', 'config_id = ' . $row['config_id'], '', $row['config_valor'], false);
        echo '</select>';
      } else if ($row['config_tipo'] == 'text'){
        echo '<input type="text" name="config_valor" size="50" value="' . $row['config_valor'] . '" id="config_id_' . $row['config_id'] . '"/>';
      } else if ($row['config_tipo'] == 'textarea') {
        echo '<textarea rows="5" cols="15" name="config_valor" id="config_id_' . $row['config_id'] . '">' . $row['config_valor'] . '</textarea>';
      } else if ($row['config_tipo'] == 'password') {
        echo '<input type="password" name="config_valor" value="' . $row['config_valor'] . '" id="config_id_' . $row['config_id'] . '"/>';
      }
    echo '</td></tr>';
  }
}
?>
  </tbody>
</table>
<hr/>
<div id="divConfigMessage"></div>
<br/>
<br/>
<button class="btn btn-info" id="btnAplicar">Aplicar cambios</button>