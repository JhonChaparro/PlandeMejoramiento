<?php
//     DESCRIPCION:	Pagina principal del sitio
//         VERSION:	1.0
//           AUTOR:	NETStudio
//           FECHA:	2012-12-26
//
//  MODIFICACIONES:
//
//

?>
PREGUNTAS - Ahora es más facil.  Por favor utilice el menú ubicado en la parte superior de la pantalla
