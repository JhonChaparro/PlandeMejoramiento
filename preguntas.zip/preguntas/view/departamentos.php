<script type="text/javascript" src="js/departamentos.js?time=<?php echo time(); ?>"></script>
<div class="title">Control de Departamentos</div>
<br/>
<br/>
<input type="text" id="textBusqueda"/><button class="btn btn-default" id="btnBusqueda">Buscar <img src="images/b_search.png"/></button> 
<div id="divListaDepartamentos"></div>
<div id="divEditDepartamentos" align="center">
  <div id="divEditDepartamentosMessage"></div>
</div>
<center>
  <button class="btn btn-info" id="btnEstado">Cambiar estado</button>
</center>