<script type="text/javascript" src="js/efectividad_campanias.js?time=<?php echo time(); ?>"></script>
<div class="alert alert-info" style="margin:10px;">
  <table>
    <tr> 
      <td>
        <label>Desde:</label>
      </td>
      <td>
        &nbsp;&nbsp;
      </td>
      <td>
        <label>Hasta:</label>
      </td>
    </tr>
    <tr>
      <td> 
        <input type="text" name="fec_inicio" class="form-control" id="fec_inicio" style="color: #000;" />
      </td>
      <td>
        &nbsp;&nbsp;
      </td>
      <td>
        <input type="text" name="fec_final" class="form-control" id="fec_final" style="color: #000;"/>
      </td>
    </tr>
  </table>
</div>
<center>
  <button class="btn btn-info" id="btnBuscar" style="font-size: 18px;">Buscar</button>
</center>
<div id="divReportCampanias" style="width: 70%"></div>