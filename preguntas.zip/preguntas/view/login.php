<script type="text/javascript" src="js/login.js?time<?php echo time() ?>"></script>
<div class="form-horizontal alert alert-info" style="width: 400px; height: 400px; font-weight: bold;" align="center">
  <h3 class="muted">Sistema de gestión de preguntas en línea</h3>
  <br/>
  <br/>
  <table>
    <tr>
      <td>
        Correo electrónico
        <br/>
        <input type="text" name="usuario_email" id="usuario_email" placeholder=""/>
      </td>
    </tr>
    <tr>
      <td>
        Contraseña
        <br/>
        <input type="password" name="usuario_passwd" id="usuario_passwd" placeholder=""/>
      </td>
    </tr>
    <tr>
      <td align="right">
        <a href="javascript:iniciarOSC();">¿Olvido su contraseña?</a>
      </td>
    </tr>
  </table>
  <br/>
  <button id="button_login" class="btn btn-info">Iniciar sesión</button>
</div>
<div id="divOSC" title="Recuperación de contraseña" align="center" style="display: none;">
  <br/>
  <br/>
  Digite su correo elctrónico:
  <br/>
  <input type="text" id="usuario_osc"/>
  <br/>
  <br/>
  <hr/>
  <div id="divOSCMessage"></div>
  <br/>
  <button class="btn btn-info" id="btnRecuperar">Recuperar Contraseña</button>
  <button class="btn btn-default" id="btnCancelar">Cancelar</button>
</div>
