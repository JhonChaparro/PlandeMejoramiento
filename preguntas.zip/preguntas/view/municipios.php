<script type="text/javascript" src="js/municipios.js?time=<?php echo time(); ?>"></script>
<div class="title">Control de Municipios</div>
<br/>
<br/>
<label>seleccione un departamento:</label>
<select id="departamento_id" style="width: auto;" onchange="javascript:listarMunicipios();">
  <option value='' disabled selected>Seleccione... </option>
  <?php echo $mySQL->get_options_from_query('departamento', 'departamento_id', 'departamento_nombre', "departamento_activo = 'S'", 'departamento_nombre', '', false); ?>
</select>
<div id="divListaMunicipios"></div>
<div id="divEditMunicipios" align="center">
  <div id="divEditMunicipiosMessage"></div>
</div>
<center>
  <button class="btn btn-info" id="btnEstado">Cambiar estado</button>
</center>