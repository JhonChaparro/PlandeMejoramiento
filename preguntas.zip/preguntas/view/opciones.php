<script type="text/javascript" src="js/opciones.js?time=<?php echo time();?>"></script>
<div id="divLista"></div>
<div id="divEdit" style="display: none; text-align: center;">
  <div id="divNombreOpcion"></div>
  <br/>
  <br/>
  <input type="hidden" id="opcion_id"/>
  <table style="text-align: left;">
    <tr>
      <td class="forminput">
        <?php echo $mySQL->set_checkbox_from_query('rol', 'rol_id', 'rol_nombre', null, 'rol_id', '', true);?>
      </td>
    </tr>
  </table>
  <hr/>
  <div id="divEditMessage"></div>
    <br/>
    <br/>
  <button class="btn btn-default" id="btnAplicar">Aplicar cambios</button>
  <button class="btn btn-default" id="btnCancelar">Cancelar</button>
</div>
