<?php
include_once dirname(__FILE__) . '/../../model/Referidos.php';
$ref = new Referidos();

$config_vars = $mySQL->getConfigVars();
?>
<script type="text/javascript" src="js/referidos.js?time=<?php echo time(); ?>"></script>


<div class="alert alert-info" style="margin:10px;">
  <table>
    <tr> 
      <td>
        <label>Emisión Desde:</label>
      </td>
      <td>
        <label>Emisión Hasta:</label>
      </td>
      <td>
        <label>Nombre:</label>
      </td>
      <td>
        <label>Banco:</label>
      </td>
    </tr>
    <tr>
      <td> 
        <input type="text" name="fec_inicio" class="form-control" id="fec_inicio" style="color: #000;" />
      </td>
      <td>
        <input type="text" name="fec_final" class="form-control" id="fec_final" style="color: #000;"/>
      </td>
      <td>
        <input type="text" name="usuario_nombre" class="form-control" id="usuario_nombre" style="color: #000;"/>
        <input type="hidden" id="usuario_id" name="usuario_id" value="<?php echo $_POST['usuario_id']; ?>"/>
      </td>
      <td>
        <input type="text" name="banco_nombre" class="form-control" id="banco_nombre" style="color: #000;"/>
      </td>
    </tr>
  </table>
</div>
<p style="text-align:center;">
  <button class="btn btn-info" id="buscar" style="font-size: 18px;" onclick="javascript:filtrarPagosRealizados();">Buscar</button>
</p>
<h3 style="text-align:center;">Listado de pagos que ya fueron realizados </h3>
<?php
$sql = "SELECT refe_pago.refe_pago_id,refe_pago.fec_solicitud,usuario.usuario_nombre, refe_pago.banco_nombre,refe_pago.banco_cuenta,refe_pago.referidor_id,
        (SELECT SUM(poliza.comi_refer) FROM poliza poliza WHERE poliza.refe_pago_id=refe_pago.refe_pago_id AND poliza.referido_estado_id=4) AS 'total',
        (SELECT MAX(poliza.fec_pago_refe) FROM poliza poliza WHERE poliza.refe_pago_id=refe_pago.refe_pago_id AND poliza.referido_estado_id=4) AS 'fecha_pago' 
        FROM refe_pago refe_pago,usuario usuario 
        WHERE usuario.usuario_id=refe_pago.referidor_id AND (SELECT SUM(poliza.comi_refer) 
        FROM poliza poliza WHERE poliza.refe_pago_id=refe_pago.refe_pago_id AND poliza.referido_estado_id=4)>0  
        ORDER BY refe_pago.fec_solicitud";
$query = $mySQL->query($sql);
if ($query['success']) {
  ?>
  <div class="table-scrollable " id="pagos_realizados" style="height: auto;overflow: auto;margin: 10px;">   
    <table class="table">
      <thead>
        <tr>
          <th>Fecha&nbsp;de&nbsp;Solicitud</th>
          <th>Fecha&nbsp;de&nbsp;pago</th>
          <th >Solicitante</th>
          <th >&nbsp;Banco&nbsp;</th>
          <th>Número&nbsp;de&nbsp;Cuenta</th>
          <th style='text-align:right;'>&nbsp;Total&nbsp;</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $conta = 1;
        $contad = 0;
        if ($mySQL->num_rows($query['result']) > 0) {
          while ($refe_pago = $mySQL->fetch_assoc($query['result'])) {

            echo "<tr><td>" . date("Y-m-d H:i", $refe_pago[fec_solicitud]) . "</td>"
            . "<td>$refe_pago[fecha_pago]</td>"
            . "<td>$refe_pago[usuario_nombre]</td>"
            . "<td>$refe_pago[banco_nombre]</td>"
            . "<td>$refe_pago[banco_cuenta]</td>"
            . "<td style='text-align:right;'>$&nbsp;$refe_pago[total]</td></tr>";
          }
        } else {
          ?>
          <tr>
            <td colspan="8">No hay pagos realizados</td>
          </tr> 
        <?php } ?>
      </tbody> 
    </table>
  </div>
  <div id="errordatoscuenta"></div>
  <?php
}
?>
 

