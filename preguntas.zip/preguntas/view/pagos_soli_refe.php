<?php
include_once dirname(__FILE__) . '/../../model/Referidos.php';

$ref = new Referidos();

$config_vars = $mySQL->getConfigVars();
?>
<script type="text/javascript" src="js/referidos.js?time=<?php echo time(); ?>"></script>

<h3 style="text-align:center;">Pólizas solicitadas para pago </h3>
<?php
$sql = "SELECT refe_pago.refe_pago_id,refe_pago.fec_solicitud,usuario.usuario_nombre, refe_pago.banco_nombre, refe_pago.banco_cuenta,refe_pago.referidor_id,
        (SELECT SUM(poliza.comi_refer) FROM poliza WHERE poliza.refe_pago_id=refe_pago.refe_pago_id AND poliza.referido_estado_id=3) AS 'total' FROM refe_pago refe_pago,
         usuario usuario WHERE 
          usuario.usuario_id=refe_pago.referidor_id AND (SELECT SUM(poliza.comi_refer) 
          FROM poliza poliza WHERE poliza.refe_pago_id=refe_pago.refe_pago_id AND poliza.referido_estado_id=3)>0 ORDER BY refe_pago.fec_solicitud";
$query = $mySQL->query($sql);
if ($query['success']) {
  ?>
  <div class="table-scrollable " style="height: auto;overflow: auto;">   
    <table class="table">
      <thead>
        <tr>
          <th>Fecha&nbsp;de&nbsp;Solicitud</th>
          <th >Solicitante</th>
          <th >&nbsp;Banco&nbsp;</th>
          <th>Número&nbsp;de&nbsp;Cuenta</th>
          <th style='text-align:right;'>&nbsp;Total&nbsp;</th>
          <?php
          ?>
          <?php
          $conta = 1;
          $contad = 0;
          if ($mySQL->num_rows($query['result']) > 0) {
            echo '<th><input type="checkbox" id="all"></th></thead><tbody>';
            while ($refe_pago = $mySQL->fetch_assoc($query['result'])) {

              echo "<tr><td>" . date("Y-m-d H:i", $refe_pago[fec_solicitud]) . "</td>"
              . "<td>$refe_pago[usuario_nombre]</td>"
              . "<td>$refe_pago[banco_nombre]</td>"
              . "<td>$refe_pago[banco_cuenta]</td>"
              . "<td style='text-align:right;'>USD&nbsp;$$refe_pago[total]</td>"
              . "<td><input id='td[]' name='$refe_pago[refe_pago_id]' type='checkbox' value='" . $refe_pago[refe_pago_id] . "'></td></tr>";
            }
            echo ' </tbody> </table></div>
<div id="errordatoscuenta"></div>
  <p align="right"><button class="btn btn-primary btn-contacto" id="cambiarEstado" onclick="javascript:cambiarEstadoReferidos();" disabled >Marcar como pagadas</button><br>
 <label>Para habilitar debe marcar por lo menos una solicitud</label>
  <br></p>';
          } else {
            ?>
          </tr>
        </thead>
        <tbody> 
          <tr>
            <td colspan="8">No hay solicitudes de pago</td>
          </tr>
        </tbody> 
      </table>
    </div>
  <?php } ?>

  <?php
}
?>

<div id="divProcessing" align="center" style="display: none;">
  <span id="divProcessMessage" style="max-width: 100px;"></span><img src="images/spinner.gif"/><br><br>
</div>
