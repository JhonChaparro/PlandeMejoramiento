<script type="text/javascript" src="js/poliza_form.js?time=<?php echo time(); ?>"></script>
<?php
//var_dump($_SESSION);
unset($_SESSION['poliza_id']);
$poliza_id = $_REQUEST['poliza_id'];
$tools = new Tools();

$sql = "SELECT poliza.nombres afianzado, tipo_documento.sigla, CONCAT(municipio.municipio_nombre,' - ',departamento.departamento_nombre) lug_poliza, giro_negocio.giro_negocio_nombre, giro_negocio.giro_negocio_id, CONCAT(mun.municipio_nombre,' - ',dep.departamento_nombre) lug_res_afi_text, poliza.*, sector.sector_nombre,
          CONCAT(usuario.usuario_nombre,' ',usuario.usuario_apel) creador
        FROM poliza
        LEFT JOIN tipo_documento USING (tipo_documento_id)
        LEFT JOIN municipio ON (municipio.municipio_id = poliza.municipio_id)
        LEFT JOIN departamento ON (departamento.departamento_id = municipio.departamento_id)
        LEFT JOIN municipio as mun ON (mun.municipio_id = poliza.lug_res_afi)
        LEFT JOIN departamento as dep ON (dep.departamento_id = mun.departamento_id)
        LEFT JOIN giro_negocio ON (giro_negocio.giro_negocio_id = poliza.giro_negocio_id)
        LEFT JOIN sector ON (poliza.sector_id = sector.sector_id)
        LEFT JOIN usuario ON (poliza.creacion_id = usuario.usuario_id)
        WHERE poliza_id = $poliza_id";
$query = $mySQL->query($sql);
if ($query['success']) {
  if ($mySQL->num_rows($query['result']) > 0) {
    $filapoliza = $mySQL->fetch_assoc($query['result']);
  }
}

$asegurados = array();
$sql = "SELECT poliza_asegurado.nombres asegurado, tipo_documento.sigla, CONCAT(municipio.municipio_nombre, ', ', departamento.departamento_nombre) residencia, poliza_asegurado.*
        FROM poliza_asegurado
        INNER JOIN tipo_documento USING (tipo_documento_id)
        LEFT JOIN municipio ON (municipio.municipio_id = poliza_asegurado.municipio_id)
        LEFT JOIN departamento ON (departamento.departamento_id = municipio.departamento_id)
        WHERE poliza_id = $poliza_id";
$query = $mySQL->query($sql);
if ($query['success']) {
  if ($mySQL->num_rows($query['result']) > 0) {
    while ($row = $mySQL->fetch_assoc($query['result'])) {
      $asegurados[] = $row;
    }
  }
}

$amparos = array();
$sql = "SELECT amparo.amparo_nombre, poliza_amparo.fec_inicio, poliza_amparo.fec_final, poliza_amparo.valor_asegurado, poliza_amparo.valor_liqui, tipo_amparo.tipo_amparo_nombre, tipo_liqui.amparo_liqui_nombre, amparo.garantia_id, poliza_amparo.poliza_amparo_id
        FROM poliza_amparo
        INNER JOIN amparo USING(amparo_id)
        INNER JOIN tipo_amparo ON (amparo.tipo_amparo_id = tipo_amparo.tipo_amparo_id)
        INNER JOIN poliza ON (poliza_amparo.poliza_id = poliza.poliza_id)
        INNER JOIN tipo_liqui ON (tipo_liqui.tipo_liqui_id = poliza_amparo.tipo_liqui_id)
        WHERE poliza.poliza_id = $poliza_id AND poliza_amparo.poliza_amparo_activo = 'S'
        ORDER BY amparo.garantia_id ASC";
$query = $mySQL->query($sql);
if ($query['success']) {
  if ($mySQL->num_rows($query['result']) > 0) {
    while ($row = $mySQL->fetch_assoc($query['result'])) {
      $amparos[] = $row;
    }
  }
}

$aseguradoras = array();
$sql = "SELECT * FROM aseguradora WHERE aseguradora_activo = 'S'";
$query = $mySQL->query($sql);
if ($query['success']) {
  if ($mySQL->num_rows($query['result']) > 0) {
    while ($row = $mySQL->fetch_assoc($query['result'])) {
      $aseguradoras[] = $row;
    }
  }
}

$garantias = array();
$sql = "SELECT garantia.*, count(poliza_amparo_id) cant_amparos 
        FROM garantia
        INNER JOIN amparo USING (garantia_id)
        LEFT JOIN poliza_amparo ON (amparo.amparo_id = poliza_amparo.amparo_id)
        WHERE poliza_amparo.poliza_id = $poliza_id AND poliza_amparo.poliza_amparo_activo = 'S'
        GROUP BY garantia_id";
$query = $mySQL->query($sql);
if ($query['success']) {
  if ($mySQL->num_rows($query['result']) > 0) {
    while ($row = $mySQL->fetch_assoc($query['result'])) {
      $garantias[] = $row;
    }
  }
}

$aseg_selec = array();
$sql = "SELECT poliza_aseguradora.*, aseguradora.aseguradora_nombre, garantia.garantia_nombre
        FROM poliza_aseguradora
        INNER JOIN aseguradora USING (aseguradora_id)
        INNER JOIN garantia using (garantia_id)
        WHERE poliza_id = $poliza_id AND es_seleccionada = 'S'";
$query = $mySQL->query($sql);
if ($query['success']) {
  if ($mySQL->num_rows($query['result']) > 0) {
    while ($row = $mySQL->fetch_assoc($query['result'])) {
      $aseg_selec[] = $row;
    }
  }
}

$tipo_liqui = '';
$sql = "SELECT * FROM tipo_liqui";
$query_liqui = $mySQL->query($sql);
if ($query_liqui['success']) {
  if ($mySQL->num_rows($query_liqui['result']) > 0) {
    while ($row_liqui = $mySQL->fetch_assoc($query_liqui['result'])) {
      $tipo_liqui .= '<input type="radio" name="tipo_liqui" id="tipo_liqui" value="' . $row_liqui['tipo_liqui_id'] . '" onclick="javascript:calcularValorAsegurado();" checked="true"/>  ' . $row_liqui['amparo_liqui_nombre'] . '<br>';
    }
  }
}

$poliza_bitac = array();
$sql = "SELECT poliza_estado.*, poliza_bitac.comentarios, DATE_FORMAT(poliza_bitac.fec_registro,'%Y-%m-%d %H:%i') fec_registro
        FROM poliza_bitac
        INNER JOIN poliza_estado USING (poliza_estado_id)
        INNER JOIN poliza USING (poliza_id)
        WHERE poliza_id = $poliza_id
        ORDER BY poliza_bitac_id DESC";
$query = $mySQL->query($sql);
if ($query['success']) {
  if ($mySQL->num_rows($query['result']) > 0) {
    while ($row = $mySQL->fetch_assoc($query['result'])) {
      $poliza_bitac[] = $row;
    }
  }
}

$total = 0;
foreach ($aseg_selec as $key => $value) {
  $total = $total + $value['total'];
}
//var_dump($aseg_selec);
?>
<h2>Póliza en Trámite</h2>
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title">Datos del Contrato</h3>
  </div>
  <div class="panel panel-default col-md-12">
    <div class="panel-body col-md-6">
      <ul class="list-group" style="text-align: left;">
        <li class="list-group-item">
          <label>Municipio :</label>
          <label style="font-weight: normal; font-family: Times;"><?php echo $filapoliza["lug_poliza"]; ?></label>  <span class="glyphicon glyphicon-pencil" aria-hidden="true" id="CambiarDepartamento" style="cursor:pointer"></span>
        </li>
        <li class="list-group-item">
          <label>Firma del Contrato :</label>
          <label style="font-weight: normal; font-family: Times;"><?php echo $filapoliza['fec_contrato']; ?></label>  <span class="glyphicon glyphicon-pencil" aria-hidden="true" id="CambiarFechas" style="cursor:pointer"></span>
        </li>
        <li class="list-group-item">
          <label>Inicio del Contrato :</label>
          <label style="font-weight: normal; font-family: Times;"><?php echo $filapoliza['fec_inicio']; ?></label>
        </li>
        <li class="list-group-item">
          <label>Finalización del Contrato :</label>
          <label style="font-weight: normal; font-family: Times;"><?php echo $filapoliza['fec_final']; ?></label>
        </li>
        <li class="list-group-item">
          <label>Póliza creada por :</label>
          <label style="font-weight: normal; font-family: Times;"><?php echo $filapoliza['creador']; ?></label>
        </li>
      </ul>
    </div>
    <div class="panel-body col-md-6">
      <ul class="list-group" style="text-align: left;">
        <li class="list-group-item">
          <label>Referencia :</label>
          <label style="font-weight: normal; font-family: Times;"><?php echo $filapoliza['ref_contrato']; ?></label>  <span class="glyphicon glyphicon-pencil" aria-hidden="true" id="infopoliza" style="cursor:pointer"></span>
        </li>
        <li class="list-group-item">
          <label>Sector :</label>
          <label style="font-weight: normal; font-family: Times;"><?php echo $filapoliza['sector_nombre']; ?></label>
        </li>
        <li class="list-group-item">
          <label>Giro de Negocio :</label>
          <label style="font-weight: normal; font-family: Times;"><?php echo $filapoliza['giro_negocio_nombre']; ?></label>
        </li>
        <li class="list-group-item">
          <label>Valor :</label>
          <label style="font-weight: normal; font-family: Times;"><?php echo $filapoliza['valor_contrato']; ?></label>
          <input type="hidden" id="valor_contrato" value="<?php echo $filapoliza["valor_contrato"]; ?>"/>
          <input type="hidden" id="tipo_anticipo" value="<?php echo $filapoliza["tipo_anticipo"]; ?>"/>
          <input type="hidden" id="smmlv" value="689.454"/>
        </li>
        <li class="list-group-item">
          <label>Anticipo :</label>
          <label style="font-weight: normal; font-family: Times;"><?php echo $filapoliza['valor_anticipo']; ?></label>
          <input type="hidden" id="valor_anticipo" value="<?php echo $filapoliza["valor_anticipo"]; ?>"/>
        </li>
        <li class="list-group-item">
          <label>Tipo del Anticipo :</label>
          <label style="font-weight: normal; font-family: Times;"><?php echo ($filapoliza["tipo_anticipo"] == 'P' ? 'Porcentaje del valor del contrato ' : "Valor fijo"); ?></label>
        </li>
        <li class="list-group-item">
          <label style="text-align: left; width: 100%;">Objeto</label>
          <p style="text-align: left; font-weight: normal; font-family: Times;"><?php echo $tools->parseEnterKey($filapoliza["objeto"], '<br/>'); ?></p>
        </li>
      </ul>
    </div>
  </div>
</div>

<div class="panel panel-default col-md-12">
  <div class="panel-body col-md-2">
    <div class="panel panel-default" style="margin-bottom: 0px;">
      <div class="panel-heading">
        <h3 class="panel-title">Afianzado <span class="glyphicon glyphicon-pencil" aria-hidden="true" id="afianzados" style="cursor:pointer"></span></h3>
      </div>
    </div>
    <ul class="list-group">
      <li class="list-group-item">
        <label style="font-weight: normal; font-family: Times; text-align: left; width:100%;"><?php echo $filapoliza["afianzado"]; ?></label>
      </li>
      <li class="list-group-item">
        <label style="font-weight: normal; font-family: Times; text-align: left; width:100%;"><?php echo $filapoliza["sigla"] . ' ' . $filapoliza["identificacion"]; ?></label>
      </li>
      <li class="list-group-item">
        <label style="font-weight: normal; font-family: Times; text-align: left; width:100%;">Dir: <?php echo $filapoliza["direccion"]; ?></label>
      </li>
      <li class="list-group-item">
        <label style="font-weight: normal; font-family: Times; text-align: left; width:100%;">Tel: <?php echo $filapoliza["telefono"]; ?></label>
      </li>
      <li class="list-group-item">
        <label style="font-weight: normal; font-family: Times; text-align: left; width:100%;">Email: <br/><?php echo $filapoliza["email"]; ?></label>
      </li>
      <li class="list-group-item">
        <label style="font-weight: normal; font-family: Times; text-align: left; width:100%;"><?php echo $filapoliza["lug_res_afi_text"]; ?></label>
      </li>
    </ul>
  </div>

  <div class="panel-body col-md-2 col-md-offset-1">
    <div class="panel panel-default" style="margin-bottom: 0px;">
      <div class="panel-heading">
        <h3 class="panel-title">Documentos</h3>
        <span class="glyphicon glyphicon-plus-sign" id="agregarDocumentos" style="cursor:pointer"></span>
      </div>
    </div>
    <ul class="list-group">
      <li class="list-group-item">
        <table style="width:95%;">
          <tbody id="tbodyAdjuntosOuter">          
          </tbody>
        </table>
      </li>
    </ul>
  </div>

  <div class="panel-body col-md-6 col-md-offset-1">
    <div class="panel panel-default" style="margin-bottom: 0px;">
      <div class="panel-heading">
        <h3 class="panel-title">Asegurados Y Beneficiarios</h3>
        <span class="glyphicon glyphicon-plus-sign" id="CambiarAsegurados" style="cursor:pointer" onclick="javascript:editarAsegurado('nuevo');"></span>
      </div>
      <table class="table table-striped">
        <thead>
          <tr>
            <th>Tercero</th>
            <th>Asegurado</th>
            <th>Beneficiario</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($asegurados as $key => $value) { ?>
            <tr>
              <td>
                <span><?php echo $value["asegurado"]; ?></span>
                <br/>
                <span><?php echo $value["sigla"]; ?></span> <span><?php echo $value["identificacion"]; ?></span>
                <br/>
                Dir: <span><?php echo $value["direccion"]; ?></span>
                <br/>
                Tel: <span><?php echo $value["telefono"]; ?></span>
                <br/>
                Email: <br/><span><?php echo $value["email"]; ?></span>
                <br/>
                <span><?php echo $value["residencia"]; ?></span>

              </td>
              <td>
                <?php if ($value["es_asegur"] == 1) { ?>
                  <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>
                <?php } ?>
              </td>
              <td>
                <?php if ($value["es_benef"] == 1) { ?>
                  <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>
                <?php } ?>
              </td>
              <td>
                <span class="glyphicon glyphicon-pencil" aria-hidden="true" id="prueba" style="cursor:pointer" onclick="javascript:editarAsegurado('editar',<?php echo $value['poliza_asegurado_id']; ?>);"></span>
                <span class="glyphicon glyphicon-trash" aria-hidden="true" id="prueba" style="cursor:pointer" onclick="javascript:eliminarAsegurado(<?php echo $value['poliza_asegurado_id']; ?>, 'Asegurado');"></span>
              </td>
            </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="panel panel-default col-md-12">
  <table class="col-md-12">
    <tr align="center">
      <td colspan="5">
        <br/>
        <?php if (!empty($filapoliza["sector_id"])) { ?>
          <button class="btn btn-info" id="btnAgregarAmparo"><span class="glyphicon glyphicon-plus-sign"></span> Agregar Amparo</button>
        <?php } else { ?>
          <span id="msgPassword" class="msghelp">La póliza no pertenece a ningún sector, por favor seleccione uno para poder cargar los amparos.</span>
        <?php } ?>
      </td>
    </tr>
    <?php
    $total_valor_asegurado = 0;
    foreach ($garantias as $value) {
      ?>
      <tr align="center">
        <td colspan="5">
          <fieldset>
            <legend><?php echo $value['garantia_nombre']; ?></legend>
            <br/>
            <br/>
            <table align="center" width="80%" class="table">
              <?php if ($value['cant_amparos'] > 0) { ?>
                <thead>
                  <tr>
                    <th>Descripción amparos contrato</th>
                    <th>Tipo amparo</th>
                    <th>Vigencia desde</th>
                    <th>Vigencia hasta</th>
                    <th>Tipo de liquidacion</th>
                    <th>Suma a liquidar</th>
                    <th>Suma a asegurada</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $total_garantia = 0;
                  foreach ($amparos as $key => $valor) {
                    if ($value['garantia_id'] == $valor['garantia_id']) {
                      ?>
                      <tr>
                        <td style="text-align: left;"><?php echo $valor['amparo_nombre']; ?></td>
                        <td style="text-align: left;"><?php echo $valor['tipo_amparo_nombre']; ?></td>
                        <td style="text-align: left;"><?php echo $valor['fec_inicio']; ?></td>
                        <td style="text-align: left;"><?php echo $valor['fec_final']; ?></td>
                        <td style="text-align: left;"><?php echo $valor['amparo_liqui_nombre']; ?></td>
                        <td style="text-align: right;"><?php echo $valor['valor_liqui']; ?></td>
                        <td style="text-align: right;"><?php echo number_format($valor['valor_asegurado'], 2, '.', ','); ?></td>
                        <td>
                          <span class="glyphicon glyphicon-pencil" aria-hidden="true" id="prueba" style="cursor:pointer" onclick="javascript:editarAmparo(<?php echo $valor['poliza_amparo_id']; ?>);"></span>
                          <span class="glyphicon glyphicon-trash" aria-hidden="true" id="prueba" style="cursor:pointer" onclick="javascript:eliminarAmparo(<?php echo $valor['poliza_amparo_id']; ?>);"></span>
                        </td>
                      </tr>
                      <?php
                      $total_garantia = $total_garantia + $valor['valor_asegurado'];
                    }
                  }
                  ?>
                  <tr>
                    <td colspan="6" style="text-align: right;"><b>Total valor asegurado:</b></td>
                    <td style="text-align: right;">
                      <?php echo number_format($total_garantia, 2, '.', ','); ?>
                      <input type="hidden" name="total_garantia" id="total_garantia_<?php echo $value['garantia_id']; ?>" value="<?php echo $total_garantia; ?>">
                    </td>
                    <td></td>
                  </tr>
                <?php } else { ?>
                  <tr><td style="text-align: center;">No hay amparos asociados a esta garantía</td></tr>
                <?php } ?>
              </tbody>
            </table>
          </fieldset>
          <br/>
        </td>
      </tr>
    <?php } ?>
    <tr>
      <td style="text-align: right; width: 91%;"><b>Total asegurado:</b></td>
      <td style="text-align: right;">
        <span id="total_asegurado"></span>
        <input type="hidden" id="valor_asegurado_total">
      </td>
    </tr>
  </table>
</div>
<?php if ($filapoliza['poliza_estado_id'] == 6) { ?>
  <div style="text-align: left;">
    <b>La aseguradora seleccionada fue <?php echo $aseg_selec[0]['aseguradora_nombre']; ?> y se ha recibido un pago por <?php echo number_format($total, 2, '.', ','); ?>, ya puede expedir la póliza.</b>
  </div>
<?php } ?>

<?php if (!empty($poliza_bitac)) { ?>
  <div class="panel panel-default col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title">Seguimiento de la solicitud</h3>
      </div>
      <table class="table">
        <thead>
          <tr>
            <th>Estado</th>
            <th>Comentario</th>
            <th>Fecha</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($poliza_bitac as $key => $value) { ?>
            <tr>
              <td>
                <span class="glyphicon glyphicon-<?php echo $value['icono']; ?>" aria-hidden="true"  style="color: <?php echo $value['color_fondo'] ?>"></span>&nbsp;&nbsp;&nbsp;  <?php echo $value['poliza_estado_nombre']; ?>
              </td>
              <td><?php echo $value['comentarios']; ?></td>
              <td><?php echo $value['fec_registro']; ?></td>
            </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
<?php } ?>

<input type="hidden" id="poliza_id" name="poliza_id" value="<?php echo $poliza_id; ?>"/>
<input type="hidden" id="correo_afianzado" name="correo_afianzado" value="<?php echo $filapoliza["email"]; ?>"/>

<div id="popUpPoliza" align="center">
  <img src="images/spinner.gif"/><br>Guardando datos . . .
</div>
<br/>
<div align="center">
  <?php if ($filapoliza['poliza_estado_id'] == 1 || $filapoliza['poliza_estado_id'] == 3) { ?>
    <button class="btn btn-info" id="btnAprobar" onclick="javascript:validarPoliza(<?php echo $poliza_id; ?>);">Aprobar</button>
    <button class="btn btn-info" id="btnRechazar" >Rechazar</button>
    <button class="btn btn-info" id="btnReqInfo" >Requiere más información</button>
  <?php
  }
  if ($filapoliza['poliza_estado_id'] == 6) {
    ?>
    <button class="btn btn-info" id="btnCargarArchivo" >Cargar archivos emitidos</button>
    <button class="btn btn-info" id="btnReqInfo" >Requiere más información</button>
    <button class="btn btn-info" id="btnRechazar" >Rechazar</button>
  <?php
  }
  if ($filapoliza['poliza_estado_id'] == 5 || $filapoliza['poliza_estado_id'] == 2) {
    ?>
    <button class="btn btn-info" id="btnConfirmarPago" >Confirmar pago</button>
<?php } ?>  
</div>


<div id="popUpAseguradora" align="center">
  <div id="aseguradoras" style="display: none;">
<?php foreach ($aseguradoras as $key => $value) { ?>
      <input type='checkbox' name='check_aseg' id='ck_aseg_<?php echo $value['aseguradora_id']; ?>' value='<?php echo $value['aseguradora_id']; ?>'/> <b id="nombre_aseguradora_<?php echo $value['aseguradora_id']; ?>"><?php echo $value['aseguradora_nombre']; ?></b><br/>
      <input type='checkbox' name='req_sarlaft' id='req_sarlaft_<?php echo $value['aseguradora_id']; ?>' value='S'/> <b>Requiere sarlaft</b><br/>
      <table class="form-table corner-round tablesorter" align="center">
        <thead>
          <tr>
            <th>Garantia</th>
            <th style="text-align: right;">Total asegurado</th>
            <th style="text-align: right;">Prima</th>
            <th style="text-align: right;">Gastos expedición</th>
            <th style="text-align: right;">Impuesto</th>
          </tr>
        </thead>
        <tbody>
          <?php
          foreach ($garantias as $valor) {
            ?>
            <tr>
              <td>
    <?php echo $valor['garantia_nombre']; ?>
                <input type="hidden" name="garantia_id_<?php echo $value['aseguradora_id']; ?>" value="<?php echo $valor['garantia_id']; ?>"/>
                <input type="hidden" id="garantia_nombre_<?php echo $value['aseguradora_id'] . '_' . $valor['garantia_id']; ?>" value="<?php echo $valor['garantia_nombre']; ?>"/>
              </td>
              <td style="text-align: right;">
                <img src="images/b_add.png" onload="javascript:cargarTotalGarantia(<?php echo $value['aseguradora_id']; ?>,<?php echo $valor['garantia_id']; ?>)" width="0" height="0"/>
                <span id="txt_asegurado_total_<?php echo $value['aseguradora_id'] . '_' . $valor['garantia_id']; ?>"></span>
                <input type="hidden" name="asegurado_total" id="asegurado_total_<?php echo $value['aseguradora_id'] . '_' . $valor['garantia_id']; ?>">
              </td>
              <td style="text-align: right;">
                <input type="text" name="valor_prima" id="valor_prima_<?php echo $value['aseguradora_id'] . '_' . $valor['garantia_id']; ?>" onkeyup="javascript:calcularIVA(<?php echo $value['aseguradora_id']; ?>,<?php echo $valor['garantia_id']; ?>);" style="width: 60%; text-align: right;"/>
              </td>
              <td style="text-align: right;">
                <input type="text" name="gastos_expedicion" id="gastos_expedicion_<?php echo $value['aseguradora_id'] . '_' . $valor['garantia_id']; ?>" onkeyup="javascript:calcularIVA(<?php echo $value['aseguradora_id']; ?>,<?php echo $valor['garantia_id']; ?>);" style="width: 35%; text-align: right;"/>
              </td>
              <td style="text-align: right;">
                <input type="text" name="iva" id="iva_<?php echo $value['aseguradora_id'] . '_' . $valor['garantia_id']; ?>" style="width: 35%; text-align: right;"/>
              </td>
            </tr>
  <?php } ?>
        </tbody>
        <tbody>
          <tr>
            <td>
              Observaciones
            </td>
            <td colspan="4" style="text-align: center;">
              <textarea name="obser_aseg" id="obser_aseg_<?php echo $value['aseguradora_id']; ?>" rows="3" style="width: 90%"></textarea>
            </td>
          </tr>
          <tr>
            <td colspan="5" style="text-align: right;">
              Tiempo promedio de entrega &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              Minutos:
              <input type="text" name="min" id="min_<?php echo $value['aseguradora_id']; ?>" style="width: 35px;">
              &nbsp;&nbsp;&nbsp;&nbsp;
              Horas:
              <input type="text" name="hora" id="hora_<?php echo $value['aseguradora_id']; ?>" style="width: 35px;">
              &nbsp;&nbsp;&nbsp;&nbsp;
              Días:
              <input type="text" name="dia" id="dia_<?php echo $value['aseguradora_id']; ?>" style="width: 35px;">
            </td>
          </tr>
        </tbody>
      </table>
      <br/>
<?php } ?>
  </div>

  <div id="confirmarPago" style="display: none;">
    <br/>
    <table align="center" width="80%">
      <tbody>
        <tr>
          <td>
            <label>Opciones pago</label>
          </td>
          <td>
            <select id="metodo_pago_id" >
              <?php echo $mySQL->get_options_from_query('metodo_pago', 'metodo_pago_id', 'metodo_pago_nombre', '', 'metodo_pago_nombre', '', false); ?>
            </select>
          </td>
        </tr>
        <tr>
          <td>
            <label>Seleccione la aseguradora:</label>
          </td>
          <td>
            <select id="aseguradora_id" >
              <?php echo $mySQL->get_options_from_query('poliza_aseguradora INNER JOIN aseguradora USING (aseguradora_id) INNER JOIN garantia using (garantia_id)', 'aseguradora_id', 'aseguradora_nombre', "poliza_id = $poliza_id", 'aseguradora_nombre', '', false); ?>
            </select>
          </td>
        </tr>
      </tbody>
    </table>
    <br/>
    <br/>
  </div>

  <fieldset>
    <legend>Observaciones</legend>
    <table align="center" width="80%">
      <tbody>
        <tr>
          <td>
            <textarea id="observaciones" name="observaciones" style="width: 60%;margin-left: 20%; margin-right: 20%;" rows="6"></textarea>
            <input type="hidden" id="estado" name="estado">
          </td>
        </tr>
      </tbody>
    </table>
  </fieldset>
  <div id="divPolizaMessage"></div>
  <hr>
  <center>
    <button class="btn btn-info" id="btnGuardar">Guardar</button>
    <button class="btn btn-default" id="btnCancelar">Cancelar</button>
  </center>
</div>

<div id="popUpDepartamento" align="center">
  <form enctype='MULTIPART/form-data' method= "post">
    <table>
      <tr>
        <td style="text-align: right;">Lugar de expedicion de la poliza:</td>
        <td><input type="text" id="municipio_nombre_poliza"/></td>
        <td><input type="hidden" id="municipio_id_poliza"/></td>
      </tr>
    </table>
    <hr/>
    <div id="divEditDepartamentoMessage"></div>
    <br/>
    <button class="btn btn-info" id="btnGuardarDepartamento">Guardar</button>
    <button class="btn btn-default" id="btnCancelarDepartamento">Cancelar</button>
  </form>
</div>

<div id="popUpinfoPoliza" align="center">
  <input type="hidden" id="valor_contrato_info_def" value="<?php echo $filapoliza["valor_contrato"]; ?>"/>
  <input type="hidden" id="valor_anticipo_info_def" value="<?php echo $filapoliza["valor_anticipo"]; ?>"/>
  <input type="hidden" id="ref_contrato_def" value="<?php echo $filapoliza["ref_contrato"] ?>"/>
  <input type="hidden" id="motivo_poliza_def" value="<?php echo $filapoliza["giro_negocio_id"]; ?>"/>
  <input type="hidden" id="objeto_def" value="<?php echo $filapoliza["objeto"]; ?>"/>
  <input type="hidden" id="sector_def" value="<?php echo $filapoliza["sector_id"]; ?>"/>
  <div class="col-md-12">
    Datos del contrato
    <br/>
    <br/>
    <table class="table" style="width: 100%;">
      <tr>
        <td style="width: 25%;">
          Valor: <input type="text" id="valor_contrato_info" style="width: 150px; text-align: right;" value="<?php echo $filapoliza["valor_contrato"]; ?>"/>
        </td>
        <td style="width: 25%;" align="right">
          Anticipo: <input type="text" id="valor_anticipo_info" style="width: 150px; text-align: right;" value="<?php echo $filapoliza["valor_anticipo"]; ?>"/>
        </td>
        <td style="width: 25%;" align="left">
          <input type="radio" name="tipo_anticipo" id="tipo_anticipo" value="P" checked> Porcentaje del valor del contrato 
          <br/>
          <input type="radio" name="tipo_anticipo" id="tipo_anticipo" value="F"> Valor fijo
        </td>
        <td style="width: 25%;">
          Referencia: <input type="text" id="ref_contrato" style="width: 150px; text-align: right;" value="<?php echo $filapoliza["ref_contrato"] ?>"/>
        </td>
      </tr>
      <tr>
        <td colspan="4">
          Sector: 
          <select id="sector" style="width: 95%">
            <option value="">Selecccione ...</option>
<?php echo $mySQL->get_options_from_query('sector', 'sector_id', 'sector_nombre', "sector_activo = 'S'"); ?>
          </select>
        </td>
      </tr>
      <tr>
        <td colspan="4">
          Motivo o giro del negocio: 
          <select id="motivo_poliza" style="width: 95%">
            <option value="">Selecccione ...</option>
<?php echo $mySQL->get_options_from_query('giro_negocio', 'giro_negocio_id', 'giro_negocio_nombre', "giro_negocio_activo = 'S'"); ?>
          </select>
        </td>
      </tr>
      <tr>
        <td colspan="4">
          Objeto del contrato: <textarea id="objeto" style="width: 95%; height: 100px;"><?php echo $filapoliza["objeto"]; ?></textarea>
        </td>
      </tr>
    </table>
    <br/>
    <div id="divEditinfoPolizaMessage"></div>
    <center class="col-md-8 col-md-offset-2">
      <hr>
      <button class="btn btn-info" id="btnGuardarInfopliza">Guardar</button>
      <button class="btn btn-default" id="btnCancelarInfopliza">Cancelar</button>
    </center>
    <br/>
    <br/>
  </div>
</div>

<div id="popUpAfianzados" align="center">
  <form enctype='MULTIPART/form-data' method= "post">
    <input type="hidden" id="afi_nombre_def" value="<?php echo $filapoliza["nombres"]; ?>"/>
    <input type="hidden" id="afi_tipo_documento_def" value="<?php echo $filapoliza["tipo_documento_id"]; ?>"/>
    <input type="hidden" id="afi_identificacion_def" value="<?php echo $filapoliza["identificacion"]; ?>"/>
    <input type="hidden" id="afi_digit_ver_def" value="<?php echo $filapoliza["digit_ver"]; ?>"/>
    <input type="hidden" id="municipio_nombre_def" value="<?php echo $filapoliza["lug_res_afi_text"]; ?>"/>
    <input type="hidden" id="municipio_id_def" value="<?php echo $filapoliza["lug_res_afi"]; ?>"/>
    <input type="hidden" id="afi_direccion_def" value="<?php echo $filapoliza["direccion"]; ?>"/>
    <input type="hidden" id="afi_telefono_def" value="<?php echo $filapoliza["telefono"]; ?>"/>
    <input type="hidden" id="afi_email_def" value="<?php echo $filapoliza["email"]; ?>"/>
    <table>
      <tr>
        <td style="text-align: right;">* Nombre Completo o Razón Social:</td>
        <td><input type="text" id="afi_nombre" value="<?php echo $filapoliza["nombres"]; ?>"/></td>
      </tr>
      <tr>
        <td style="text-align: right;">* Tipo de documento:</td>
        <td>
          <select id="afi_tipo_documento" style="width: auto;">
<?php echo $mySQL->get_options_from_query('tipo_documento', 'tipo_documento_id', 'tipo_documento_nombre', '', 'tipo_documento_nombre', '', true); ?>
          </select>
        </td>
      </tr>
      <tr>
        <td style="text-align: right;">* Número de identificación:</td>
        <td><input type="text" id="afi_identificacion" value="<?php echo $filapoliza["identificacion"]; ?>"/></td>
      </tr>
      <tr>
        <td style="text-align: right;">* Dígito de verificación:</td>
        <td><input type="text" id="afi_digit_ver" value="<?php echo $filapoliza["digit_ver"]; ?>" style="width: 15%;"/></td>
      </tr>
      <tr>
        <td style="text-align: right;">* Ciudad de residencia:</td>
        <td><input type="text" id="municipio_nombre" value="<?php echo $filapoliza["lug_res_afi_text"]; ?>"/></td>
        <td><input type="hidden" id="municipio_id" value="<?php echo $filapoliza["lug_res_afi"]; ?>"/></td>
      </tr>
      <tr>
        <td style="text-align: right;">* Dirección:</td>
        <td><input type="text" id="afi_direccion" value="<?php echo $filapoliza["direccion"]; ?>"/></td>
        <td><input type="hidden" id="afi_tercero_id"/></td>
      </tr>
      <tr>
        <td style="text-align: right;">* Teléfono:</td>
        <td><input type="text" id="afi_telefono" value="<?php echo $filapoliza["telefono"]; ?>"/></td>
      </tr>
      <tr>
        <td style="text-align: right;">* Correo electrónico:</td>
        <td><input type="text" id="afi_email" value="<?php echo $filapoliza["email"]; ?>"/></td>
      </tr>
    </table>
    <hr/>
    <div id="divEditAfianzadosMessage"></div>
    <br/>
    <br/>
    <button class="btn btn-info" id="btnGuardarAfianzado">Guardar</button>
    <button class="btn btn-default" id="btnCancelarAfianzado">Cancelar</button>
  </form>
</div>

<div id="popUpAsegurado" align="center">
  <form enctype='MULTIPART/form-data' method= "post">
    <table>
      <tr>
        <td style="text-align: right;">* Nombre Completo o Razón Social:</td>
        <td><input type="text" id="AsBe_nombre"/></td>
      </tr>
      <tr>
        <td style="text-align: right;">* Tipo de documento:</td>
        <td>
          <select id="AsBe_tipo_documento" style="width: auto;">
<?php echo $mySQL->get_options_from_query('tipo_documento', 'tipo_documento_id', 'tipo_documento_nombre', '', 'tipo_documento_nombre', '', true); ?>
          </select>
        </td>
      </tr>
      <tr>
        <td style="text-align: right;">* Número de identificación:</td>
        <td><input type="text" id="AsBe_identificacion"/></td>
      </tr>
      <tr>
        <td style="text-align: right;">* Dígito de verificación:</td>
        <td><input type="text" id="AsBe_digit_ver" style="width: 15%;"/></td>
      </tr>
      <tr>
        <td style="text-align: right;">Ciudad de residencia:</td>
        <td><input type="text" id="AsBe_municipio_nombre"/></td>
        <td><input type="hidden" id="AsBe_municipio_id"/></td>
      </tr>
      <tr>
        <td style="text-align: right;">Dirección:</td>
        <td><input type="text" id="AsBe_direccion"/></td>
        <td><input type="hidden" id="AsBe_poliza_asegurado_id"/></td>
      </tr>
      <tr>
        <td style="text-align: right;">Teléfono:</td>
        <td><input type="text" id="AsBe_telefono"/></td>
      </tr>
      <tr>
        <td style="text-align: right;">Correo electrónico:</td>
        <td><input type="text" id="AsBe_email"/></td>
      </tr>
      <tr>
        <td style="text-align: center;" align= "center" colspan="2">
          <input type="checkbox" id="asegurado" name="tipoPer" value="true"> Asegurado
          <input type="checkbox" id="beneficiario" name="tipoPer" value="true"> Beneficiario
        </td>
      </tr>
    </table>
    <hr/>
    <div id="divEditAsegBeneMessage"></div>
    <br/>
    <br/>
    <button class="btn btn-info" id="btnGuardarAsegurados">Guardar</button>
    <button class="btn btn-default" id="btnCancelarAsegurados">Cancelar</button>
  </form>
</div>

<div id="popUpDocumentos" align="center">
  Ahora debe cargar los documentos necesarios para la expedición de la póliza<br/>
  Usted debe incluir al menos 2 documentos:  La copia del contrato y la identificación del afianzado.
  <br/>
  <br/>
  <div style="color:#fff; height: auto;" class="container-fluid">

    <div id="seccion1" align="center" class="row">
      <div class="col-md-10 col-md-offset-1 col-sm-11 corner-round box-shadow section-blue" style="height: auto;">
        <br/>
        <br/>
        Carga de documentos
        <br/>
        <br/>
        <form id="formCarga">
          <input type="hidden" name="action" value="cargarAdjunto"/>
          <table class="table">
            <tbody>
              <tr>
                <td>
                  Seleccione el archivo
                </td>
                <td>
                  <input type="file" name="archivo" id="archivo" accept="image/*,application/pdf" capture="camera"/>
                </td>
              </tr>
              <tr>
                <td>
                  Descripción
                </td>
                <td>
                  <input type="text" name="descripcion" id="descripcion"/>
                </td>
              </tr>
            </tbody>
          </table>
        </form>
        <br/>
        <br/>
        <div style="width: 100%; text-align: center;">
          <button class="btn btn-default section-green" onclick="javascript:cargarAdjunto('E');">Cargar Archivo</button>
        </div>
        <br/>
        <div id="divEditMessage" style="width: 100%; text-align: center;"></div>
        <br/>
        <br/>
      </div>
    </div>
    <br/>
    <br/>
    <div id="seccion1" align="center" class="row">
      <div class="col-md-10 col-md-offset-1 col-sm-11 corner-round box-shadow section-green" style="height: auto;">
        <br/>
        <br/>
        Documentos Cargados
        <br/>
        <br/>
        <div id="listaDocumentos">
          <table class="table">
            <tbody id="tbodyAdjuntos"></tbody>
          </table>
        </div>
        <br/>
        <br/>
        <div id="divDocumentosMessage" style="width: 100%; text-align: center;"></div>
        <br/>
        <div style="width: 100%; text-align: center;">
          <button class="btn btn-default section-blue" id="btnCancelarDocumentos">Cerrar</button>
        </div>
        <br/>
        <br/>
      </div>
    </div>
  </div>
</div>

<div id="popUpFechas" align="center">
  <input type="hidden" id="fec_contrato_def" value="<?php echo $filapoliza["fec_contrato"]; ?>"/>
  <input type="hidden" id="fec_inicio_def" value="<?php echo $filapoliza["fec_inicio"]; ?>"/>
  <input type="hidden" id="duracion_periodo_def" value="<?php echo $filapoliza["duracion_periodo"]; ?>"/>
  <input type="hidden" id="periodo_tiempo_id_def" value="<?php echo $filapoliza["periodo_tiempo_id"]; ?>"/>
  <input type="hidden" id="fec_final_def" value="<?php echo $filapoliza["fec_final"]; ?>"/>
  <input type="hidden" id="dias_def" value="<?php echo $filapoliza["dias"]; ?>"/>
  <input type="hidden" id="meses_def" value="<?php echo $filapoliza["meses"]; ?>"/>
  <input type="hidden" id="anios_def" value="<?php echo $filapoliza["anios"]; ?>"/>
  <br/>
  <br/>
  <div class="row">
    <div class="col col-md-6 form-group">
      <label>Fecha de la firma del contrato: </label>
      <input type="text" id="fec_contrato" class="form-control" value="<?php echo (!empty($filapoliza["fec_contrato"]) ? $filapoliza["fec_contrato"] : date('Y-m-d')); ?>"/>
    </div>
    <div class="col col-md-6 form-group">
      <label>Inicio de Ejecución: </label>
      <input type="text" id="fec_inicio" class="form-control" value="<?php echo (!empty($filapoliza["fec_inicio"]) ? $filapoliza["fec_inicio"] : date('Y-m-d')); ?>"/>
    </div>
  </div>
  <div class="row">
    <div class="col col-md-4 form-group">
      <label>Días: </label>
      <input type="text" id="dias_contrato" placeholder="Duración en días" style="text-align: right;" class="form-control"/>
    </div>
    <div class="col col-md-4 form-group">
      <label>Meses: </label>
      <input type="text" id="meses_contrato" placeholder="Duración en meses" style="text-align: right;" class="form-control"/>
    </div>
    <div class="col col-md-4 form-group">
      <label>Años: </label>
      <input type="text" id="anios_contrato" placeholder="Duración en años" style="text-align: right;" class="form-control"/>
    </div>
  </div>
  <div class="row">
    <div class="col col-md-6 form-group">
      <label>Final de Ejecución: : </label>
      <input type="text" id="fec_final" class="form-control" value="<?php echo $filapoliza["fec_final"]; ?>"/>
    </div>
  </div>
  <div id="divMensaje" style="width: 100%; text-align: center;"></div>
  <div style="width: 100%; text-align: center;">
    <br/>
    <button class="btn btn-info" id="btnGuardarFechas" onclick="javascript:actualizarFechas();">Guardar</button>
    <button class="btn btn-default" id="btnCancelarFechas">Cancelar</button>
  </div>
  <br/>
</div>

<div id="popUpCargarArchivos" align="center">
  <input type="hidden" id="req_sarlaft" value="<?php echo $aseg_selec[0]['req_sarlaft']; ?>">
  <div style="color:#fff; height: auto;" class="container-fluid">
    <div id="seccion1" align="center" class="row">
      <div id="cargarDocs" style="display: block;">
        Ahora debe cargar los documentos emitidos por la aseguradora.
        <br/>
        <br/>
        <div class="col-md-12 corner-round box-shadow section-blue" style="height: auto;">
          <br/>
          <br/>
          Carga de documentos
          <br/>
          <br/>
          <form id="formCarga">
            <input type="hidden" name="action" value="cargarAdjunto"/>
            <table class="table">
              <tbody>
                <tr>
                  <td>
                    Seleccione el archivo
                  </td>
                  <td>
                    <input type="file" name="archivoEmitido" id="archivoEmitido" accept="image/*,application/pdf" capture="camera"/>
                  </td>
                </tr>
                <tr>
                  <td>
                    Descripción
                  </td>
                  <td>
                    <input type="text" name="descripcionEmitido" id="descripcionEmitido"/>
                  </td>
                </tr>
              </tbody>
            </table>
          </form>
          <br/>
          <br/>
          <div style="width: 100%; text-align: center;">
            <button class="btn btn-default section-green" onclick="javascript:cargarEmitidos('S');">Cargar Archivo</button>
          </div>
          <br/>
          <div id="divEditMessageEmitido" style="width: 100%; text-align: center;"></div>
          <br/>
          <br/>
          <!--ss-->
          <br/>
          <br/>
          Documentos Cargados
          <br/>
          <br/>
          <div id="listaDocumentos">
            <table class="table">
              <tbody id="tbodyAdjuntos2"></tbody>
            </table>
          </div>
          <br/>
          <br/>
          <div id="divDocumentosMessage" style="width: 100%; text-align: center;"></div>
          <br/>
          <!--ss-->
        </div>
      </div>

      <div id="cargarCod" style="display: none;">
        <div class="col-md-12 corner-round box-shadow section-green" style="height: auto;">
          <br/>
          <br/>
          <!--tutulo pendiente-->
          <br/>
          <br/>
          <form>
<?php foreach ($aseg_selec as $key => $value) { ?>
              <fieldset>
                <legend><?php echo $value['garantia_nombre']; ?></legend>
                <input type="hidden" id="poliza_aseguradora" name="poliza_aseguradora" value="<?php echo $value['poliza_aseguradora_id']; ?>">
                <input type="hidden" id="garantia_nombre_<?php echo $value['poliza_aseguradora_id']; ?>" name="garantia_nombre" value="<?php echo $value['garantia_nombre']; ?>">
                <table class="table">
                  <tbody>
                    <tr>
                      <td>
                        Código de la póliza
                      </td>
                      <td>
                        <input type="text" name="cod_poliza" id="cod_poliza_<?php echo $value['poliza_aseguradora_id']; ?>" value="<?php echo $value['cod_poliza']; ?>"/>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Fecha de emisión
                      </td>
                      <td>
                        <input type="text" name="fec_poliza" id="fec_poliza_<?php echo $value['poliza_aseguradora_id']; ?>" value="<?php echo (empty($value["fec_poliza"]) ? date('Y-m-d') : $value["fec_poliza"]); ?>"/>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </fieldset>
              <br/>
<?php } ?>
          </form>
          <br/>
          <br/>
          <div style="width: 100%; text-align: center;">
            <button class="btn btn-default section-blue" id="btnGuardarCodPol">Guardar</button>
          </div>
          <br/>
          <div id="divEditMessageCodPol" style="width: 100%; text-align: center;"></div>
          <br/>
          <br/>
        </div>
      </div>

      <div id="divObserv" style="display: none;">
        <div class="col-md-12 corner-round box-shadow section-blue" style="height: auto;">
          <br/>
          <br/>
          <legend>Observaciones</legend>
          <br/>
          <br/>
          <table align="center" width="80%">
            <tbody>
              <tr>
                <td>
                  <textarea id="observacionesEmitida" name="observacionesEmitida" style="width: 100%;" rows="6"></textarea>
                </td>
              </tr>
            </tbody>
          </table>
          <br/>
          <br/>
        </div>>
      </div>
    </div>
    <br/>
    <br/>
    <div style="width: 100%; text-align: center;">
      <button id="btnCancelarCargarArchivos" class="btn btn-default section-blue">Cancelar</button>
      <button class="btn btn-default section-blue" id="btnSiguiente1">Siguiente</button>
      <button class="btn btn-default section-blue" id="btnSiguiente2" style="display: none;">Siguiente</button>
      <button class="btn btn-default section-blue" id="btnCancelarArchivo" style="display: none;">Cerrar y Notificar</button>
    </div>
  </div>
</div>

<div id="divAmparos">
  <table class="table">
    <thead>
      <tr>
        <th>Amparo</th>
        <th>Valor o Porcentaje</th>
        <th>Liquidación</th>
      </tr>
    </thead>  
    <tbody>
      <tr>
        <td>
          <select id="amparos" style="background-color: transparent;" onchange="javascript:mostrarFechaInicio('<?php echo $filapoliza["fec_inicio"]; ?>', '<?php echo $filapoliza["fec_final"]; ?>');">
            <option value="">Selecccione ...</option>
            <?php
            if (!empty($filapoliza["sector_id"])) {
              echo $mySQL->get_options_from_query('amparo INNER JOIN tipo_amparo USING (tipo_amparo_id) INNER JOIN garantia ON (garantia.garantia_id = amparo.garantia_id AND garantia_activo = "S")', 'amparo_id', 'amparo_nombre', 'amparo_activo = "S" AND garantia.sector_id = ' . $filapoliza["sector_id"], '');
            }
            ?>
          </select>
        <td>
          <input type="text" id="valor_amparo"  style="text-align: right;" onkeyup="javascript:calcularValorAsegurado();"/>
        </td>
        <td>
<?php echo $tipo_liqui; ?>
        </td>
      </tr>
    </tbody>
    <tbody>
      <tr>
        <td colspan="3">
          <div class="col col-md-4">
            <label>Días: </label><br>
            <input type="text" id="dias" placeholder="Duración en días" style="text-align: right;"/>
          </div>
          <div class="col col-md-4">
            <label>Meses: </label><br>
            <input type="text" id="meses" placeholder="Duración en meses" style="text-align: right;"/><br>
          </div>
          <div class="col col-md-4">
            <label>Años: </label><br>
            <input type="text" id="anios" placeholder="Duración en años" style="text-align: right;"/>
          </div>
          <br/>
          <br/>
          <div class="col col-md-12">
            <label>Fecha de finalización o Vigencia adicional: </label><br>
            <input type="text" id="fec_final_amparo">
            <br/>
            <span>Si no conoce la finalización de la vigencia o no ha sido <br/>definida por favor deje este campo en blanco.</span>
          </div>
        </td>
      </tr>
    </tbody>
    <thead>
      <tr>
        <th colspan="2">Vigencia Inicial</th>
        <th>Valor Asegurado</th>
    </thead>
    <tbody>
      <tr>
        <td colspan="2">
          <span id="fechaInicial"></span><input type="hidden" id="fec_inicio"/>
        </td>
        <td style="text-align: right;">
          <span id="spanValAseg"></span>
          <input type="hidden" id="hiddenValAseg"/>
          <input type="hidden" id="poliza_amparo_id"/>
        </td>
      </tr>
    </tbody>
  </table>
  <br/><div id="divEditAmparosMessage" style="text-align: center;"></div>
  <center>
    <hr> 
    <button class="btn btn-info" id="btnGuardarAmparo" onclick="javascript:guardarAmparos();">Guardar</button>
    <button class="btn btn-default" id="btnCancelarAmparo" onclick="javascript:cerrarPopUpAmparos();">Cancelar</button> 
  </center>
</div>

<div id="eliminarAmparo" style="display: none;">
  ¿esta seguro que desea eliminar este amparo?
</div>

<div id="inactivarDocumento" style="display: none;">
  ¿esta seguro que desea <span id="texto2"></span> este documento?
</div>

<div id="eliminarAsegurado" style="display: none;">
  ¿esta seguro que desea eliminar este <span id="texto"></span>?
</div>

<div id="eliminarGarantia" style="display: none;">
  ¿esta seguro que desea eliminar esta garantia de la poliza?
</div>

<div id="validacionPoliza" style="display: none;">
  <span id="errores"></span>
</div>

<div id="alertaBeneficiarios" style="display: none;">
  Esta póliza no cuenta con beneficiarios,<br/>
  ¿esta seguro que quiere continuar?
</div>

<div id="alertaSarlaft" style="display: none;">
  Esta póliza requiere Sarlaft o FUCC del afianzado,<br/>
  ¿esta seguro que ya dispone de dicho documento? 
</div>

<script type="text/javascript">
  //
  if ('<?php echo $filapoliza["tipo_anticipo"]; ?>' == 'P') {
    $('#tipo_anticipo[value=P]').prop("checked", true);
  } else if ('<?php echo $filapoliza["tipo_anticipo"]; ?>' == 'F') {
    $('#tipo_anticipo[value=F]').prop("checked", true);
  }
  //
  $('#motivo_poliza').val(<?php echo $filapoliza["giro_negocio_id"]; ?>);
  //
  $('#afi_tipo_documento').val(<?php echo $filapoliza["tipo_documento_id"]; ?>);
  //
  $('#periodo_tiempo_id').val(<?php echo $filapoliza["periodo_tiempo_id"]; ?>);
</script>