<script type="text/javascript" src="js/polizas_finalizadas.js?time<?php echo time(); ?>"></script>
<fieldset>
  <legend>Consulta de resultados</legend>
  <form class="form-inline">
    <div class="form-group">
      <label for="identificacion">Identificación:</label>
      <input type="text" class="form-control" id="identificacion">
    </div>
    <div class="form-group">
      <label for="ref_contrato">ref_contrato:</label>
      <input type="text" class="form-control" id="ref_contrato">
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="text" class="form-control" id="email">
    </div>
    <div class="form-group">
      <label for="estado_id">Estado:</label>
      <select id="estado_id" name="tipo_docu_id" class="form-control">
        <option value="">Seleccione...</option>
        <option value="3">Rechazada</option>
        <option value="7">Emitida</option>
      </select>
    </div>
  </form>
  <br/>
  <br/>
  <div align="center">
    <input type="button" class="btn btn-info" value="Filtrar" id="Filtrar"/>
  </div>
  <br/>
  <div id="divListaPolizas" style="width: 70%;"></div>
</fieldset>

