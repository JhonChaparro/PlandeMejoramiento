<script type="text/javascript" src="js/polizas_tramite.js?time=<?php echo time(); ?>"></script>

<audio id="audio">
  <source src="Osmium.ogg" type="audio/ogg">
</audio>
<div class= "datagrid">
  <legend>Pólizas en trámite</legend>
  <div id="divPolizasTramite"></div>
</div>
<br/>
<br/>
<br/>
<div class= "datagrid">
  <legend>Pólizas con falta de documentos</legend>
  <div id="divPolizasNoDoc"></div>
</div>
<br/>
<br/>
<span id="spTimer" style="color: red;"></span>
