<script type="text/javascript" src="js/reporte_emicion.js?time=<?php echo time(); ?>"></script>
<div class="alert alert-info" style="margin:10px;">
  <table>
    <tr>
      <td>
        <label>Fecha de creación de la póliza</label>
      </td>
    </tr>
    <tr> 
      <td>
        <label>Desde:</label>
      </td>
      <td>
        &nbsp;&nbsp;
      </td>
      <td>
        <label>Hasta:</label>
      </td>
    </tr>
    <tr>
      <td> 
        <input type="text" name="fec_inicio_crea" class="form-control" id="fec_inicio_crea" style="color: #000;" />
      </td>
      <td>
        &nbsp;&nbsp;
      </td>
      <td>
        <input type="text" name="fec_final_crea" class="form-control" id="fec_final_crea" style="color: #000;"/>
      </td>
    </tr>
  </table>
  <br/>
  <table>
    <tr>
      <td>
        <label>Fecha de expedición de la póliza</label>
      </td>
    </tr>
    <tr>
      <td>
        <label>Desde:</label>
      </td>
      <td>
        &nbsp;&nbsp;
      </td>
      <td>
        <label>Hasta:</label>
      </td>
    </tr>
    <tr>
      <td> 
        <input type="text" name="fec_inicio_exp" class="form-control" id="fec_inicio_exp" style="color: #000;" />
      </td>
      <td>
        &nbsp;&nbsp;
      </td>
      <td>
        <input type="text" name="fec_final_exp" class="form-control" id="fec_final_exp" style="color: #000;"/>
      </td>
    </tr>
  </table>
  <br/>
  <table style="width: 400px;">
    <tr>
      <td>
        <label>Aseguradora:</label>
      </td>
    </tr>
    <tr>
      <td>
        <select id="aseguradora_id" style="width: auto;">
          <option value=''>Todas </option>
          <?php echo $mySQL->get_options_from_query('aseguradora', 'aseguradora_id', 'aseguradora_nombre', "aseguradora_activo = 'S'", 'aseguradora_nombre', '', false); ?>
        </select>
      </td>
      <td>
        &nbsp;&nbsp;&nbsp;&nbsp;
      </td>
    </tr>
  </table>
</div>
<center>
  <button class="btn btn-info" id="btnBuscar" style="font-size: 18px;">Buscar</button>
</center>
<div id="divReportEmitidas" style="width: 70%"></div>