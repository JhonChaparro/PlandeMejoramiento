<script type="text/javascript" src="js/rol.js?time=<?php echo time(); ?>"></script>
<div class="title">Control de roles</div>
<br/>
<br/>
<a href="javascript:editarRol('nuevo');"><img src='images/b_add.png'/></a>
<br/>
<input type="text" id="textBusqueda"/><button id="btnBusqueda"><img src="images/b_search.png"/></button>
<div id="divListaRol"></div>
<div id="divEditRol" style="display:none" align="center">
  <form enctype='MULTIPART/form-data' method= "post" action="usuariog">
    <input type="hidden" id="rol_id"/>
    <table>
      <tr>
        <td style="text-align: right;">* Nombre:</td>
        <td><input type="text" id="rol_nombre" style="width: 140%;"/></td>
      </tr>	
    </table>
    <table class="tablesorter">
      <thead>
        <tr>
          <th>Administrativo</th>
          <th>Operativo</th>
          <th>Reportes</th>
        </tr>  
      </thead>
      <tbody>
        <tr>
          <td style="vertical-align: top;">
            <?php echo $mySQL->set_checkbox_from_query('opcion', 'opcion_id', 'opcion_nombre', 'menu_id=1', 'opcion_id', '', true, 'opcion_orden'); ?>
          </td>
          <td style="vertical-align: top;">
            <?php echo $mySQL->set_checkbox_from_query('opcion', 'opcion_id', 'opcion_nombre', 'menu_id=2', 'opcion_id', '', true, 'opcion_orden'); ?>
          </td>
          <td style="vertical-align: top;">
            <?php echo $mySQL->set_checkbox_from_query('opcion', 'opcion_id', 'opcion_nombre', 'menu_id=3', 'opcion_id', '', true, 'opcion_orden'); ?>
          </td>
        </tr>
      </tbody>
    </table>
    <hr/>
    <div id="divEditRolMessage"></div>
    <br/>
    <br/>
    <button class="btn btn-info" id="btnGuardar">Guardar</button>
    <button class="btn btn-default" id="btnCancelar">Cancelar</button>
  </form>  
</div>

