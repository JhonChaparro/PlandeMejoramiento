<?php
//     DESCRIPCION:	Programa para ingresar, editar y deshabilitar los sector
//         VERSION:	1.0
//           AUTOR:	NETStudio
//           FECHA:	2016-03-22
//
//  MODIFICACIONES:
//
//
?>
<script type="text/javascript" src="js/sector.js?time=<?php echo time(); ?>"></script>
<div class="title">Control de Sectores</div>
<br/>
<br/>
<input type="text" id="textBusqueda"/><button class="btn btn-default" id="btnBusqueda">Buscar <img src="images/b_search.png"/></button><button class="btn btn-default" id="btnBusqueda" onclick="javascript:editarSector('nuevo');">Nuevo Sector <img src="images/b_add.png"/></button> 
<div id="divListaSectores"></div>
<div id="divEditSectores" align="center">
  <form enctype='MULTIPART/form-data' method= "post">
    <table>
      <tr>
        <td style="text-align: right;">* Nombre:</td>
        <td><input type="text" id="sector_nombre"/></td>
      </tr>	
      <tr>
        <td style="text-align: right;">* Descripción:</td>
        <td><textarea cols="30" rows="3" id="sector_desc"></textarea></td>
      </tr>	
      <input type="hidden" id="sector_id" name="sector_id"/>
    </table>
    <hr/>
    <div id="divEditSectoresMessage"></div>
    <br/>
    <br/>
    <button class="btn btn-info" id="btnGuardar">Guardar</button>
    <button class="btn btn-default" id="btnCancelar">Cancelar</button>
  </form>
  <div id="divEditSectoresMessage"></div>
</div>