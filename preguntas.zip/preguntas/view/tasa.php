<script type="text/javascript" src="js/tasa.js?time=<?php echo time(); ?>"></script>
<div class="title">Control de tasas por aseguradora</div>
<br/>
<br/>
<table style="width: 40%;">
  <tr>
    <td style="text-align: right;">
      * Aseguradora : 
    </td>
    <td>
      <select id="aseguradora_id" onchange="javascript:borrarRegistros();">
        <option value="">Seleccione ...</option>
        <?php echo $mySQL->get_options_from_query('aseguradora', 'aseguradora_id', 'aseguradora_nombre', "aseguradora_activo = 'S'")?>
      </select>
    </td>
  </tr>
  <tr>
    <td style="text-align: right;">
      * Garantia : 
    </td>
    <td>
      <select id="garantia_id" onchange="javascript:borrarRegistros();">
        <option value="">Seleccione ...</option>
        <?php echo $mySQL->get_options_from_query('garantia JOIN sector USING (sector_id)', 'garantia_id', "concat(sector_nombre, ' - ', garantia_nombre)", "garantia_activo = 'S'")?>
      </select>
    </td>
  </tr>
</table>
<br/>
<br/>
<button class="btn btn-default" onclick="javascript:listarTasas();">Listar Amparos y Tasas</button>
<br/>
<br/>
<div id="divRegistros"></div>