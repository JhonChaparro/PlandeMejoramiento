<?php
//     DESCRIPCION:	Programa para ingresar, editar y deshabilitar los usuarios
//         VERSION:	1.0
//           AUTOR:	NETStudio
//           FECHA:	2016-03-22
//
//  MODIFICACIONES:
//
//
?>
<script type="text/javascript" src="js/usuarios.js?time=<?php echo time(); ?>"></script>
<div class="title">Control de usuarios</div>
<br/>
<br/>
<input type="text" id="textBusqueda"/><button class="btn btn-default" id="btnBusqueda">Buscar <img src="images/b_search.png"/></button><button class="btn btn-default" id="btnBusqueda" onclick="javascript:editarUsuario('nuevo');">Nuevo usuario <img src="images/b_add.png"/></button> 
<div id="divListaUsuarios"></div>
<div id="divEditUsuarios" align="center">
  <form enctype='MULTIPART/form-data' method= "post">
    <table>
      <tr>
        <td style="text-align: right;">* Nombres:</td>
        <td><input type="text" id="nombres"/></td>
      </tr>
      <tr>
        <td style="text-align: right;">* Apellidos:</td>
        <td><input type="text" id="apellidos"/></td>
      </tr>
      <tr>
        <td style="text-align: right;">* Número de identificación:</td>
        <td><input type="text" id="identificacion"/></td>
      </tr>
      <tr>
        <td style="text-align: right;">* Email:</td>
        <td><input type="text" id="email"/></td>
      </tr
      <tr>
        <td style="text-align: right;">Contraseña:</td>
        <td>
          <input type="password" id="clave"/>
          <br/>
          <span id="msgPassword" class="msghelp">Dejar vac&iacute;o si no se quiere actualizar</span>
        </td>
      </tr>
      <tr>
        <td style="text-align: right;">Repita la Contraseña:</td>
        <td><input type="password" id="clave2"/></td>
      </tr>
      <tr>
        <td style="text-align: right;">Rol:</td>
        <td>
          <select id="rol_id" style="width: auto;">
            <?php echo $mySQL->get_options_from_query('roles', 'rol_id', 'rol_nombre', '', 'rol_nombre', '', true); ?>
          </select>
        </td>
      </tr>
      <tr>
        <td style="text-align: right;">Area:</td>
        <td>
          <select id="area_id" style="width: auto;">
            <?php echo $mySQL->get_options_from_query('areas', 'area_id', 'area_nombre', '', 'area_nombre', '', true); ?>
          </select>
        </td>
      </tr>
      <input type="hidden" id="usuario_id" name="usuario_id"/>
    </table>
    <hr/>
    <div id="divEditUsuariosMessage"></div>
    <br/>
    <br/>
    <button class="btn btn-info" id="btnGuardar">Guardar</button>
    <button class="btn btn-default" id="btnCancelar">Cancelar</button>
  </form>
  <div id="divEditUsuariosMessage"></div>
</div>